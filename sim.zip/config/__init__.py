"""
Configuration module for SimOxy Simulation Engine.

This module provides centralized configuration management for all simulation
components, ensuring consistency and compliance with the SimOxy Handbook.
"""

from .simulation_config import (
    # Enums
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    WellStatus,
    CrudeGrade,
    RefineryConfiguration,
    RefineryProduct,
    # Constants
    SimulationConstants,
    # Parameter dictionaries
    WELL_TYPE_PARAMETERS,
    DECLINE_TYPE_PARAMETERS,
    DRIVE_MECHANISM_DECLINE_MULTIPLIER,
    CONFIGURATION_MULTIPLIER,
    CRUDE_GRADE_PROBABILITIES,
    PLAY_TYPE_TO_WELL_TYPE,
    REFINERY_PRODUCTS,
    CRACK_PRODUCTS,
    LIGHT_PRODUCTS,
    CRACKED_HFO_DISTRIBUTION,
    CRUDE_GRADE_TO_REFINERY_GRADE,
    DEFAULT_REFINERY_YIELDS,
    get_well_type_defaults,
)

__all__ = [
    # Enums
    "WellType",
    "DeclineType",
    "DriveMechanism",
    "WellConfiguration",
    "WellStatus",
    "CrudeGrade",
    "RefineryConfiguration",
    "RefineryProduct",
    # Constants
    "SimulationConstants",
    # Parameter dictionaries
    "WELL_TYPE_PARAMETERS",
    "DECLINE_TYPE_PARAMETERS",
    "DRIVE_MECHANISM_DECLINE_MULTIPLIER",
    "CONFIGURATION_MULTIPLIER",
    "CRUDE_GRADE_PROBABILITIES",
    "PLAY_TYPE_TO_WELL_TYPE",
    "REFINERY_PRODUCTS",
    "CRACK_PRODUCTS",
    "LIGHT_PRODUCTS",
    "CRACKED_HFO_DISTRIBUTION",
    "CRUDE_GRADE_TO_REFINERY_GRADE",
    "DEFAULT_REFINERY_YIELDS",
    "get_well_type_defaults",
]
