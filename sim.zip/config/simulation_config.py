"""
Centralized Simulation Configuration - Single Source of Truth.

This module contains all configuration constants, enums, and parameter
dictionaries used across the SimOxy simulation engine. All simulation
components should import from this module to ensure consistency.

COMPLIANCE: Parameters align with SimOxy Handbook specifications.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any


# =============================================================================
# ENUMS - Type-safe constants for well attributes
# =============================================================================

class WellType(str, Enum):
    """Valid well types as per SimOxy Handbook."""
    SHALE_OIL = "Shale Oil"
    CONVENTIONAL_TIGHT = "Conventional Tight"
    CONVENTIONAL_ONSHORE = "Conventional Onshore"
    CONVENTIONAL_OFFSHORE = "Conventional Offshore"
    TIGHT = "Tight"
    CUSTOM = "Custom"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid well type values."""
        return {member.value for member in cls}


class DeclineType(str, Enum):
    """Decline curve types supported by the simulation."""
    EXPONENTIAL = "Exponential"
    HYPERBOLIC = "Hyperbolic"
    HARMONIC = "Harmonic"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid decline type values."""
        return {member.value for member in cls}


class DriveMechanism(str, Enum):
    """Reservoir drive mechanisms affecting decline behavior."""
    WATER_DRIVE = "Water Drive"
    SOLUTION_GAS_DRIVE = "Solution Gas Drive"
    DEPLETION_DRIVE = "Depletion Drive"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid drive mechanism values."""
        return {member.value for member in cls}


class WellConfiguration(str, Enum):
    """Well completion configurations."""
    VERTICAL = "Vertical"
    HORIZONTAL = "Horizontal"
    FRAC = "Frac"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid configuration values."""
        return {member.value for member in cls}


class WellStatus(str, Enum):
    """Operational status of wells."""
    ACTIVE = "Active"
    CHOKED = "Choked"
    INACTIVE = "Inactive"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid status values."""
        return {member.value for member in cls}


class CrudeGrade(str, Enum):
    """Crude oil grade classifications."""
    LIGHT_SWEET = "Light Sweet"
    LIGHT_SOUR = "Light Sour"
    MEDIUM_SWEET = "Medium Sweet"
    MEDIUM_SOUR = "Medium Sour"
    HEAVY_SOUR = "Heavy Sour"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid crude grade values."""
        return {member.value for member in cls}


# =============================================================================
# REFINERY ENUMS AND CONFIGURATION
# =============================================================================

class RefineryConfiguration(str, Enum):
    """Refinery processing configurations."""
    SIMPLE_DISTILLATION = "Simple Distillation"
    HYDROSKIMMING = "Hydroskimming"
    COKING = "Coking"
    CRACKING = "Cracking"
    EXPORT = "Export"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid refinery configuration values."""
        return {member.value for member in cls}


class RefineryProduct(str, Enum):
    """Refinery output products."""
    LPG = "LPG"
    NAPHTHA = "Naphtha"
    GASOLINE = "Gasoline"
    KERO_JET = "Kero/Jet"
    GASOIL_DIESEL = "Gasoil/Diesel"
    HEAVY_FUEL_OIL = "Heavy Fuel Oil"
    
    @classmethod
    def values(cls) -> set:
        """Return set of all valid refinery product values."""
        return {member.value for member in cls}


# =============================================================================
# GLOBAL CONSTANTS
# =============================================================================

@dataclass(frozen=True)
class SimulationConstants:
    """
    Immutable simulation constants.
    
    These values should not change during simulation runtime.
    All constants are documented with their units where applicable.
    """
    # Time constants
    DAYS_IN_YEAR: float = 365.25
    
    # EUR estimation
    DEFAULT_EUR_HORIZON_YEARS: int = 30  # years
    
    # Economic limits
    MIN_ECONOMIC_PRODUCTION: float = 0.5  # bbl/day - below this, well is uneconomic
    
    # Pipeline defaults
    DEFAULT_PIPELINE_CAPACITY: float = 20000 # bbl/day
    MIN_PIPELINE_ECONOMIC_FLOW: float = 100.0  # bbl/day
    PIPELINE_ANNUAL_CAPACITY_INCREASE: float = 0.02  # 2% per year
    
    # Well numbering
    DEFAULT_API_START: int = 9_000_000
    
    # ECR (Enhanced Completion Recovery) multiplier
    ECR_UPLIFT_FACTOR: float = 1.15  # 15% production uplift
    
    # Drilling constraints
    DEFAULT_OFFSHORE_QUARTERLY_LIMIT: int = 100  # max offshore wells per quarter
    
    # Production cost defaults (for production_cost calculation)
    BASE_OPEX_PER_DAY: float = 10.0  # base operating expense per day
    VARIABLE_OPEX_FACTOR: float = 0.05  # cost per bbl produced
    
    # Fallback initial production for existing wells with missing qi
    FALLBACK_EXISTING_WELL_QI: float = 66.0  # bopd


# Create a singleton instance for easy access
CONSTANTS = SimulationConstants()


# =============================================================================
# WELL TYPE PARAMETERS - SINGLE SOURCE OF TRUTH
# COMPLIANCE: Aligns with SimOxy Handbook ranges and defaults
# =============================================================================

WELL_TYPE_PARAMETERS: Dict[str, Dict[str, Any]] = {
    WellType.SHALE_OIL.value: {
        "decline_exponent": 1.30,      # Typical shale b-factor: 1.0–1.5+
        "nominal_decline_rate": 0.65,  # First-year decline: 60–75%
        "typical_qi": 500,             # Common IP range: 250–2500+ bopd (initial production)
        "default_max_capacity_multiplier": 3.0,
        "drive_mechanism": DriveMechanism.DEPLETION_DRIVE.value,
        "configuration": WellConfiguration.HORIZONTAL.value,
    },
    WellType.CONVENTIONAL_TIGHT.value: {
        "decline_exponent": 0.95,      # Tight sands b-factor: 0.8–1.2
        "nominal_decline_rate": 0.32,  # First-year decline: 25–40%
        "typical_qi": 150,             # Typical IP: 100–180 bopd (initial production)
        "default_max_capacity_multiplier": 2.0,
        "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
        "configuration": WellConfiguration.VERTICAL.value,
    },
    WellType.CONVENTIONAL_ONSHORE.value: {
        "decline_exponent": 0.4,       # COMPLIANCE: Exponential-like; b ≈ 0.3–0.4
        "nominal_decline_rate": 0.15,  # First-year decline: 10–25%
        "typical_qi": 26,             # Initial production in bopd
        "default_max_capacity_multiplier": 15.0,
        "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
        "configuration": WellConfiguration.VERTICAL.value,
    },
    WellType.CONVENTIONAL_OFFSHORE.value: {
        "decline_exponent": 0.6,       # COMPLIANCE: Offshore exponential/hyperbolic: 0.4–0.8
        "nominal_decline_rate": 0.14,  # COMPLIANCE: First-year decline: 8–20% (mid-range)
        "typical_qi": 100,            # Initial production in bopd
        "default_max_capacity_multiplier": 8.0,  # COMPLIANCE: Max capacity 10k-40k+ range
        "drive_mechanism": DriveMechanism.WATER_DRIVE.value,
        "configuration": WellConfiguration.HORIZONTAL.value,
    },
    WellType.TIGHT.value: {
        "decline_exponent": 1.00,      # General tight reservoirs: 0.7–1.3
        "nominal_decline_rate": 0.30,  # First-year decline: 25–50%
        "typical_qi": 200,             # Typical IP: 100–1500 bopd (initial production)
        "default_max_capacity_multiplier": 4.0,
        "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
        "configuration": WellConfiguration.HORIZONTAL.value,
    },
    WellType.CUSTOM.value: {
        "decline_exponent": 0.5,       # Default custom values - can be overridden
        "nominal_decline_rate": 0.20,  # Default 20% first-year decline
        "typical_qi": 250,             # Default 250 bopd (initial production)
        "default_max_capacity_multiplier": 5.0,
        "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
        "configuration": WellConfiguration.VERTICAL.value,
    },
}


def get_well_type_defaults(well_type: str) -> Dict[str, Any]:
    """
    Get normalized default parameters for a well type (single source of truth).

    Returns a copy with standardized keys so callers don't need to know
    the internal WELL_TYPE_PARAMETERS structure.
    """
    params = WELL_TYPE_PARAMETERS.get(
        well_type,
        WELL_TYPE_PARAMETERS[WellType.CUSTOM.value],
    )

    return {
        "initial_production": params["typical_qi"],
        "b_factor": params["decline_exponent"],
        "nominal_decline_rate": params["nominal_decline_rate"],
        "drive_mechanism": params.get("drive_mechanism", DriveMechanism.SOLUTION_GAS_DRIVE.value),
        "configuration": params.get("configuration", WellConfiguration.VERTICAL.value),
        "default_max_capacity_multiplier": params.get("default_max_capacity_multiplier", 3.0),
    }


# =============================================================================
# DECLINE TYPE PARAMETERS
# COMPLIANCE: Decline type determines b-factor and decline rate behavior
# =============================================================================

DECLINE_TYPE_PARAMETERS: Dict[str, Dict[str, Any]] = {
    DeclineType.EXPONENTIAL.value: {
        "b_factor": 0.0,           # b=0 for exponential decline
        "decline_multiplier": 1.0,
    },
    DeclineType.HYPERBOLIC.value: {
        "b_factor": None,          # Use well type default b-factor
        "decline_multiplier": 1.0,
    },
    DeclineType.HARMONIC.value: {
        "b_factor": 1.0,           # b=1 for harmonic decline
        "decline_multiplier": 0.8,  # Slower decline
    },
}


# =============================================================================
# DRIVE MECHANISM MULTIPLIERS
# COMPLIANCE: Per SimOxy Handbook
# =============================================================================

DRIVE_MECHANISM_DECLINE_MULTIPLIER: Dict[str, float] = {
    DriveMechanism.WATER_DRIVE.value: 0.7,         # COMPLIANCE: gentler decline (slower)
    DriveMechanism.SOLUTION_GAS_DRIVE.value: 1.0,  # COMPLIANCE: standard decline
    DriveMechanism.DEPLETION_DRIVE.value: 1.25,    # COMPLIANCE: steeper decline
}


# =============================================================================
# WELL CONFIGURATION MULTIPLIERS
# COMPLIANCE: Vertical / Horizontal / Frac productivity multipliers
# =============================================================================

CONFIGURATION_MULTIPLIER: Dict[str, float] = {
    WellConfiguration.VERTICAL.value: 1.0,
    WellConfiguration.HORIZONTAL.value: 1.4,
    WellConfiguration.FRAC.value: 1.8,
}


# =============================================================================
# CRUDE GRADE PROBABILITY DISTRIBUTIONS
# COMPLIANCE: Based on SimOxy Handbook - Well Type Crude Grade Probabilities
# =============================================================================

CRUDE_GRADE_PROBABILITIES: Dict[str, Dict[str, float]] = {
    WellType.SHALE_OIL.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.70,
        CrudeGrade.LIGHT_SOUR.value: 0.20,
        CrudeGrade.MEDIUM_SWEET.value: 0.10,
        CrudeGrade.MEDIUM_SOUR.value: 0.0,
        CrudeGrade.HEAVY_SOUR.value: 0.0,
    },
    WellType.CONVENTIONAL_TIGHT.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.50,
        CrudeGrade.LIGHT_SOUR.value: 0.15,
        CrudeGrade.MEDIUM_SWEET.value: 0.25,
        CrudeGrade.MEDIUM_SOUR.value: 0.10,
        CrudeGrade.HEAVY_SOUR.value: 0.0,
    },
    WellType.TIGHT.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.40,
        CrudeGrade.LIGHT_SOUR.value: 0.10,
        CrudeGrade.MEDIUM_SWEET.value: 0.25,
        CrudeGrade.MEDIUM_SOUR.value: 0.20,
        CrudeGrade.HEAVY_SOUR.value: 0.05,
    },
    WellType.CONVENTIONAL_OFFSHORE.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.45,
        CrudeGrade.LIGHT_SOUR.value: 0.10,
        CrudeGrade.MEDIUM_SWEET.value: 0.25,
        CrudeGrade.MEDIUM_SOUR.value: 0.20,
        CrudeGrade.HEAVY_SOUR.value: 0.0,
    },
    WellType.CONVENTIONAL_ONSHORE.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.40,
        CrudeGrade.LIGHT_SOUR.value: 0.10,
        CrudeGrade.MEDIUM_SWEET.value: 0.25,
        CrudeGrade.MEDIUM_SOUR.value: 0.20,
        CrudeGrade.HEAVY_SOUR.value: 0.05,
    },
    WellType.CUSTOM.value: {
        CrudeGrade.LIGHT_SWEET.value: 0.50,
        CrudeGrade.LIGHT_SOUR.value: 0.20,
        CrudeGrade.MEDIUM_SWEET.value: 0.20,
        CrudeGrade.MEDIUM_SOUR.value: 0.08,
        CrudeGrade.HEAVY_SOUR.value: 0.02,
    },
}


# =============================================================================
# REFINERY CONFIGURATION PARAMETERS
# =============================================================================
 
# Products processed by refineries
REFINERY_PRODUCTS = [
    RefineryProduct.LPG.value,
    RefineryProduct.NAPHTHA.value,
    RefineryProduct.GASOLINE.value,
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
    RefineryProduct.HEAVY_FUEL_OIL.value,
]
 
# Products that receive cracked HFO redistribution
CRACK_PRODUCTS = [
    RefineryProduct.GASOLINE.value,
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
]
 
# Light products (no HFO redistribution)
LIGHT_PRODUCTS = [
    RefineryProduct.LPG.value,
    RefineryProduct.NAPHTHA.value,
]
 
# Product lists for grade-specific yield calculations
MEDIUM_HIGH_PRODUCTS = [
    RefineryProduct.GASOLINE.value,
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
]
 
MEDIUM_LOW_PRODUCTS = [
    RefineryProduct.LPG.value,
    RefineryProduct.NAPHTHA.value,
]
 
LIGHT_COKING_HIGH_PRODUCTS = [
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
]
 
LIGHT_COKING_LOW_PRODUCTS = [
    RefineryProduct.LPG.value,
    RefineryProduct.NAPHTHA.value,
    RefineryProduct.GASOLINE.value,
]

# Cracked HFO redistribution percentages for Coking/Cracking configurations
# NOTE: This is deprecated in favor of grade-specific calculations
CRACKED_HFO_DISTRIBUTION: Dict[str, float] = {
    RefineryProduct.GASOLINE.value: 0.40,      # 40% of cracked HFO → Gasoline
    RefineryProduct.GASOIL_DIESEL.value: 0.40,  # 40% of cracked HFO → Diesel
    RefineryProduct.KERO_JET.value: 0.20,       # 20% of cracked HFO → Jet fuel
}
 
 
LIGHT_CRACK_HIGH_PRODUCTS = [
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
    RefineryProduct.LPG.value,
]
 
LIGHT_CRACK_LOW_PRODUCTS = [
    RefineryProduct.NAPHTHA.value,
    RefineryProduct.GASOLINE.value,
]
 
HEAVY_LIGHT_PRODUCTS = [
    RefineryProduct.GASOLINE.value,
    RefineryProduct.KERO_JET.value,
    RefineryProduct.GASOIL_DIESEL.value,
    RefineryProduct.LPG.value,
    RefineryProduct.NAPHTHA.value,
]
 
# Mapping from CrudeGrade to refinery grade_name_match
CRUDE_GRADE_TO_REFINERY_GRADE: Dict[str, str] = {
    CrudeGrade.LIGHT_SWEET.value: "Light Sweet",
    CrudeGrade.LIGHT_SOUR.value: "Light Sour",
    CrudeGrade.MEDIUM_SWEET.value: "Medium Sweet",
    CrudeGrade.MEDIUM_SOUR.value: "Medium Sour",
    CrudeGrade.HEAVY_SOUR.value: "Heavy Sour",
}
 
# Default refinery conversion factors (used when mapping data unavailable)
DEFAULT_REFINERY_YIELDS: Dict[str, Dict[str, float]] = {
    RefineryConfiguration.SIMPLE_DISTILLATION.value: {
        RefineryProduct.LPG.value: 0.02,
        RefineryProduct.NAPHTHA.value: 0.10,
        RefineryProduct.GASOLINE.value: 0.25,
        RefineryProduct.KERO_JET.value: 0.12,
        RefineryProduct.GASOIL_DIESEL.value: 0.28,
        RefineryProduct.HEAVY_FUEL_OIL.value: 0.23,
    },
    RefineryConfiguration.HYDROSKIMMING.value: {
        RefineryProduct.LPG.value: 0.03,
        RefineryProduct.NAPHTHA.value: 0.12,
        RefineryProduct.GASOLINE.value: 0.30,
        RefineryProduct.KERO_JET.value: 0.14,
        RefineryProduct.GASOIL_DIESEL.value: 0.26,
        RefineryProduct.HEAVY_FUEL_OIL.value: 0.15,
    },
    RefineryConfiguration.COKING.value: {
        RefineryProduct.LPG.value: 0.04,
        RefineryProduct.NAPHTHA.value: 0.08,
        RefineryProduct.GASOLINE.value: 0.48,
        RefineryProduct.KERO_JET.value: 0.10,
        RefineryProduct.GASOIL_DIESEL.value: 0.22,
        RefineryProduct.HEAVY_FUEL_OIL.value: 0.08,
    },
    RefineryConfiguration.CRACKING.value: {
        RefineryProduct.LPG.value: 0.05,
        RefineryProduct.NAPHTHA.value: 0.09,
        RefineryProduct.GASOLINE.value: 0.45,
        RefineryProduct.KERO_JET.value: 0.11,
        RefineryProduct.GASOIL_DIESEL.value: 0.23,
        RefineryProduct.HEAVY_FUEL_OIL.value: 0.07,
    },
}


# =============================================================================
# PLAY TYPE TO WELL TYPE MAPPING
# Maps forecast play_type to WellAgent well_type
# =============================================================================

PLAY_TYPE_TO_WELL_TYPE: Dict[str, str] = {
    "CONVENTIONAL ONSHORE": WellType.CONVENTIONAL_ONSHORE.value,
    "CONVENTIONAL OFFSHORE": WellType.CONVENTIONAL_OFFSHORE.value,
    "UNCONVENTIONAL ONSHORE": WellType.SHALE_OIL.value,
    "UNCONVENTIONAL OFFSHORE": WellType.CONVENTIONAL_OFFSHORE.value,  # Handbook: offshore must be conventional
    "SHALE": WellType.SHALE_OIL.value,
    "TIGHT": WellType.TIGHT.value,
    "CONVENTIONAL TIGHT": WellType.CONVENTIONAL_TIGHT.value,
}


# =============================================================================
# VALIDATION BOUNDS
# Centralized validation ranges for well parameters
# =============================================================================

@dataclass(frozen=True)
class ValidationBounds:
    """Parameter validation bounds as per SimOxy Handbook."""
    B_FACTOR_MIN: float = 0.0
    B_FACTOR_MAX: float = 2.0
    
    INITIAL_PRODUCTION_MIN: float = 0.0  # Must be > 0 (exclusive)
    
    NOMINAL_DECLINE_RATE_MIN: float = 0.0  # Must be > 0 (exclusive)
    NOMINAL_DECLINE_RATE_MAX: float = 1.0  # 100% decline rate max
    
    EUR_MIN: float = 0.0  # Must be > 0 for valid EUR


VALIDATION_BOUNDS = ValidationBounds()
