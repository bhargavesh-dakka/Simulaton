"""
Well Configuration Validators.

Provides Pydantic-based validation for well configurations, ensuring
all well data meets SimOxy Handbook compliance requirements.
"""

from datetime import datetime
from typing import Optional, Dict, Any, List, Union
from pydantic import BaseModel, Field, field_validator, model_validator

import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.simulation_config import (
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    WellStatus,
    VALIDATION_BOUNDS,
    WELL_TYPE_PARAMETERS,
)


class WellConfigSchema(BaseModel):
    """
    Pydantic schema for well configuration validation.
    """
    
    # Identification
    api_number: Optional[Union[int, str]] = Field(None, description="Unique API identifier")
    
    # Well classification
    well_type: str = Field(..., description="Type of well (e.g., 'Shale Oil', 'Conventional Onshore')")
    
    # Production parameters
    initial_production: Optional[float] = Field(None, gt=0, description="Initial production rate in bbl/day")
    b_factor: float = Field(
        default=0.5,
        ge=VALIDATION_BOUNDS.B_FACTOR_MIN,
        le=VALIDATION_BOUNDS.B_FACTOR_MAX,
        description="Decline curve b-factor"
    )
    nominal_decline_rate: float = Field(
        default=0.05,
        gt=0,
        le=VALIDATION_BOUNDS.NOMINAL_DECLINE_RATE_MAX,
        description="Annual nominal decline rate (0-1)"
    )
    decline_type: str = Field(default="Hyperbolic", description="Type of decline curve")
    
    # Dates
    production_start_date: Optional[datetime] = Field(None, description="Date when production begins")
    production_end_date: Optional[datetime] = Field(None, description="Date when production ends")
    drilling_date: Optional[datetime] = Field(None, description="Date when drilling started")
    
    # Location
    location: Optional[str] = Field(None, description="Well location or basin name")
    basin: Optional[str] = Field(None, description="Basin name")
    
    # Technical parameters
    drive_mechanism: str = Field(default="Solution Gas Drive", description="Reservoir drive mechanism")
    configuration: str = Field(default="Vertical", description="Well completion configuration")
    operational_status: str = Field(default="Active", description="Current operational status")
    
    # Recovery estimates
    eur: Optional[float] = Field(None, gt=0, description="Estimated Ultimate Recovery in bbls")
    max_capacity: Optional[float] = Field(None, gt=0, description="Maximum production capacity in bbl/day")
    
    # Options
    ecr_enabled: bool = Field(default=False, description="Enhanced Completion Recovery enabled")
    actual_production_data: Optional[Dict[str, float]] = Field(
        default_factory=dict,
        description="Historical production data"
    )
    
    class Config:
        extra = "allow"
        validate_assignment = True
    
    @field_validator("well_type")
    @classmethod
    def validate_well_type(cls, v: str) -> str:
        valid_types = WellType.values()
        if v not in valid_types:
            raise ValueError(f"Invalid well_type '{v}'. Valid types: {sorted(valid_types)}")
        return v
    
    @field_validator("decline_type")
    @classmethod
    def validate_decline_type(cls, v: str) -> str:
        valid_types = DeclineType.values()
        if v not in valid_types:
            raise ValueError(f"Invalid decline_type '{v}'. Valid types: {sorted(valid_types)}")
        return v
    
    @field_validator("drive_mechanism")
    @classmethod
    def validate_drive_mechanism(cls, v: str) -> str:
        valid_mechanisms = DriveMechanism.values()
        if v not in valid_mechanisms:
            raise ValueError(f"Invalid drive_mechanism '{v}'. Valid types: {sorted(valid_mechanisms)}")
        return v
    
    @field_validator("configuration")
    @classmethod
    def validate_configuration(cls, v: str) -> str:
        valid_configs = WellConfiguration.values()
        if v not in valid_configs:
            raise ValueError(f"Invalid configuration '{v}'. Valid types: {sorted(valid_configs)}")
        return v
    
    @field_validator("operational_status")
    @classmethod
    def validate_operational_status(cls, v: str) -> str:
        valid_statuses = WellStatus.values()
        if v not in valid_statuses:
            raise ValueError(f"Invalid operational_status '{v}'. Valid statuses: {sorted(valid_statuses)}")
        return v
    
    @model_validator(mode='after')
    def validate_dates_and_compliance(self) -> 'WellConfigSchema':
        # Validate end date is after start date
        if self.production_end_date is not None and self.production_start_date is not None:
            if self.production_end_date < self.production_start_date:
                raise ValueError(
                    f"production_end_date ({self.production_end_date}) must be after "
                    f"production_start_date ({self.production_start_date})"
                )
        
        # COMPLIANCE: Validate offshore wells are conventional type
        location = self.location or ""
        well_type = self.well_type
        
        if isinstance(location, str) and "offshore" in location.lower():
            if "conventional" not in well_type.lower():
                raise ValueError(
                    f"COMPLIANCE ERROR: Offshore wells must be Conventional type. "
                    f"Got well_type='{well_type}' for location='{location}'"
                )
        
        # Set default initial_production based on well_type if not provided
        if self.initial_production is None and self.well_type in WELL_TYPE_PARAMETERS:
            params = WELL_TYPE_PARAMETERS[self.well_type]
            object.__setattr__(self, 'initial_production', params.get("typical_qi", 100.0))
        
        return self
    
    def to_well_kwargs(self) -> Dict[str, Any]:
        return self.model_dump(exclude_none=True, exclude_unset=False)


class WellConfigUpdateSchema(BaseModel):
    """Schema for updating existing well configurations."""
    
    initial_production: Optional[float] = Field(None, gt=0)
    b_factor: Optional[float] = Field(
        None,
        ge=VALIDATION_BOUNDS.B_FACTOR_MIN,
        le=VALIDATION_BOUNDS.B_FACTOR_MAX
    )
    nominal_decline_rate: Optional[float] = Field(None, gt=0, le=1.0)
    max_capacity: Optional[float] = Field(None, gt=0)
    operational_status: Optional[str] = None
    ecr_enabled: Optional[bool] = None
    
    @field_validator("operational_status")
    @classmethod
    def validate_status(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            valid_statuses = WellStatus.values()
            if v not in valid_statuses:
                raise ValueError(f"Invalid operational_status '{v}'. Valid: {sorted(valid_statuses)}")
        return v


class BatchWellConfigSchema(BaseModel):
    """Schema for batch well creation validation."""
    
    configs: List[WellConfigSchema] = Field(
        ...,
        min_length=1,
        description="List of well configurations to create"
    )
    
    skip_validation: bool = Field(
        default=False,
        description="Skip individual validation"
    )


def validate_well_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate a well configuration dictionary.
    """
    try:
        schema = WellConfigSchema(**config)
        return schema.to_well_kwargs()
    except Exception as e:
        raise ValueError(f"Well configuration validation failed: {str(e)}") from e


def validate_offshore_compliance(well_type: str, location: str) -> bool:
    """
    Check if a well type is compliant for an offshore location.
    """
    if location and isinstance(location, str) and "offshore" in location.lower():
        return "conventional" in well_type.lower()
    return True
