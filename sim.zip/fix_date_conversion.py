#!/usr/bin/env python3
"""
Fix for Polars date conversion issue in the notebook.

The error "production_start_date must be a datetime object" occurs because
Polars date objects need to be converted to Python datetime objects.

Add this import at the top:
from datetime import date

And modify the create_well_config function to convert dates properly:
"""

def create_well_config_fixed(row: dict) -> Dict[str, Any]:
    """Create well configuration from merged data with proper date conversion."""
    api = row['api']

    # Get actual production data for this well
    well_production = fact.filter(pl.col('api') == api).sort('prod_date')
    actual_production = {}

    for prod_row in well_production.iter_rows(named=True):
        date_str = prod_row['prod_date'].strftime('%Y-%m-%d')
        bopd = prod_row['bopd']
        if bopd is not None and bopd > 0:
            actual_production[date_str] = float(bopd)

    # Convert Polars date to Python datetime
    start_date = row['first_prod_date']
    if hasattr(start_date, 'year') and hasattr(start_date, 'month') and hasattr(start_date, 'day'):
        # Polars date object - convert to datetime
        production_start_date = datetime.combine(start_date, datetime.min.time())
    else:
        # Already a datetime or other format
        production_start_date = start_date

    # Configuration
    config = {
        'api_number': api,
        'well_type': map_well_type(row['well_type']),
        'decline_type': map_decline_type(row.get('model', 'hyperbolic')),

        # From dimension table
        'initial_production': float(row['Qi']),
        'nominal_decline_rate': float(row['Di']),
        'b_factor': float(row.get('b_factor', 0.5)) if row.get('b_factor') else 0.5,

        # Dates - use the converted datetime
        'production_start_date': production_start_date,

        # Location
        'location': row['basin_name'],
        'basin': row['basin_name'],

        # Historical production data
        'actual_production_data': actual_production,

        # Fallback parameters
        'last_known_qi': float(row['last_bopd']) if row['last_bopd'] else float(row['Qi']),
        'last_known_di': float(row['Di']) / 12,  # Convert annual to monthly
        'last_data_date': row['latest_prod_date'],

        # Mark as existing well
        'is_new': False,
    }

    return config

print("Fixed version of create_well_config function:")
print("=" * 60)
import inspect
print(inspect.getsource(create_well_config_fixed))
