"""
Custom Exception Hierarchy for SimOxy Simulation Engine.
"""

from typing import Any, Optional, Dict, List


class SimulationError(Exception):
    """Base exception for all simulation-related errors."""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "details": self.details,
        }


class SimulationNotInitializedError(SimulationError):
    def __init__(self, message: str = "Simulation not initialized"):
        super().__init__(message, details={"hint": "Call the /initialize endpoint first"})


class SimulationAlreadyRunningError(SimulationError):
    def __init__(self, message: str = "Simulation is already running"):
        super().__init__(message, details={"hint": "Reset the simulation before re-initializing"})


class ValidationError(SimulationError):
    """Base class for validation-related errors."""
    pass


class WellValidationError(ValidationError):
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        value: Any = None,
        constraint: Optional[str] = None,
    ):
        self.field = field
        self.value = value
        self.constraint = constraint
        
        details = {}
        if field:
            details["field"] = field
        if value is not None:
            details["value"] = str(value)
        if constraint:
            details["constraint"] = constraint
        
        super().__init__(message, details)


class ConfigurationValidationError(ValidationError):
    def __init__(self, message: str, invalid_fields: Optional[List[str]] = None):
        details = {}
        if invalid_fields:
            details["invalid_fields"] = invalid_fields
        super().__init__(message, details)


class DateValidationError(ValidationError):
    def __init__(
        self,
        message: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ):
        details = {}
        if start_date:
            details["start_date"] = start_date
        if end_date:
            details["end_date"] = end_date
        super().__init__(message, details)


class ResourceError(SimulationError):
    """Base class for resource-related errors."""
    pass


class ReserveDepletionError(ResourceError):
    def __init__(
        self,
        message: str = "Basin reserves have been depleted",
        basin_name: Optional[str] = None,
        remaining_reserves: Optional[float] = None,
    ):
        details = {}
        if basin_name:
            details["basin_name"] = basin_name
        if remaining_reserves is not None:
            details["remaining_reserves"] = remaining_reserves
        super().__init__(message, details)


class PipelineCapacityError(ResourceError):
    def __init__(
        self,
        message: str = "Pipeline capacity exceeded",
        requested_flow: Optional[float] = None,
        available_capacity: Optional[float] = None,
        pipeline_name: Optional[str] = None,
    ):
        details = {}
        if requested_flow is not None:
            details["requested_flow"] = requested_flow
        if available_capacity is not None:
            details["available_capacity"] = available_capacity
        if pipeline_name:
            details["pipeline_name"] = pipeline_name
        super().__init__(message, details)


class ConstraintError(SimulationError):
    """Base class for constraint violation errors."""
    pass


class DrillingConstraintError(ConstraintError):
    def __init__(
        self,
        message: str = "Drilling constraint exceeded",
        well_type: Optional[str] = None,
        quarter: Optional[str] = None,
        current_count: Optional[int] = None,
        limit: Optional[int] = None,
    ):
        details = {}
        if well_type:
            details["well_type"] = well_type
        if quarter:
            details["quarter"] = quarter
        if current_count is not None:
            details["current_count"] = current_count
        if limit is not None:
            details["limit"] = limit
        super().__init__(message, details)


class OffshoreComplianceError(ConstraintError):
    def __init__(
        self,
        message: str = "Offshore wells must be Conventional type",
        well_type: Optional[str] = None,
        location: Optional[str] = None,
    ):
        details = {"compliance_rule": "Offshore wells must be exclusively conventional (Handbook)"}
        if well_type:
            details["well_type"] = well_type
        if location:
            details["location"] = location
        super().__init__(message, details)


class WellError(SimulationError):
    """Base class for well-specific errors."""
    pass


class WellNotFoundError(WellError):
    def __init__(
        self,
        message: str = "Well not found",
        api_number: Optional[str] = None,
        well_id: Optional[str] = None,
    ):
        details = {}
        if api_number:
            details["api_number"] = api_number
        if well_id:
            details["well_id"] = well_id
        super().__init__(message, details)


class WellCreationError(WellError):
    def __init__(
        self,
        message: str,
        config: Optional[Dict[str, Any]] = None,
        reason: Optional[str] = None,
    ):
        details = {}
        if reason:
            details["reason"] = reason
        if config:
            details["config_summary"] = {
                k: v for k, v in config.items()
                if k in ("api_number", "well_type", "initial_production")
            }
        super().__init__(message, details)


class WellStateError(WellError):
    def __init__(
        self,
        message: str,
        current_status: Optional[str] = None,
        required_status: Optional[str] = None,
    ):
        details = {}
        if current_status:
            details["current_status"] = current_status
        if required_status:
            details["required_status"] = required_status
        super().__init__(message, details)


class DataError(SimulationError):
    """Base class for data-related errors."""
    pass


class DataLoadError(DataError):
    def __init__(
        self,
        message: str,
        file_path: Optional[str] = None,
        reason: Optional[str] = None,
    ):
        details = {}
        if file_path:
            details["file_path"] = file_path
        if reason:
            details["reason"] = reason
        super().__init__(message, details)


class DataValidationError(DataError):
    def __init__(
        self,
        message: str,
        missing_columns: Optional[List[str]] = None,
        invalid_rows: Optional[int] = None,
    ):
        details = {}
        if missing_columns:
            details["missing_columns"] = missing_columns
        if invalid_rows is not None:
            details["invalid_rows"] = invalid_rows
        super().__init__(message, details)


class ForecastError(SimulationError):
    """Base class for forecasting-related errors."""
    pass


class ForecastGenerationError(ForecastError):
    def __init__(
        self,
        message: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        reason: Optional[str] = None,
    ):
        details = {}
        if start_date:
            details["start_date"] = start_date
        if end_date:
            details["end_date"] = end_date
        if reason:
            details["reason"] = reason
        super().__init__(message, details)


def format_exception_for_api(exc: Exception) -> Dict[str, Any]:
    """Format any exception for API response."""
    if isinstance(exc, SimulationError):
        return exc.to_dict()
    else:
        return {
            "error_type": type(exc).__name__,
            "message": str(exc),
            "details": {},
        }
