"""
Data loading utilities for SimEng simulation engine.

This module provides abstracted functions for loading and processing
well data from CSV files (dim and fact tables).
"""

import polars as pl
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path


# Default data directory (relative to project root)
DATA_DIR = Path(__file__).parent.parent / "data"


def get_data_path(filename: str) -> Path:
    """Get the full path to a data file.
    
    Args:
        filename: Name of the file (can include subdirectory)
        
    Returns:
        Full path to the data file
    """
    return DATA_DIR / filename


# =============================================================================
# REFINERY DATA LOADING FUNCTIONS
# =============================================================================

def load_refinery_capacity_data(
    market_center: str = "Houston",
    filename: str = "refinery/refinery_capacity.csv"
) -> pl.DataFrame:
    """Load refinery capacity data for a market center.
    
    Args:
        market_center: Market center to filter by
        filename: Name of the refinery capacity CSV file
        
    Returns:
        Polars DataFrame with refinery capacity data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Refinery capacity file not found: {file_path}")
    
    try:
        df = pl.read_csv(str(file_path))
        
        # Filter by market center if specified
        if market_center and market_center != "All Market Centers":
            if "market_center" in df.columns:
                df = df.filter(pl.col("market_center") == market_center)
        
        return df
    except Exception as e:
        raise Exception(f"Failed to load refinery capacity data: {str(e)}")


def load_refinery_mapping_data(
    filename: str = "refinery/crude_conversion_mapping.csv"
) -> pl.DataFrame:
    """Load crude-to-product conversion mapping data.
    
    Args:
        filename: Name of the mapping CSV file
        
    Returns:
        Polars DataFrame with conversion mapping data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Refinery mapping file not found: {file_path}")
    
    try:
        df = pl.read_csv(str(file_path))
        
        # Normalize grade element names
        if "SPG_grade_element_name" in df.columns:
            df = df.with_columns(
                pl.col("SPG_grade_element_name").str.to_lowercase().str.strip_chars()
            )
        
        return df
    except Exception as e:
        raise Exception(f"Failed to load refinery mapping data: {str(e)}")


def get_unique_refineries(
    market_center: str = "Houston",
    capacity_filename: str = "refinery/refinery_capacity.csv"
) -> pl.DataFrame:
    """Get unique refineries with their configurations.
    
    Args:
        market_center: Market center to filter by
        capacity_filename: Name of the capacity CSV file
        
    Returns:
        DataFrame with unique refinery configurations (one row per refinery)
    """
    capacity_df = load_refinery_capacity_data(market_center, capacity_filename)
    
    # Group by refinery to get unique configurations
    unique_refineries = capacity_df.group_by([
        "refinery_id", "refinery_name", "basin", "market_center",
        "configuration_name", "grade_name", "grade_element_name"
    ]).agg([
        pl.col("max_capacity").first(),
        pl.col("runs_vol_avg").first(),
        pl.col("effective_capacity").first(),
        pl.col("weight").first(),
    ])
    
    return unique_refineries


def get_refinery_summary(market_center: str = "Houston") -> Dict[str, Any]:
    """Get summary statistics for refineries in a market center.
    
    Args:
        market_center: Market center to summarize
        
    Returns:
        Dictionary with refinery summary statistics
    """
    try:
        capacity_df = load_refinery_capacity_data(market_center)
        unique_refineries = get_unique_refineries(market_center)
        
        return {
            "market_center": market_center,
            "total_refineries": unique_refineries["refinery_id"].n_unique(),
            "total_capacity": capacity_df["effective_capacity"].sum(),
            "configurations": capacity_df["configuration_name"].unique().to_list(),
            "grades_processed": capacity_df["grade_name"].unique().to_list(),
        }
    except Exception as e:
        return {"error": str(e)}


def load_dim_data(
    filename,
    schema_overrides: Optional[Dict[str, Any]] = None
) -> pl.DataFrame:
    """Load dimension (decline curve) data from CSV.
    
    Args:
        filename: Name of the dim CSV file
        schema_overrides: Optional schema overrides for polars
        
    Returns:
        Polars DataFrame with dim data
        
    Raises:
        FileNotFoundError: If file doesn't exist
        Exception: If loading fails
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Dim data file not found: {file_path}")
    
    default_schema = {"api": pl.Utf8, "API": pl.Utf8}
    if schema_overrides:
        default_schema.update(schema_overrides)
    
    try:
        df = pl.read_csv(str(file_path), schema_overrides=default_schema)
        return df
    except Exception as e:
        raise Exception(f"Failed to load dim data from {file_path}: {str(e)}")


def load_fact_data(
    filename: str = "Houston_fact_combined.csv",
    schema_overrides: Optional[Dict[str, Any]] = None
) -> pl.DataFrame:
    """Load fact (production) data from CSV.
    
    Args:
        filename: Name of the fact CSV file
        schema_overrides: Optional schema overrides for polars
        
    Returns:
        Polars DataFrame with fact data
        
    Raises:
        FileNotFoundError: If file doesn't exist
        Exception: If loading fails
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Fact data file not found: {file_path}")
    
    default_schema = {"api": pl.Utf8, "API": pl.Utf8, "Well_ID": pl.Utf8}
    if schema_overrides:
        default_schema.update(schema_overrides)
    
    try:
        df = pl.read_csv(str(file_path), schema_overrides=default_schema)
        
        # Standardize column names if needed
        if "production_date" in df.columns and "production_vol_date" not in df.columns:
            df = df.rename({"production_date": "production_vol_date"})
        if "Well_ID" in df.columns and "api" not in df.columns:
            df = df.rename({"Well_ID": "api"})
            
        return df
    except Exception as e:
        raise Exception(f"Failed to load fact data from {file_path}: {str(e)}")


def parse_production_dates(df: pl.DataFrame, date_column: str = "production_vol_date") -> pl.DataFrame:
    """Parse production dates with multiple format support.
    
    Tries multiple date formats to handle different data sources:
    - M/D/YYYY (e.g., 8/1/2024)
    - YYYY-MM-DD (e.g., 2024-08-01)
    
    Args:
        df: DataFrame with date column
        date_column: Name of the date column to parse
        
    Returns:
        DataFrame with parsed date column
    """
    if date_column not in df.columns:
        return df
    
    # Try M/D/YYYY format first (8/1/2024)
    try:
        return df.with_columns(
            pl.col(date_column).str.to_date("%-m/%-d/%Y")
        )
    except:
        pass
    
    # Try YYYY-MM-DD format
    try:
        return df.with_columns(
            pl.col(date_column).str.to_date("%Y-%m-%d")
        )
    except:
        pass
    
    # Last resort: automatic parsing with strict=False
    try:
        return df.with_columns(
            pl.col(date_column).str.strptime(pl.Date, strict=False)
        )
    except:
        # Return original if all parsing attempts fail
        return df


def apply_standard_filters(
    df: pl.DataFrame,
    basin_name: Optional[str] = None,
    market_center: Optional[str] = None,
    country: Optional[str] = None
) -> pl.DataFrame:
    """Apply standard geographic filters to a DataFrame.
    
    Args:
        df: DataFrame to filter
        basin_name: Basin name to filter by (None or "All Basins" = no filter)
        market_center: Market center to filter by (None or "All Market Centers" = no filter)
        country: Country to filter by (None or "All Countries" = no filter)
        
    Returns:
        Filtered DataFrame
    """
    filters = []
    
    # Filter by basin
    if basin_name and basin_name != "All Basins" and "basin" in df.columns:
        filters.append(pl.col("basin") == basin_name)
    
    # Filter by market center
    if market_center and market_center != "All Market Centers" and "market_center_name" in df.columns:
        filters.append(pl.col("market_center_name") == market_center)
    
    # Filter by country with flexible matching
    if country and country not in ["All Countries"] and "country" in df.columns:
        country_value = country.upper()
        if country_value in ["UNITED STATES", "US", "USA", "UNITED STATES OF AMERICA"]:
            # Match both "UNITED STATES" and "UNITED STATES OF AMERICA"
            filters.append(pl.col("country").str.contains("(?i)UNITED STATES"))
        else:
            filters.append(pl.col("country").str.contains(f"(?i){country_value}"))
    
    # Apply all filters
    if filters:
        df = df.filter(pl.all_horizontal(filters))
    
    return df


def apply_date_range_filter(
    df: pl.DataFrame,
    start_date: datetime,
    end_date: datetime,
    date_column: str = "production_vol_date"
) -> pl.DataFrame:
    """Apply date range filter to a DataFrame.
    
    Args:
        df: DataFrame to filter
        start_date: Start of date range
        end_date: End of date range
        date_column: Name of the date column
        
    Returns:
        Filtered DataFrame
    """
    if date_column not in df.columns:
        return df
    
    return df.filter(
        (pl.col(date_column) >= start_date.date()) &
        (pl.col(date_column) <= end_date.date())
    )


def count_wells_in_range(
    start_date: datetime,
    end_date: datetime,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_dimension.csv"
) -> int:
    """Count existing wells from data files matching filter criteria.
    
    Wells are considered "existing" if their latest_production_date >= start_date,
    meaning they are still producing when the simulation starts.
    
    Args:
        start_date: Simulation start date
        end_date: Simulation end date (not used for existing wells filter)
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file to use
        
    Returns:
        Number of unique wells matching criteria
    """
    try:
        # Load dim data
        dim_df = load_dim_data(dim_filename)
        
        # Apply geographic filters
        dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
        
        # Filter by latest_production_date >= start_date
        # Wells still producing at simulation start are considered existing
        if "latest_production_date" in dim_df.columns:
            start_date_str = start_date.strftime("%Y-%m-%d")
            dim_df = dim_df.filter(
                pl.col("latest_production_date") >= start_date_str
            )
        
        # Return unique well count
        return dim_df["api"].n_unique()
    except Exception as e:
        print(f"Error counting existing wells: {e}")
        return 0


def load_and_merge_well_data(
    start_date,
    end_date,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_dimension.csv",
    fact_filename: str = "houston_fact_combined_cleaned.csv",
    debug: bool = False
) -> Tuple[pl.DataFrame, Dict[str, Any]]:
    """Load and merge dim and fact data for wells.
    
    This is the main function for loading well data. It:
    1. Loads dim (decline curve) data
    2. Loads fact (production) data
    3. Applies geographic and date filters
    4. Merges the two datasets
    
    Args:
        start_date: Start of simulation date range
        end_date: End of simulation date range
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file
        fact_filename: Name of the fact CSV file
        debug: If True, return debug info
        
    Returns:
        Tuple of (merged DataFrame, metadata dict)
    """
    metadata = {
        "dim_file": dim_filename,
        "fact_file": fact_filename,
        "filters_applied": {
            "basin_name": basin_name,
            "market_center": market_center,
            "country": country,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
    }
    
    # Load dim data
    dim_df = load_dim_data(dim_filename)
    metadata["dim_rows_original"] = dim_df.shape[0]
    
    # Apply geographic filters to dim data
    dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
    metadata["dim_rows_after_geo_filter"] = dim_df.shape[0]
    
    # Filter by latest_production_date >= start_date (consistent with count_wells_in_range)
    # Wells still producing at simulation start are considered existing
    if "latest_production_date" in dim_df.columns:
        start_date_str = start_date.strftime("%Y-%m-%d")
        dim_df = dim_df.filter(
            pl.col("latest_production_date") >= start_date_str
        )
    metadata["dim_rows_filtered"] = dim_df.shape[0]
    
    # Load fact data
    fact_df = load_fact_data(fact_filename)
    metadata["fact_rows_original"] = fact_df.shape[0]
    
    # Parse and filter fact data by date range
    fact_df = parse_production_dates(fact_df)
    fact_df = apply_date_range_filter(fact_df, start_date, end_date)
    
    # Apply geographic filters to fact data
    fact_df = apply_standard_filters(fact_df, basin_name, market_center, country)
    metadata["fact_rows_filtered"] = fact_df.shape[0]
    
    # Get all APIs from filtered dim table
    # dim_apis = set(dim_df["api"].unique())
    # selected_apis = list(dim_apis)
    # metadata["unique_wells"] = len(selected_apis)
    
    # Sample data
    sampled_dim_df = dim_df
    sampled_fact_df = fact_df
    
    # Merge dim and fact tables on api
    # Handle different production column names
    if "bopd" in sampled_fact_df.columns:
        merged_df = sampled_fact_df.join(
            sampled_dim_df, on=["country","market_id","basin_name","well_type","start_year"], how="left"
        ).rename({"bopd": "bopd"})
    elif "BOPD" in sampled_fact_df.columns:
        merged_df = sampled_fact_df.join(
            sampled_dim_df, on=["country","market_id","basin_name","well_type","start_year"], how="left"
        ).rename({"BOPD": "bopd"})
    else:
        merged_df = sampled_dim_df.join(sampled_fact_df, on=["country","market_id","basin_name","well_type","start_year"], how="left")
        metadata["warning"] = "Neither BOPDD nor bopd found in fact table"
    
    # Add production data stats to metadata
    if "bopd" in merged_df.columns:
        has_prod_data = merged_df.filter(
            pl.col("bopd").is_not_null()
        ).shape[0]
        metadata["rows_with_production"] = has_prod_data
    
    metadata["merged_rows"] = merged_df.shape[0]
    
    # Debug output
    if debug:
        _write_debug_info(merged_df, sampled_fact_df, metadata)
    
    return merged_df, metadata


def _write_debug_info(merged_df: pl.DataFrame, fact_df: pl.DataFrame, metadata: Dict[str, Any]) -> None:
    """Write debug information to file."""
    try:
        with open("debug_production.txt", "w", encoding="utf-8", errors="ignore") as f:
            f.write(f"Merged DF rows with production data: {metadata.get('rows_with_production', 0)} ")
            f.write(f"out of {merged_df.shape[0]}\n")
            f.write(f"Fact table columns: {fact_df.columns}\n")
            f.write(f"Merged table columns: {merged_df.columns}\n")
            
            if metadata.get("rows_with_production", 0) > 0 and "bopd" in merged_df.columns:
                sample_with_prod = merged_df.filter(
                    pl.col("bopd").is_not_null()
                ).head(2)
                f.write(f"\nSample rows with production:\n")
                cols_to_show = ["api", "production_vol_date", "bopd"]
                cols_available = [c for c in cols_to_show if c in sample_with_prod.columns]
                f.write(str(sample_with_prod.select(cols_available)))
            else:
                f.write(f"\nNo rows with production data found!\n")
                f.write(f"\nFirst 2 merged rows:\n")
                f.write(str(merged_df.head(2)))
    except Exception as e:
        print(f"Debug write failed: {e}")


def create_well_summary(merged_df: pl.DataFrame) -> pl.DataFrame:
    """Create a summary DataFrame grouped by well API.
    
    Args:
        merged_df: Merged dim/fact DataFrame
        
    Returns:
        Summary DataFrame with one row per well
    """
    agg_cols = [
        pl.col("bopd").count().alias("production_days"),
        pl.col("Qi").first().alias("qi_bopd"),
        pl.col("Di").first().alias("decline_rate"),
        pl.col("avg_value").first().alias("b_factor"),
        # Get the last production date with data for decline curve fallback
        pl.col("production_vol_date").max().alias("last_data_date"),
    ]
    
    # Include Di_per_month_latest for fallback decline rate if available
    if "Di_per_month_latest" in merged_df.columns:
        agg_cols.append(pl.col("Di_per_month_latest").first().alias("di_latest"))
    
    # Include production_start_date if available
    if "production_start_date" in merged_df.columns:
        agg_cols.append(pl.col("production_start_date").first().alias("production_start_date"))
    
    return merged_df.group_by("api").agg(agg_cols)


def get_available_well_types(
    start_date: datetime,
    end_date: datetime,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_dimension.csv"
) -> List[str]:
    """Get unique well types (play_type) from dim data matching filter criteria.
    
    Wells are considered existing if their latest_production_date >= start_date.
    
    Args:
        start_date: Simulation start date
        end_date: Simulation end date (not used for existing wells filter)
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file to use
        
    Returns:
        List of unique well types (play_type values) matching criteria
    """
    try:
        # Load dim data
        dim_df = load_dim_data(dim_filename)
        
        # Apply geographic filters
        dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
        
        # Filter by latest_production_date >= start_date (consistent with count_wells_in_range)
        # Wells still producing at simulation start are considered existing
        if "latest_production_date" in dim_df.columns:
            start_date_str = start_date.strftime("%Y-%m-%d")
            dim_df = dim_df.filter(
                pl.col("latest_production_date") >= start_date_str
            )
        
        # Get unique play_type values (well types)
        if "play_type" in dim_df.columns:
            well_types = dim_df["play_type"].unique().to_list()
            # Filter out None/null values and return sorted list
            return sorted([wt for wt in well_types if wt is not None])
        
        return []
    except Exception as e:
        print(f"Error getting available well types: {e}")
        return []


def load_drilling_rate_data() -> Tuple[pl.DataFrame, Dict[str, Dict[str, float]]]:
    """Load drilling rate data and slope coefficients.
    
    Returns:
        Tuple of (drilling_df, slope_dict)
        - drilling_df: DataFrame with historical drilling counts
        - slope_dict: Dictionary mapping play_type to {slope, intercept}
    """
    drilling_rate_folder = DATA_DIR / "drilling_rate"
    
    try:
        drilling_df = pl.read_csv(str(drilling_rate_folder / "drilling_data.csv"))
        slope_df = pl.read_csv(str(drilling_rate_folder / "slope.csv"))
        
        # Create slope dictionary
        slope_dict = {}
        for row in slope_df.iter_rows(named=True):
            slope_dict[row["Play_Type"]] = {
                "slope": row["Slope"],
                "intercept": row["Intercept"]
            }
        
        return drilling_df, slope_dict
    except Exception as e:
        print(f"Error loading drilling rate data: {e}")
        return pl.DataFrame(), {}


def calc_month_index(year: int, month: int, sim_start_year: int, sim_start_month: int) -> int:
    """Calculate month index relative to simulation start date.
    
    Args:
        year: Target year
        month: Target month
        sim_start_year: Simulation start year
        sim_start_month: Simulation start month
        
    Returns:
        Month index (1-based, relative to simulation start)
    """
    return (year - sim_start_year) * 12 + (month - sim_start_month) + 1


def build_historical_series(
    drilling_df: pl.DataFrame, 
    play_type: str, 
    sim_start_year: int, 
    sim_start_month: int
) -> Dict[int, int]:
    """Build a dictionary of month_index -> drilling count for a play type.
    
    Args:
        drilling_df: DataFrame with drilling data
        play_type: Well type / play type to filter
        sim_start_year: Simulation start year
        sim_start_month: Simulation start month
        
    Returns:
        Dictionary mapping month index to drilling count
    """
    play_data = drilling_df.filter(pl.col("play_type") == play_type).sort("month")
    
    history = {}
    for row in play_data.iter_rows(named=True):
        data_year = row["year"]
        data_month = row["month"]
        month_idx = calc_month_index(data_year, data_month, sim_start_year, sim_start_month)
        history[month_idx] = row["Total_Drilled"]
    
    return history


def forecast_wells_drilled(
    play_type: str,
    target_year: int,
    target_month: int,
    historical_data: Dict[str, Dict[int, int]],
    slope_dict: Dict[str, Dict[str, float]],
    sim_start_year: int,
    sim_start_month: int,
    multiplier: float = 1.0
) -> Tuple[int, float, float, int]:
    """Forecast wells drilled for a specific month using rolling average and trend.
    
    Formula:
    - If multiplier == 1.0: forecast = round(rolling_avg)
    - If multiplier != 1.0: forecast = round((rolling_avg + trend_adjustment) * multiplier)
    
    Args:
        play_type: Well type / play type
        target_year: Target year for forecast
        target_month: Target month for forecast
        historical_data: Dictionary of play_type -> {month_index -> count}
        slope_dict: Dictionary of play_type -> {slope, intercept}
        sim_start_year: Simulation start year
        sim_start_month: Simulation start month
        multiplier: Scenario multiplier (default 1.0)
        
    Returns:
        Tuple of (forecast, rolling_avg, trend_adjustment, monthly_index)
    """
    if play_type not in historical_data:
        return (0, 0.0, 0.0, 0)
    
    history = historical_data[play_type]
    monthly_index = calc_month_index(target_year, target_month, sim_start_year, sim_start_month)
    
    # Calculate 12-month rolling window
    window_start = monthly_index - 12
    window_end = monthly_index - 1
    
    # Get values in the window
    window_values = [history[idx] for idx in range(window_start, window_end + 1) if idx in history]
    
    # Calculate rolling average
    rolling_avg = sum(window_values) / len(window_values) if window_values else 0.0
    
    # Get slope and intercept
    m = slope_dict.get(play_type, {}).get("slope", 0)
    b = slope_dict.get(play_type, {}).get("intercept", 0)
    
    # Calculate trend adjustment
    trend_adjustment = (m * monthly_index) + b
    
    # Apply conditional formula based on multiplier
    if multiplier == 1.0:
        forecast = max(0, round(rolling_avg))
    else:
        full_value = rolling_avg + trend_adjustment
        forecast = max(0, round(full_value * multiplier))
    
    return (forecast, rolling_avg, trend_adjustment, monthly_index)


def generate_well_drilling_forecast(
    start_date: datetime,
    end_date: datetime,
    available_well_types: List[str],
    multipliers: Dict[str, float],
    global_scenario: float = 1.0,
    fact_filename: str = "houston_fact_combined.csv"
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Generate well drilling forecast for the simulation period.
    
    Args:
        start_date: Simulation start date
        end_date: Simulation end date
        available_well_types: List of play types to forecast
        multipliers: Dictionary mapping multiplier keys to values
        global_scenario: Global scenario multiplier
        fact_filename: Fact data filename to find last data month
        
    Returns:
        Tuple of (forecast_list, summary)
        - forecast_list: List of monthly forecasts with play_type, year, month, wells_count
        - summary: Summary statistics
    """
    from dateutil.relativedelta import relativedelta
    
    # Map play_type names to multiplier keys
    play_type_to_multiplier_key = {
        "CONVENTIONAL ONSHORE": "conventionalOnshore",
        "CONVENTIONAL OFFSHORE": "conventionalOffshore",
        "UNCONVENTIONAL ONSHORE": "unconventionalOnshore",
        "UNCONVENTIONAL OFFSHORE": "unconventionalOffshore",
        "SHALE": "unconventionalOnshore",
        "TIGHT": "unconventionalOnshore",
        "CONVENTIONAL TIGHT": "conventionalOnshore"
    }
    
    # Load drilling rate data
    drilling_df, slope_dict = load_drilling_rate_data()
    if drilling_df.is_empty():
        return [], {"error": "Could not load drilling rate data"}
    
    # Find last month with fact data
    try:
        fact_path = get_data_path(fact_filename)
        fact_df = pl.read_csv(str(fact_path), schema_overrides={"api": pl.Utf8})
        
        # Parse dates
        if "production_vol_date" in fact_df.columns:
            try:
                fact_df = fact_df.with_columns(
                    pl.col("production_vol_date").str.to_date("%-m/%-d/%Y").alias("parsed_date")
                )
            except:
                fact_df = fact_df.with_columns(
                    pl.col("production_vol_date").str.to_date("%Y-%m-%d").alias("parsed_date")
                )
            
            max_fact_date = fact_df["parsed_date"].max()
            last_data_year = max_fact_date.year
            last_data_month = max_fact_date.month
        else:
            # Default to current date if no fact data
            last_data_year = start_date.year
            last_data_month = start_date.month
    except Exception as e:
        print(f"Error finding last data month: {e}")
        last_data_year = start_date.year
        last_data_month = start_date.month
    
    sim_start_year = start_date.year
    sim_start_month = start_date.month
    
    # Build historical series for each play type
    historical_data = {}
    for play_type in drilling_df["play_type"].unique().to_list():
        historical_data[play_type] = build_historical_series(
            drilling_df, play_type, sim_start_year, sim_start_month
        )
    
    # Start forecasting from month after last data month
    forecast_start = datetime(last_data_year, last_data_month, 1) + relativedelta(months=1)
    
    # Create working copy of historical data
    working_history = {pt: hist.copy() for pt, hist in historical_data.items()}
    
    forecast_results = []
    current_month = forecast_start
    
    while current_month <= end_date:
        year = current_month.year
        month = current_month.month
        
        for play_type in available_well_types:
            # Get multiplier for this play type
            mult_key = play_type_to_multiplier_key.get(play_type, "conventionalOnshore")
            type_multiplier = multipliers.get(mult_key, 1.0) * global_scenario
            
            # Calculate forecast
            forecast, rolling_avg, trend_adj, monthly_index = forecast_wells_drilled(
                play_type, year, month, working_history, slope_dict,
                sim_start_year, sim_start_month, type_multiplier
            )
            
            forecast_results.append({
                "year": year,
                "month": month,
                "month_name": current_month.strftime("%B"),
                "play_type": play_type,
                "wells_count": forecast,
                "rolling_avg": round(rolling_avg, 2),
                "trend_adjustment": round(trend_adj, 4),
                "multiplier": type_multiplier
            })
            
            # Update working history for future rolling calculations
            if play_type in working_history:
                working_history[play_type][monthly_index] = forecast
        
        current_month += relativedelta(months=1)
    
    # Calculate summary
    total_wells = sum(r["wells_count"] for r in forecast_results)
    wells_by_type = {}
    wells_by_year = {}
    
    for r in forecast_results:
        pt = r["play_type"]
        yr = r["year"]
        wells_by_type[pt] = wells_by_type.get(pt, 0) + r["wells_count"]
        wells_by_year[yr] = wells_by_year.get(yr, 0) + r["wells_count"]
    
    summary = {
        "forecast_start": forecast_start.strftime("%Y-%m"),
        "forecast_end": end_date.strftime("%Y-%m"),
        "last_data_month": f"{last_data_year}-{last_data_month:02d}",
        "total_forecasted_wells": total_wells,
        "wells_by_play_type": wells_by_type,
        "wells_by_year": wells_by_year,
        "play_types_forecasted": available_well_types
    }
    
    return forecast_results, summary
