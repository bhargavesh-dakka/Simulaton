"""
Utility modules for SimEng simulation engine.
"""

from utils.data_loader import (
    load_dim_data,
    load_fact_data,
    load_and_merge_well_data,
    count_wells_in_range,
    apply_standard_filters,
    apply_date_range_filter,
    parse_production_dates,
    create_well_summary,
    get_data_path,
    get_available_well_types,
    generate_well_drilling_forecast,
    DATA_DIR,
)
from utils.helpers import sanitize_for_json, build_prod_vs_takeaway_from_sample_points
from utils.well_factory import (
    # High-level API
    create_wells_from_forecast,
    create_wells_from_forecast_async,
    # Config preparation
    prepare_configs_from_forecast,
    prepare_configs_parallel,
    prepare_well_config,
    # Validation
    validate_well_config,
    validate_configs_batch,
    # Batch creation
    create_wells_batch,
    create_wells_async,
    # Result types
    BatchCreationResult,
    WellCreationResult,
    FailedWellCreation,
    WellCreationError,
    # Constants
    PLAY_TYPE_TO_WELL_TYPE,
    get_well_type_defaults,
)

__all__ = [
    # Data loading
    "load_dim_data",
    "load_fact_data", 
    "load_and_merge_well_data",
    "count_wells_in_range",
    "apply_standard_filters",
    "apply_date_range_filter",
    "parse_production_dates",
    "create_well_summary",
    "get_data_path",
    "get_available_well_types",
    "generate_well_drilling_forecast",
    "DATA_DIR",
    # Helpers
    "sanitize_for_json",
    "build_prod_vs_takeaway_payload",
    # Well Factory - High-level API
    "create_wells_from_forecast",
    "create_wells_from_forecast_async",
    # Well Factory - Config preparation
    "prepare_configs_from_forecast",
    "prepare_configs_parallel",
    "prepare_well_config",
    # Well Factory - Validation
    "validate_well_config",
    "validate_configs_batch",
    # Well Factory - Batch creation
    "create_wells_batch",
    "create_wells_async",
    # Well Factory - Result types
    "BatchCreationResult",
    "WellCreationResult",
    "FailedWellCreation",
    "WellCreationError",
    # Well Factory - Constants
    "PLAY_TYPE_TO_WELL_TYPE",
    "get_well_type_defaults",
]
