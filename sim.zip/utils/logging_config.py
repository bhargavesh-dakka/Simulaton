"""
Standardized Logging Configuration for SimOxy Simulation Engine.

This module provides centralized logging setup to ensure consistent
logging format, levels, and handlers across all simulation components.

Usage:
    # At application startup (e.g., in api.py):
    from utils.logging_config import setup_logging
    setup_logging(level="INFO")
    
    # In each module:
    from utils.logging_config import get_logger
    logger = get_logger(__name__)
    
    logger.info("Simulation started with %d wells", num_wells)
    logger.warning("Well %s has low production", api_number)
    logger.error("Failed to load data: %s", error_msg)
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
from functools import wraps
import time


# =============================================================================
# DEFAULT CONFIGURATION
# =============================================================================

DEFAULT_LOG_FORMAT = (
    "[%(asctime)s] %(levelname)-8s [%(name)s:%(lineno)d] %(message)s"
)
DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFAULT_LOG_LEVEL = "INFO"

# Loggers to suppress (noisy third-party libraries)
SUPPRESSED_LOGGERS = [
    "mesa",
    "urllib3",
    "httpcore",
    "httpx",
    "asyncio",
]


# =============================================================================
# SETUP FUNCTIONS
# =============================================================================

def setup_logging(
    level: str = DEFAULT_LOG_LEVEL,
    log_file: Optional[str] = None,
    log_format: str = DEFAULT_LOG_FORMAT,
    date_format: str = DEFAULT_DATE_FORMAT,
    suppress_noisy: bool = True,
) -> None:
    """
    Configure logging for the simulation engine.
    
    This function should be called once at application startup, typically
    in the main entry point (api.py or similar).
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional path to log file. If None, logs only to console.
        log_format: Format string for log messages
        date_format: Format string for timestamps
        suppress_noisy: If True, suppress verbose third-party loggers
        
    Example:
        # Basic setup
        setup_logging(level="INFO")
        
        # With file logging
        setup_logging(level="DEBUG", log_file="logs/simulation.log")
    """
    # Convert string level to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create handlers
    handlers = []
    
    # Console handler (always enabled)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(
        logging.Formatter(log_format, datefmt=date_format)
    )
    handlers.append(console_handler)
    
    # File handler (optional)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(
            logging.Formatter(log_format, datefmt=date_format)
        )
        handlers.append(file_handler)
    
    # Configure root logger
    logging.basicConfig(
        level=numeric_level,
        format=log_format,
        datefmt=date_format,
        handlers=handlers,
        force=True,  # Override existing config
    )
    
    # Suppress noisy third-party loggers
    if suppress_noisy:
        for logger_name in SUPPRESSED_LOGGERS:
            logging.getLogger(logger_name).setLevel(logging.WARNING)
    
    # Log the configuration
    root_logger = logging.getLogger()
    root_logger.info(
        "Logging configured: level=%s, handlers=%d, log_file=%s",
        level,
        len(handlers),
        log_file or "None"
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a module.
    
    This is a convenience function that ensures consistent logger naming.
    
    Args:
        name: Typically __name__ of the calling module
        
    Returns:
        Configured logger instance
        
    Example:
        # In any module
        from utils.logging_config import get_logger
        logger = get_logger(__name__)
        
        logger.info("Processing %d wells", count)
    """
    return logging.getLogger(name)


# =============================================================================
# LOGGING DECORATORS
# =============================================================================

def log_execution_time(logger: Optional[logging.Logger] = None):
    """
    Decorator to log function execution time.
    
    Args:
        logger: Logger to use. If None, uses the module's logger.
        
    Example:
        @log_execution_time()
        def process_wells(configs):
            # ... processing logic
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = logging.getLogger(func.__module__)
            
            start_time = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                elapsed = time.perf_counter() - start_time
                logger.debug(
                    "%s completed in %.3f seconds",
                    func.__name__,
                    elapsed
                )
                return result
            except Exception as e:
                elapsed = time.perf_counter() - start_time
                logger.error(
                    "%s failed after %.3f seconds: %s",
                    func.__name__,
                    elapsed,
                    str(e)
                )
                raise
        return wrapper
    return decorator


def log_function_call(logger: Optional[logging.Logger] = None, level: int = logging.DEBUG):
    """
    Decorator to log function entry and exit.
    
    Args:
        logger: Logger to use. If None, uses the module's logger.
        level: Logging level for the messages
        
    Example:
        @log_function_call()
        def add_well(config):
            # ... add well logic
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = logging.getLogger(func.__module__)
            
            # Log entry
            logger.log(level, "Entering %s", func.__name__)
            
            try:
                result = func(*args, **kwargs)
                logger.log(level, "Exiting %s (success)", func.__name__)
                return result
            except Exception as e:
                logger.log(
                    logging.ERROR,
                    "Exiting %s (exception: %s)",
                    func.__name__,
                    str(e)
                )
                raise
        return wrapper
    return decorator


# =============================================================================
# SPECIALIZED LOGGERS
# =============================================================================

class SimulationLogger:
    """
    Specialized logger for simulation-specific events.
    
    Provides convenient methods for logging common simulation events
    with consistent formatting.
    
    Example:
        sim_logger = SimulationLogger("simulation")
        sim_logger.log_well_created(api_number="12345", well_type="Shale Oil")
        sim_logger.log_step_completed(step=100, active_wells=50, production=10000)
    """
    
    def __init__(self, name: str):
        self._logger = logging.getLogger(name)
    
    def log_simulation_started(
        self,
        start_date: str,
        end_date: str,
        basin_name: str,
        num_wells: int,
    ) -> None:
        """Log simulation initialization."""
        self._logger.info(
            "Simulation started: basin=%s, period=%s to %s, wells=%d",
            basin_name,
            start_date,
            end_date,
            num_wells,
        )
    
    def log_simulation_completed(
        self,
        total_steps: int,
        total_production: float,
        duration_seconds: float,
    ) -> None:
        """Log simulation completion."""
        self._logger.info(
            "Simulation completed: steps=%d, total_production=%.0f bbl, "
            "duration=%.2f seconds",
            total_steps,
            total_production,
            duration_seconds,
        )
    
    def log_well_created(
        self,
        api_number: str,
        well_type: str,
        initial_production: Optional[float] = None,
    ) -> None:
        """Log well creation."""
        if initial_production:
            self._logger.debug(
                "Well created: api=%s, type=%s, qi=%.0f bbl/day",
                api_number,
                well_type,
                initial_production,
            )
        else:
            self._logger.debug(
                "Well created: api=%s, type=%s",
                api_number,
                well_type,
            )
    
    def log_well_shutdown(
        self,
        api_number: str,
        reason: str,
        cumulative_production: float,
    ) -> None:
        """Log well shutdown."""
        self._logger.info(
            "Well shutdown: api=%s, reason=%s, cumulative=%.0f bbl",
            api_number,
            reason,
            cumulative_production,
        )
    
    def log_step_completed(
        self,
        step: int,
        active_wells: int,
        daily_production: float,
        remaining_reserves: Optional[float] = None,
    ) -> None:
        """Log step completion (typically at intervals, not every step)."""
        if remaining_reserves is not None:
            self._logger.debug(
                "Step %d: active_wells=%d, daily_prod=%.0f bbl/day, "
                "remaining_reserves=%.0f bbl",
                step,
                active_wells,
                daily_production,
                remaining_reserves,
            )
        else:
            self._logger.debug(
                "Step %d: active_wells=%d, daily_prod=%.0f bbl/day",
                step,
                active_wells,
                daily_production,
            )
    
    def log_reserves_initialized(
        self,
        basin_name: str,
        remaining_reserves: float,
        effective_date: str,
    ) -> None:
        """Log reserves tracking initialization."""
        self._logger.info(
            "Reserves tracking activated: basin=%s, remaining=%.0f bbl, "
            "effective_date=%s",
            basin_name,
            remaining_reserves,
            effective_date,
        )
    
    def log_reserves_depleted(self, basin_name: str) -> None:
        """Log reserves depletion."""
        self._logger.warning(
            "Basin reserves depleted: %s",
            basin_name,
        )
    
    def log_constraint_exceeded(
        self,
        constraint_type: str,
        details: str,
    ) -> None:
        """Log constraint violation."""
        self._logger.warning(
            "Constraint exceeded: %s - %s",
            constraint_type,
            details,
        )
    
    def log_batch_operation(
        self,
        operation: str,
        total: int,
        succeeded: int,
        failed: int,
    ) -> None:
        """Log batch operation results."""
        self._logger.info(
            "Batch %s: total=%d, succeeded=%d, failed=%d (%.1f%% success)",
            operation,
            total,
            succeeded,
            failed,
            (succeeded / total * 100) if total > 0 else 0,
        )


# Create a default simulation logger
simulation_logger = SimulationLogger("simoxy.simulation")
