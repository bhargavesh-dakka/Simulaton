"""
Well Factory - Optimized batch well creation with error handling.

This module provides efficient batch creation of wells from forecast data,
with comprehensive validation, error handling, and async support.

COMPLIANCE: Uses centralized configuration for SimOxy Handbook compliance.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Tuple, TYPE_CHECKING
from concurrent.futures import ThreadPoolExecutor, as_completed

# Import centralized configuration
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.simulation_config import (
    WellType,
    DriveMechanism,
    WellConfiguration,
    CONSTANTS,
    PLAY_TYPE_TO_WELL_TYPE,
    get_well_type_defaults,
)
from utils.logging_config import get_logger, log_execution_time
from exceptions import WellValidationError, WellCreationError

if TYPE_CHECKING:
    from simulation.model import BasinModel

# Module logger
logger = get_logger(__name__)


# =============================================================================
# ERROR TYPES & RESULT CLASSES
# =============================================================================

class WellCreationErrorType(Enum):
    """Categorized error types for well creation failures."""
    VALIDATION_FAILED = "validation_failed"
    INVALID_WELL_TYPE = "invalid_well_type"
    INVALID_DATES = "invalid_dates"
    INVALID_PARAMETERS = "invalid_parameters"
    CONSTRAINT_EXCEEDED = "drilling_constraint_exceeded"
    MODEL_ERROR = "model_error"
    UNKNOWN_ERROR = "unknown_error"


@dataclass
class FailedWellCreation:
    """
    Details of a failed well creation attempt.
    
    Attributes:
        config: The configuration that failed
        error_type: Category of the error
        error_message: Human-readable error description
        retry_possible: Whether retrying might succeed
    """
    config: Dict[str, Any]
    error_type: WellCreationErrorType
    error_message: str
    retry_possible: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API responses."""
        return {
            "config": self.config,
            "error_type": self.error_type.value,
            "error_message": self.error_message,
            "retry_possible": self.retry_possible,
        }


@dataclass
class WellCreationResult:
    """
    Result of a single well creation attempt.
    
    Attributes:
        success: Whether creation succeeded
        well_config: The configuration used
        error: Error details if creation failed
        api_number: API number of created well if successful
    """
    success: bool
    well_config: Dict[str, Any]
    error: Optional[FailedWellCreation] = None
    api_number: Optional[str] = None


@dataclass
class BatchCreationResult:
    """
    Aggregated result of batch well creation.
    
    Attributes:
        total_attempted: Number of wells attempted
        total_created: Number successfully created
        total_failed: Number that failed
        created_api_numbers: List of created API numbers
        failures: List of creation failures
        validation_errors: List of validation failures
    """
    total_attempted: int = 0
    total_created: int = 0
    total_failed: int = 0
    created_api_numbers: List[str] = field(default_factory=list)
    failures: List[FailedWellCreation] = field(default_factory=list)
    validation_errors: List[FailedWellCreation] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API responses."""
        return {
            "total_attempted": self.total_attempted,
            "total_created": self.total_created,
            "total_failed": self.total_failed,
            "success_rate": (
                self.total_created / self.total_attempted * 100
            ) if self.total_attempted > 0 else 0,
            "created_api_numbers_sample": self.created_api_numbers[:10],
            "failures_sample": [f.to_dict() for f in self.failures[:10]],
            "validation_errors_count": len(self.validation_errors),
        }


# =============================================================================
# VALIDATION FUNCTIONS
# =============================================================================

def validate_well_config(
    config: Dict[str, Any], 
    model: "BasinModel"
) -> Optional[FailedWellCreation]:
    """
    Validate a single well configuration before creation.
    
    Args:
        config: Well configuration dictionary
        model: BasinModel instance for context
        
    Returns:
        FailedWellCreation if validation fails, None if valid
    """
    # Check required fields
    required_fields = {"well_type", "production_start_date"}
    missing = required_fields - set(config.keys())
    if missing:
        return FailedWellCreation(
            config=config,
            error_type=WellCreationErrorType.VALIDATION_FAILED,
            error_message=f"Missing required fields: {missing}",
            retry_possible=True
        )
    
    # Validate well_type
    well_type = config.get("well_type")
    valid_well_types = WellType.values()
    if well_type not in valid_well_types:
        return FailedWellCreation(
            config=config,
            error_type=WellCreationErrorType.INVALID_WELL_TYPE,
            error_message=f"Invalid well_type '{well_type}'. Valid types: {sorted(valid_well_types)}",
            retry_possible=True
        )
    
    # Validate b_factor range (0-2)
    b_factor = config.get("b_factor", 0.5)
    if b_factor < 0 or b_factor > 2:
        return FailedWellCreation(
            config=config,
            error_type=WellCreationErrorType.INVALID_PARAMETERS,
            error_message=f"b_factor {b_factor} out of valid range (0-2)",
            retry_possible=True
        )
    
    # Validate nominal_decline_rate (must be positive)
    decline_rate = config.get("nominal_decline_rate", 0.05)
    if decline_rate <= 0:
        return FailedWellCreation(
            config=config,
            error_type=WellCreationErrorType.INVALID_PARAMETERS,
            error_message=f"nominal_decline_rate must be positive, got {decline_rate}",
            retry_possible=True
        )
    
    # Validate initial_production (must be positive)
    initial_prod = config.get("initial_production", 100)
    if initial_prod <= 0:
        return FailedWellCreation(
            config=config,
            error_type=WellCreationErrorType.INVALID_PARAMETERS,
            error_message=f"initial_production must be positive, got {initial_prod}",
            retry_possible=True
        )
    
    # Validate production_start_date
    prod_start = config.get("production_start_date")
    if prod_start is not None:
        if not isinstance(prod_start, datetime):
            return FailedWellCreation(
                config=config,
                error_type=WellCreationErrorType.INVALID_DATES,
                error_message=f"production_start_date must be datetime, got {type(prod_start)}",
                retry_possible=True
            )
    
    # Validate offshore wells must be conventional
    location = config.get("location", "")
    if isinstance(location, str) and "offshore" in location.lower():
        if "conventional" not in well_type.lower():
            return FailedWellCreation(
                config=config,
                error_type=WellCreationErrorType.VALIDATION_FAILED,
                error_message="Offshore wells must be Conventional type (Handbook compliance)",
                retry_possible=True
            )
    
    return None  # Valid


def validate_configs_batch(
    configs: List[Dict[str, Any]], 
    model: "BasinModel"
) -> Tuple[List[Dict[str, Any]], List[FailedWellCreation]]:
    """
    Validate a batch of well configurations.
    
    Args:
        configs: List of well configurations
        model: BasinModel instance
        
    Returns:
        Tuple of (valid_configs, validation_errors)
    """
    valid_configs = []
    errors = []
    
    for config in configs:
        error = validate_well_config(config, model)
        if error:
            errors.append(error)
        else:
            valid_configs.append(config)
    
    if errors:
        logger.warning(
            "Batch validation: %d of %d configs failed validation",
            len(errors), len(configs)
        )
    
    return valid_configs, errors


# =============================================================================
# CONFIG PREPARATION FUNCTIONS
# =============================================================================

def map_play_type_to_well_type(play_type: str) -> str:
    """
    Map forecast play_type to WellAgent well_type.
    
    Args:
        play_type: Play type string from forecast data
        
    Returns:
        Corresponding WellAgent well_type
    """
    well_type = PLAY_TYPE_TO_WELL_TYPE.get(play_type.upper())
    if well_type is None:
        logger.warning(
            "Unknown play_type '%s', defaulting to '%s'",
            play_type, WellType.CONVENTIONAL_ONSHORE.value
        )
        return WellType.CONVENTIONAL_ONSHORE.value
    return well_type


def get_default_parameters(well_type: str) -> Dict[str, Any]:
    """
    Get default parameters for a well type.
    
    Args:
        well_type: Well type string
        
    Returns:
        Dictionary of default parameters
    """
    return get_well_type_defaults(well_type).copy()


def prepare_well_config(
    year: int,
    month: int,
    play_type: str,
    api_number: int,
    multiplier: float = 1.0,
    base_config: Optional[Dict[str, Any]] = None,
    model_basin: str = "PERMIAN BASIN"
) -> Dict[str, Any]:
    """
    Prepare a single well configuration from forecast data.
    
    Args:
        year: Forecast year
        month: Forecast month
        play_type: Play type from forecast
        api_number: Unique API number for the well
        multiplier: Production multiplier from scenario
        base_config: Optional base configuration to merge
        model_basin: Basin name from model
        
    Returns:
        Complete well configuration dictionary
    """
    well_type = map_play_type_to_well_type(play_type)
    defaults = get_default_parameters(well_type)
    
    config = {
        "api_number": api_number,
        "well_type": well_type,
        "production_start_date": datetime(year, month, 1),
        "initial_production": defaults["initial_production"] * multiplier,
        "b_factor": defaults["b_factor"],
        "nominal_decline_rate": defaults["nominal_decline_rate"],
        "drive_mechanism": defaults["drive_mechanism"],
        "configuration": defaults["configuration"],
        "decline_type": "Hyperbolic",
        "basin": model_basin,
        "location": model_basin,
        "operational_status": "Active",
        "ecr_enabled": False,
        "actual_production_data": {},
        "is_new": True,  # Forecast wells are new wells
    }
    
    # Override with base_config if provided
    if base_config:
        for key, value in base_config.items():
            if value is not None and key != "api_number":
                config[key] = value
    
    return config


def prepare_configs_from_forecast(
    forecast_results: List[Dict[str, Any]],
    base_api_start: int,
    base_config: Optional[Dict[str, Any]] = None,
    model_basin: str = "PERMIAN BASIN"
) -> List[Dict[str, Any]]:
    """
    Prepare all well configurations from forecast results.
    
    This is the main function to convert forecast data into well configs.
    
    Args:
        forecast_results: List of forecast dictionaries with year, month, play_type, wells_count
        base_api_start: Starting API number for generated wells
        base_config: Optional base configuration to apply to all wells
        model_basin: Basin name from model
        
    Returns:
        List of well configuration dictionaries
    """
    configs = []
    api_counter = base_api_start
    
    for forecast in forecast_results:
        wells_count = forecast.get("wells_count", 0)
        if wells_count <= 0:
            continue
            
        year = forecast["year"]
        month = forecast["month"]
        play_type = forecast["play_type"]
        multiplier = forecast.get("multiplier", 1.0)
        
        for _ in range(wells_count):
            config = prepare_well_config(
                year=year,
                month=month,
                play_type=play_type,
                api_number=api_counter,
                multiplier=multiplier,
                base_config=base_config,
                model_basin=model_basin
            )
            configs.append(config)
            api_counter += 1
    
    logger.debug(
        "Prepared %d well configs from %d forecast entries",
        len(configs), len(forecast_results)
    )
    
    return configs


@log_execution_time()
def prepare_configs_parallel(
    forecast_results: List[Dict[str, Any]],
    base_api_start: int,
    base_config: Optional[Dict[str, Any]] = None,
    model_basin: str = "PERMIAN BASIN",
    max_workers: int = 4,
    chunk_size: int = 100
) -> List[Dict[str, Any]]:
    """
    Prepare well configurations using parallel processing.
    
    Useful for very large forecast datasets.
    
    Args:
        forecast_results: List of forecast dictionaries
        base_api_start: Starting API number
        base_config: Optional base configuration
        model_basin: Basin name
        max_workers: Max thread pool workers
        chunk_size: Forecasts per chunk
        
    Returns:
        List of well configuration dictionaries
    """
    if len(forecast_results) <= chunk_size:
        return prepare_configs_from_forecast(
            forecast_results, base_api_start, base_config, model_basin
        )
    
    # Split into chunks
    chunks = []
    current_api = base_api_start
    
    for i in range(0, len(forecast_results), chunk_size):
        chunk = forecast_results[i:i + chunk_size]
        wells_in_chunk = sum(f.get("wells_count", 0) for f in chunk)
        chunks.append((chunk, current_api))
        current_api += wells_in_chunk
    
    all_configs = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                prepare_configs_from_forecast,
                chunk,
                api_start,
                base_config,
                model_basin
            ): i
            for i, (chunk, api_start) in enumerate(chunks)
        }
        
        results_by_index = {}
        for future in as_completed(futures):
            index = futures[future]
            try:
                results_by_index[index] = future.result()
            except Exception as e:
                logger.error("Chunk %d failed: %s", index, e)
                results_by_index[index] = []
        
        for i in range(len(chunks)):
            all_configs.extend(results_by_index.get(i, []))
    
    return all_configs


# =============================================================================
# WELL CREATION FUNCTIONS
# =============================================================================

@log_execution_time()
def create_wells_batch(
    configs: List[Dict[str, Any]],
    model: "BasinModel",
    skip_validation: bool = False
) -> BatchCreationResult:
    """
    Create wells in batch with error handling.
    
    Args:
        configs: List of well configurations
        model: BasinModel instance
        skip_validation: If True, skip pre-validation (configs already validated)
        
    Returns:
        BatchCreationResult with success/failure details
    """
    result = BatchCreationResult(total_attempted=len(configs))
    
    # Phase 1: Validate all configs
    if not skip_validation:
        valid_configs, validation_errors = validate_configs_batch(configs, model)
        result.validation_errors = validation_errors
        result.total_failed += len(validation_errors)
    else:
        valid_configs = configs
    
    # Phase 2: Create wells
    for config in valid_configs:
        try:
            well = model.add_well(**config)
            result.total_created += 1
            result.created_api_numbers.append(
                str(config.get("api_number", well.unique_id))
            )
        except ValueError as e:
            result.failures.append(FailedWellCreation(
                config=config,
                error_type=WellCreationErrorType.VALIDATION_FAILED,
                error_message=str(e),
                retry_possible=True
            ))
            result.total_failed += 1
        except TypeError as e:
            result.failures.append(FailedWellCreation(
                config=config,
                error_type=WellCreationErrorType.INVALID_PARAMETERS,
                error_message=str(e),
                retry_possible=True
            ))
            result.total_failed += 1
        except Exception as e:
            logger.error("Unexpected error creating well: %s", e)
            result.failures.append(FailedWellCreation(
                config=config,
                error_type=WellCreationErrorType.MODEL_ERROR,
                error_message=str(e),
                retry_possible=False
            ))
            result.total_failed += 1
    
    logger.info(
        "Batch creation: %d created, %d failed of %d attempted (%.1f%% success)",
        result.total_created,
        result.total_failed,
        result.total_attempted,
        (result.total_created / result.total_attempted * 100) if result.total_attempted > 0 else 0
    )
    
    return result


async def create_wells_async(
    configs: List[Dict[str, Any]],
    model: "BasinModel",
    batch_size: int = 100,
    yield_interval: int = 50,
    progress_callback=None
) -> BatchCreationResult:
    """
    Create wells asynchronously with progress reporting.
    
    Yields to event loop periodically to maintain API responsiveness.
    
    Args:
        configs: List of well configurations
        model: BasinModel instance
        batch_size: Wells to process per batch
        yield_interval: Yield to event loop every N wells
        progress_callback: Optional async callback for progress updates
        
    Returns:
        BatchCreationResult with success/failure details
    """
    result = BatchCreationResult(total_attempted=len(configs))
    
    # Pre-validate all configs
    valid_configs, validation_errors = validate_configs_batch(configs, model)
    result.validation_errors = validation_errors
    result.total_failed += len(validation_errors)
    
    # Create wells in batches
    for i in range(0, len(valid_configs), batch_size):
        batch = valid_configs[i:i + batch_size]
        
        for j, config in enumerate(batch):
            try:
                well = model.add_well(**config)
                result.total_created += 1
                result.created_api_numbers.append(
                    str(config.get("api_number", well.unique_id))
                )
            except Exception as e:
                error_type = (
                    WellCreationErrorType.VALIDATION_FAILED 
                    if isinstance(e, ValueError) 
                    else WellCreationErrorType.MODEL_ERROR
                )
                result.failures.append(FailedWellCreation(
                    config=config,
                    error_type=error_type,
                    error_message=str(e),
                    retry_possible=isinstance(e, (ValueError, TypeError))
                ))
                result.total_failed += 1
            
            # Yield to event loop periodically
            if (i + j) % yield_interval == 0:
                await asyncio.sleep(0)
                
                if progress_callback:
                    progress = {
                        "processed": i + j + 1,
                        "total": len(valid_configs),
                        "created": result.total_created,
                        "failed": result.total_failed,
                    }
                    await progress_callback(progress)
    
    return result


# =============================================================================
# HIGH-LEVEL API
# =============================================================================

@log_execution_time()
def create_wells_from_forecast(
    forecast_results: List[Dict[str, Any]],
    model: "BasinModel",
    base_api_start: int = CONSTANTS.DEFAULT_API_START,
    base_config: Optional[Dict[str, Any]] = None,
    parallel_prep: bool = False,
    max_workers: int = 4
) -> BatchCreationResult:
    """
    High-level function to create wells from forecast data.
    
    This is the main entry point for batch well creation.
    
    Args:
        forecast_results: Forecast data from generate_well_drilling_forecast()
        model: BasinModel instance
        base_api_start: Starting API number for new wells
        base_config: Optional configuration to apply to all wells
        parallel_prep: Use parallel config preparation
        max_workers: Workers for parallel preparation
        
    Returns:
        BatchCreationResult with complete success/failure information
    """
    logger.info(
        "Creating wells from forecast: %d forecast entries, starting API=%d",
        len(forecast_results), base_api_start
    )
    
    # Phase 1: Prepare configs
    if parallel_prep and len(forecast_results) > 100:
        configs = prepare_configs_parallel(
            forecast_results=forecast_results,
            base_api_start=base_api_start,
            base_config=base_config,
            model_basin=getattr(model, "basin_name", "PERMIAN BASIN"),
            max_workers=max_workers
        )
    else:
        configs = prepare_configs_from_forecast(
            forecast_results=forecast_results,
            base_api_start=base_api_start,
            base_config=base_config,
            model_basin=getattr(model, "basin_name", "PERMIAN BASIN")
        )
    
    # Phase 2: Create wells
    return create_wells_batch(configs, model)


async def create_wells_from_forecast_async(
    forecast_results: List[Dict[str, Any]],
    model: "BasinModel",
    base_api_start: int = CONSTANTS.DEFAULT_API_START,
    base_config: Optional[Dict[str, Any]] = None,
    batch_size: int = 100,
    progress_callback=None
) -> BatchCreationResult:
    """
    Async version of create_wells_from_forecast.
    
    Args:
        forecast_results: Forecast data
        model: BasinModel instance
        base_api_start: Starting API number
        base_config: Optional base configuration
        batch_size: Wells per batch
        progress_callback: Optional async progress callback
        
    Returns:
        BatchCreationResult
    """
    # Prepare configs (synchronous - CPU bound)
    configs = prepare_configs_from_forecast(
        forecast_results=forecast_results,
        base_api_start=base_api_start,
        base_config=base_config,
        model_basin=getattr(model, "basin_name", "PERMIAN BASIN")
    )
    
    # Create wells asynchronously
    return await create_wells_async(
        configs=configs,
        model=model,
        batch_size=batch_size,
        progress_callback=progress_callback
    )
