"""
General helper utilities for SimEng simulation engine.

This module contains miscellaneous utility functions that don't fit
into other specialized modules.
"""

import math
from typing import Any, Dict, List
from datetime import timedelta
from utils.logging_config import get_logger

logger = get_logger(__name__)


def sanitize_for_json(obj: Any) -> Any:
    """Recursively replace NaN/Inf values with None for valid JSON serialization.
    
    Args:
        obj: Any Python object (dict, list, float, etc.)
        
    Returns:
        Sanitized object safe for JSON serialization
    """
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_for_json(v) for v in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    return obj


def build_prod_vs_takeaway_from_sample_points(runner, sample_points: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Build production vs takeaway dataset from sample points (streamed data).
    
    Args:
        runner: SimulationRunner instance (for pipeline capacity)
        sample_points: List of sample data points from the simulation stream
        
    Returns:
        List of production vs takeaway data points formatted for the chart
    """
    logger.info(f"🔍 build_prod_vs_takeaway called with {len(sample_points) if sample_points else 0} sample points")
    
    if not runner or not sample_points:
        logger.warning(f"⚠️ Returning empty - runner: {runner is not None}, sample_points: {len(sample_points) if sample_points else 0}")
        return []

    pipeline_capacity = runner.model.pipeline.max_capacity if hasattr(runner, 'model') and hasattr(runner.model, 'pipeline') else 0
    logger.info(f"🔍 Pipeline capacity: {pipeline_capacity}")
    
    result = []
    for point in sample_points:
        daily_prod = point.get("daily_production", 0.0)
        
        # For now, simplified: assume all production is transported (no pipeline constraints in current model)
        # In future, this should read actual pipeline_transported from the model
        transported = min(daily_prod, pipeline_capacity)
        gap = max(0, daily_prod - pipeline_capacity)
        
        result.append({
            "date": point.get("date"),
            "daily_production": float(daily_prod),
            "potential_production": float(daily_prod),  # Simplified: use actual as potential for now
            "pipeline_capacity": float(pipeline_capacity),
            "pipeline_transported": float(transported),
            "pipeline_utilization_pct": (transported / pipeline_capacity * 100) if pipeline_capacity > 0 else 0,
            "gap": float(gap),
            "active_wells": int(point.get("active_wells", 0)),
        })
    
    logger.info(f"✅ Built {len(result)} production_vs_takeaway points")
    return result

