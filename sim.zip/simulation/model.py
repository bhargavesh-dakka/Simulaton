
from __future__ import annotations

import math
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Any, TYPE_CHECKING

import pandas as pd
from mesa import Model
from mesa.time import BaseScheduler
from mesa.datacollection import DataCollector

# Import centralized configuration
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.simulation_config import (
    WellType,
    CONSTANTS,
    RefineryProduct,
    REFINERY_PRODUCTS,
    CRUDE_GRADE_TO_REFINERY_GRADE,
)
from utils.logging_config import get_logger, SimulationLogger
from exceptions import (
    DataLoadError,
    ReserveDepletionError,
)
from .agents import WellAgent, PipelineAgent, RefineryAgent

if TYPE_CHECKING:
    pass

# Module logger
logger = get_logger(__name__)
sim_logger = SimulationLogger(__name__)


def load_grade_splits(market_center: str) -> Dict[str, float]:
    """
    Load crude grade split percentages for a market center from grade_data.csv.
    
    Args:
        market_center: The market center name (e.g., 'Houston')
        
    Returns:
        Dict with keys: hSour, hSweet, mSour, mSweet, lSour, lSweet
        Values are percentages (0-100). Missing grades default to 0.
    """
    # Default structure with all grades at 0
    grade_splits = {
        "hSour": 0.0,   # Heavy Sour
        "hSweet": 0.0,  # Heavy Sweet
        "mSour": 0.0,   # Medium Sour
        "mSweet": 0.0,  # Medium Sweet
        "lSour": 0.0,   # Light Sour
        "lSweet": 0.0,  # Light Sweet
    }
    
    # Mapping from CSV crude_quality to our keys
    grade_mapping = {
        "Heavy Sour": "hSour",
        "Heavy Sweet": "hSweet",
        "Medium Sour": "mSour",
        "Medium Sweet": "mSweet",
        "Light Sour": "lSour",
        "Light Sweet": "lSweet",
    }
    
    try:
        possible_paths = [
            Path(__file__).parent.parent / "data" / "grade" / "grade_data.csv",
            Path("data/grade/grade_data.csv"),
            Path("./data/grade/grade_data.csv"),
        ]
        
        grade_path = None
        for p in possible_paths:
            if p.exists():
                grade_path = p
                break
        
        if grade_path is None:
            logger.warning("grade_data.csv not found, using default splits")
            return grade_splits
        
        df = pd.read_csv(grade_path)
        
        # Filter for the market center (case-insensitive)
        df['market_center_lower'] = df['market_center'].astype(str).str.lower().str.strip()
        market_center_lower = market_center.lower().strip()
        
        filtered = df[df['market_center_lower'] == market_center_lower]
        
        if filtered.empty:
            logger.info(
                "No grade data found for market_center='%s', using defaults",
                market_center
            )
            return grade_splits
        
        # Parse the grade data
        for _, row in filtered.iterrows():
            crude_quality = str(row.get('crude_quality', '')).strip()
            percentage = float(row.get('percentage', 0))
            
            if crude_quality in grade_mapping:
                key = grade_mapping[crude_quality]
                grade_splits[key] = percentage
        
        logger.info(
            "Loaded grade splits for %s: %s",
            market_center, grade_splits
        )
        
        return grade_splits
        
    except Exception as e:
        logger.error("Error loading grade data: %s", e)
        return grade_splits


def load_reserves_data(market_center: str, country: str = None) -> Optional[Dict[str, Any]]:
    """
    Load reserves data from CSV for a given market center.
    
    Args:
        market_center: The market center name (e.g., 'Houston')
        country: Optional country filter (e.g., 'United States')
        
    Returns:
        Dict with reserves data if found, None otherwise.
        Keys: crude_remaining_pp_bbl, crude_recoverable_pp_bbl, crude_cumul_prod_bbl,
              date_of_last_db_update, date_of_last_refresh, basin_name, etc.
    """
    try:
        possible_paths = [
            Path(__file__).parent.parent / "data" / "reserves" / "reserves.csv",
            Path("data/reserves/reserves.csv"),
            Path("./data/reserves/reserves.csv"),
        ]
        
        reserves_path = None
        for p in possible_paths:
            if p.exists():
                reserves_path = p
                break
        
        if reserves_path is None:
            logger.warning("reserves.csv not found in expected locations")
            return None
            
        df = pd.read_csv(reserves_path)
        columns = df.columns.tolist()
        
        if 'market_center' not in columns:
            logger.error("'market_center' column not found. Available: %s", columns)
            return None
            
        df['market_center_lower'] = df['market_center'].astype(str).str.lower().str.strip()
        market_center_lower = market_center.lower().strip()
        
        filtered = df[df['market_center_lower'] == market_center_lower]
        
        if country and not filtered.empty and 'country' in columns:
            filtered = filtered.copy()
            filtered['country_lower'] = filtered['country'].astype(str).str.lower().str.strip()
            country_lower = country.lower().strip()
            filtered = filtered[filtered['country_lower'] == country_lower]
        
        if filtered.empty:
            logger.info(
                "No reserves data found for market_center='%s', country='%s'",
                market_center, country
            )
            return None
        
        row = filtered.iloc[0]
        
        # Parse effective date
        date_str = str(row.get('date_of_last_db_update', ''))
        effective_date = None
        if date_str and date_str != 'nan':
            try:
                effective_date = datetime.strptime(date_str.split()[0], "%Y-%m-%d")
            except (ValueError, IndexError) as e:
                logger.warning("Could not parse date '%s': %s", date_str, e)
        
        reserves_data = {
            'country': str(row.get('country', '')),
            'market_center': str(row.get('market_center', '')),
            'basin_name': str(row.get('basin_name', '')),
            'main_parent_basin_name': str(row.get('main_parent_basin_name', '')),
            'crude_recoverable_pp_bbl': float(row.get('crude_recoverable_pp_bbl', 0) or 0),
            'crude_cumul_prod_bbl': float(row.get('crude_cumul_prod_bbl', 0) or 0),
            'crude_remaining_pp_bbl': float(row.get('crude_remaining_pp_bbl', 0) or 0),
            'oil_remaining_pp_bbl': float(row.get('oil_remaining_pp_bbl', 0) or 0),
            'cond_remaining_pp_bbl': float(row.get('cond_remaining_pp_bbl', 0) or 0),
            'effective_date': effective_date,
            'date_of_last_db_update': date_str,
            'date_of_last_refresh': str(row.get('date_of_last_refresh', '')),
        }
        
        logger.info(
            "Loaded reserves for %s: remaining=%.0f bbl, effective_date=%s",
            market_center,
            reserves_data['crude_remaining_pp_bbl'],
            effective_date
        )
        
        return reserves_data
        
    except Exception as e:
        logger.error("Error loading reserves data: %s", e, exc_info=True)
        return None


class MinimalStateCollector:
    """
    Minimal state collector that stores only t-1 state snapshot.
    
    Memory efficient: O(num_wells) instead of O(days × num_wells)
    
    Stores only essential state needed to derive computed values:
    - Basin: remaining_reserves, cumulative_production
    - Pipeline: total_transported, days_operational, max_capacity
    - Wells: days_on_production, cumulative_production, is_active, status
    
    All other values (daily_potential_production, recovery_factor, etc.) 
    can be derived from static parameters + minimal state.
    """
    
    def __init__(self):
        self.previous_state: Optional[Dict[str, Any]] = None
        self.current_state: Optional[Dict[str, Any]] = None
    
    def collect(self, model: "BasinModel") -> None:
        """Store minimal state snapshot - replaces previous with current."""
        self.previous_state = self.current_state
        
        reserves_tracking_active = (
            model._is_reserves_tracking_active() 
            if hasattr(model, '_is_reserves_tracking_active') 
            else False
        )
        
        self.current_state = {
            "current_date": model.current_date.isoformat(),
            "step": model.schedule.steps,
            "reserves_tracking_active": reserves_tracking_active,
            "reserves_effective_date": (
                model.reserves_effective_date.isoformat() 
                if model.reserves_effective_date 
                else None
            ),
            "basin": {
                "remaining_reserves": model.basin_remaining_reserves if reserves_tracking_active else None,
                "recovery_factor": model.basin_recovery_factor if reserves_tracking_active else None,
                "cumulative_production": model.basin_cumulative_production,
                "total_recoverable_resources": model.basin_total_recoverable_resources,
            },
            "pipeline": {
                "cumulative_transport": model.pipeline.cumulative_transport,
                "daily_transport": model.pipeline.daily_transport,
                "max_capacity": model.pipeline.max_capacity,
                "capacity_bpd": model.pipeline.max_capacity,
                "utilization_pct": model.pipeline.utilization_pct,
                "is_operational": model.pipeline.is_operational,
                "is_active": model.pipeline.is_active,
                # For backward compatibility
                "current_utilization": model.pipeline.daily_transport,
                "total_transported": model.pipeline.cumulative_transport,
                "utilization_percentage": model.pipeline.utilization_pct,
            },
            "wells": {
                w.unique_id: {
                    "days_on_production": w.days_on_production,
                    "cumulative_production": w.cumulative_production,
                    "daily_production": w.daily_production,
                    "daily_potential_production": w.daily_potential_production,
                    "is_active": w.is_active,
                    "status": w.status,
                    "production_end_date": (
                        w.production_end_date.isoformat() 
                        if w.production_end_date 
                        else None
                    ),
                }
                for w in model.basin_wells
            },
            "summary": {
                "total_daily_production": sum(w.daily_production for w in model.basin_wells),
                "total_potential_production": sum(w.daily_potential_production for w in model.basin_wells),
                "active_wells": sum(1 for w in model.basin_wells if w.is_active),
                "total_wells": len(model.basin_wells),
            }
        }
    
    def get_previous_state(self) -> Optional[Dict[str, Any]]:
        """Return t-1 state snapshot."""
        return self.previous_state
    
    def get_current_state(self) -> Optional[Dict[str, Any]]:
        """Return current state snapshot."""
        return self.current_state
    
    def get_model_vars_dataframe(self) -> pd.DataFrame:
        """Compatibility method - returns current state as single-row DataFrame."""
        if self.current_state is None:
            return pd.DataFrame()
        
        data = {
            "current_date": [self.current_state["current_date"]],
            "total_production": [self.current_state["basin"]["cumulative_production"]],
            "recovery_factor": [self.current_state["basin"]["recovery_factor"]],
            "daily_production": [self.current_state["summary"]["total_daily_production"]],
            "potential_production": [self.current_state["summary"]["total_potential_production"]],
            "num_active_wells": [self.current_state["summary"]["active_wells"]],
            "pipeline_utilization": [self.current_state["pipeline"]["current_utilization"]],
            "pipeline_capacity": [self.current_state["pipeline"]["max_capacity"]],
            "pipeline_utilization_pct": [
                (self.current_state["pipeline"]["current_utilization"] / 
                 self.current_state["pipeline"]["max_capacity"] * 100)
                if self.current_state["pipeline"]["max_capacity"] > 0 else 0
            ],
            "pipeline_operational": [self.current_state["pipeline"]["is_operational"]],
            "pipeline_total_transported": [self.current_state["pipeline"]["total_transported"]],
        }
        return pd.DataFrame(data)
    
    def get_agent_vars_dataframe(self) -> pd.DataFrame:
        """Compatibility method - returns well states as DataFrame."""
        if self.current_state is None:
            return pd.DataFrame()
        
        rows = []
        for well_id, well_state in self.current_state["wells"].items():
            rows.append({
                "AgentID": well_id,
                "Step": self.current_state["step"],
                "daily_production": well_state["daily_production"],
                "daily_potential_production": well_state["daily_potential_production"],
                "cumulative_production": well_state["cumulative_production"],
                "is_active": well_state["is_active"],
            })
        return pd.DataFrame(rows)


class QueueJsonDataCollector(MinimalStateCollector):
    """Deprecated: Use MinimalStateCollector instead. Kept for backwards compatibility."""
    
    def __init__(
        self, 
        max_steps: int = 2, 
        json_file_path: str = "simulation_history.json", 
        model_reporters=None, 
        agent_reporters=None
    ):
        super().__init__()
        logger.warning(
            "QueueJsonDataCollector is deprecated, use MinimalStateCollector instead"
        )


class BasinModel(Model):
    """
    Main Mesa model that orchestrates basin and well agents.
    
    Hierarchy: Country > Market Center > Basins > Wells
    
    COMPLIANCE: Uses daily timesteps by default, with strong guards for reserve
    depletion and consistent data collection.
    
    Attributes:
        start_date: Simulation start date
        end_date: Simulation end date
        current_date: Current simulation date
        basin_name: Name of the basin
        market_center: Market center name
        country: Country code
        basin_wells: List of WellAgent instances
        pipeline: PipelineAgent instance
        simulation_active: Whether simulation is running
    """

    def __init__(
        self,
        total_recoverable_resources: float,
        start_date: datetime,
        end_date: datetime,
        basin_name: str = "Permian Basin",
        market_center: str = "Permian",
        country: str = "US",
        basin_reserves: Optional[float] = None,
    ) -> None:
        """
        Initialize BasinModel.
        
        Args:
            total_recoverable_resources: Total recoverable oil (bbl)
            start_date: Simulation start date
            end_date: Simulation end date
            basin_name: Basin name
            market_center: Market center name
            country: Country code
            basin_reserves: Initial basin reserves (bbl)
        """
        super().__init__()
        self.start_date = start_date
        self.end_date = end_date
        self.current_date = start_date
        self.basin_name = basin_name
        self.market_center = market_center
        self.country = country

        # Determine which basins to include
        self.selected_basins = self._get_selected_basins(country, market_center, basin_name)

        # Initialize scheduler
        self.schedule = BaseScheduler(self)

        # Load reserves data from CSV
        self.reserves_data = load_reserves_data(market_center, country)
        self.reserves_available = self.reserves_data is not None
        self.reserves_effective_date = (
            self.reserves_data['effective_date'] 
            if self.reserves_data 
            else None
        )
        
        # Basin properties
        self.basin_country = country
        self.basin_market_center = market_center
        
        # Initialize cumulative production
        self.basin_cumulative_production = 0.0

        # Pipeline/refinery flow placeholders to avoid attribute errors before first allocation
        self.monthly_pipeline_input = 0.0
        self.daily_pipeline_input = 0.0
        self.pipeline_storage_buffer = 0.0
        self.pipeline_storage_days_used = 0
        # Max days storage buffer can be used before stress (align with websocket default of 7)
        self.pipeline_max_storage_days = 7
        # Collect per-day pipeline outputs (populated during step)
        self.pipeline_daily_outputs: List[Dict[str, Any]] = []
        
        if self.reserves_available:
            self.basin_total_recoverable_resources = self.reserves_data['crude_recoverable_pp_bbl']
            self._initial_remaining_reserves = self.reserves_data['crude_remaining_pp_bbl']
            self._historical_cumulative_production = self.reserves_data['crude_cumul_prod_bbl']
            
            # Will be set when tracking becomes active
            self.basin_remaining_reserves = None
            self.basin_recovery_factor = None
            
            logger.info(
                "Reserves data loaded: initial_remaining=%.0f bbl, effective_date=%s",
                self._initial_remaining_reserves,
                self.reserves_effective_date
            )
            logger.info(
                "Reserves tracking will activate on %s",
                self.reserves_effective_date
            )
        else:
            self.basin_total_recoverable_resources = None
            self.basin_remaining_reserves = None
            self.basin_recovery_factor = None
            self._initial_remaining_reserves = None
            self._historical_cumulative_production = None
            logger.warning(
                "No reserves data available for market_center='%s'. Reserves tracking disabled.",
                market_center
            )
        
        self.total_recoverable_resources = self.basin_total_recoverable_resources
        self._reserves_initialized = False
        
        self.basin_wells: List[WellAgent] = []

        # Initialize single default pipeline (can be replaced by load_pipelines)
        self.pipeline = PipelineAgent(
            unique_id=1,
            model=self,
            pipeline_id=1,
            pipeline_name=f"{market_center}_pipeline",
            market_center=market_center,
            basin=basin_name,
            capacity_bpd=CONSTANTS.DEFAULT_PIPELINE_CAPACITY,
        )
        self.schedule.add(self.pipeline)
        
        # Pipeline agents list (for multiple pipelines support)
        self.pipeline_agents: List[PipelineAgent] = [self.pipeline]

        # State collector
        self.datacollector = MinimalStateCollector()

        self.well_counter = 2
        self.simulation_active = True
 

        # Quarterly drilling constraints
        self.drilling_constraints = {
            WellType.CONVENTIONAL_OFFSHORE.value: CONSTANTS.DEFAULT_OFFSHORE_QUARTERLY_LIMIT,
            "default": float('inf')
        }
        self.quarterly_drilling_tracker: Dict[tuple, Dict[str, int]] = {}

        # Well tracking
        self.loaded_wells: Dict[str, WellAgent] = {}
        self.available_well_types: List[str] = []

        # Load grade splits for this market center
        self.grade_splits = load_grade_splits(market_center)
        
        # Monthly accumulator - tracks production by crude grade
        self.monthly_accumulator = self._create_empty_accumulator()
        self._current_month = start_date.month
        self._current_year = start_date.year

        # =============================================================
        # REFINERY INTEGRATION
        # =============================================================
        self.refinery_agents: List[RefineryAgent] = []
        self.refinery_mapping_df: Optional[pd.DataFrame] = None
        self.refinery_output_rows: List[Dict[str, Any]] = []
        
        # Monthly refinery accumulator - tracks yields by product
        self.monthly_refinery_yields = self._create_empty_refinery_accumulator()
        self.refinery_enabled = False  # Enable via load_refineries()

        # Collect initial state
        self.datacollector.collect(self)
        
        sim_logger.log_simulation_started(
            start_date=start_date.isoformat(),
            end_date=end_date.isoformat(),
            basin_name=basin_name,
            num_wells=0
        )

    def _get_selected_basins(
        self, 
        country: str, 
        market_center: str, 
        basin_name: str
    ) -> List[str]:
        """
        Determine which basins to include based on user selection.
        
        Args:
            country: Country code
            market_center: Market center name
            basin_name: Basin name or "All Basins"
            
        Returns:
            List of basin names to include
        """
        ALL_BASINS = ['GULF COAST BASIN', 'DEEP WATER GULF OF MEXICO BASIN']
        
        BASIN_MAPPING = {
            'UNITED STATES OF AMERICA': {
                'All Market Centers': ALL_BASINS,
                'Rest': ALL_BASINS,
                'Beaumont/Mont Belvieu': ALL_BASINS,
                'Louisiana Gulf Coast': ALL_BASINS,
                'Corpus Christi': ALL_BASINS,
                'Houston': ALL_BASINS,
            },
            'US': {
                'All Market Centers': ALL_BASINS,
                'Rest': ALL_BASINS,
                'Beaumont/Mont Belvieu': ALL_BASINS,
                'Louisiana Gulf Coast': ALL_BASINS,
                'Corpus Christi': ALL_BASINS,
                'Houston': ALL_BASINS,
            }
        }

        if basin_name == 'All Basins':
            if market_center == 'All Market Centers':
                return BASIN_MAPPING.get(country, {}).get('All Market Centers', ALL_BASINS)
            else:
                return BASIN_MAPPING.get(country, {}).get(market_center, ALL_BASINS)
        else:
            return [basin_name]

    def add_well(self, **kwargs) -> WellAgent:
        """
        Create and add a new WellAgent to the model.
        
        Args:
            **kwargs: Well configuration parameters
            
        Returns:
            Created WellAgent instance
        """
        kwargs.pop('unique_id', None)  # Remove to avoid conflicts with positional unique_id
        kwargs.setdefault("production_start_date", self.current_date)
        well = WellAgent(unique_id=self.well_counter, model=self, **kwargs)
        self.schedule.add(well)
        self.basin_wells.append(well)
        self.well_counter += 1
        
        logger.debug(
            "Well added: id=%d, type=%s, api=%s",
            well.unique_id,
            well.well_type,
            kwargs.get('api_number', 'N/A')
        )
        
        return well
    
    def _get_quarter(self, date: datetime) -> tuple:
        """Return (year, quarter) tuple for a given date."""
        quarter = (date.month - 1) // 3 + 1
        return (date.year, quarter)
    
    def _create_empty_accumulator(self) -> Dict[str, float]:
        """Create a fresh monthly accumulator with all grades at 0."""
        return {
            "hSour": 0.0,   # Heavy Sour
            "hSweet": 0.0,  # Heavy Sweet
            "mSour": 0.0,   # Medium Sour
            "mSweet": 0.0,  # Medium Sweet
            "lSour": 0.0,   # Light Sour
            "lSweet": 0.0,  # Light Sweet
        }
    
    def _get_grade_key(self, crude_grade: str) -> str:
        """
        Map crude_grade string to accumulator key.
        
        Args:
            crude_grade: Crude grade string (e.g., "Light Sweet", "Heavy Sour")
            
        Returns:
            Accumulator key (e.g., "lSweet", "hSour")
        """
        grade_mapping = {
            "Heavy Sour": "hSour",
            "Heavy Sweet": "hSweet",
            "Medium Sour": "mSour",
            "Medium Sweet": "mSweet",
            "Light Sour": "lSour",
            "Light Sweet": "lSweet",
        }
        return grade_mapping.get(crude_grade, "lSweet")  # Default to Light Sweet
    
    def _accumulate_production_by_grade(self, well: WellAgent, production: float) -> None:
        """
        Add production to the monthly accumulator based on well's crude grade.
        
        Args:
            well: WellAgent instance
            production: Production amount to accumulate (bbl)
        """
        if production <= 0:
            return
        
        grade_key = self._get_grade_key(well.crude_grade)
        self.monthly_accumulator[grade_key] += production
    
    def _check_and_reset_monthly_accumulator(self) -> None:
        """
        Check if we've moved to a new month. If so, process refineries and reset accumulator.
        """
        current_month = self.current_date.month
        current_year = self.current_date.year
        
        # Check if month changed
        if current_month != self._current_month or current_year != self._current_year:
            # Print the completed month's accumulator
            month_name = datetime(self._current_year, self._current_month, 1).strftime("%B %Y")
            
            print(f"\n{'='*60}")
            print(f"📊 MONTHLY PRODUCTION BY GRADE - {month_name}")
            print(f"   Market Center: {self.market_center}")
            print(f"{'='*60}")
            print(f"   Heavy Sour  (hSour):  {self.monthly_accumulator['hSour']:>15,.2f} bbl")
            print(f"   Heavy Sweet (hSweet): {self.monthly_accumulator['hSweet']:>15,.2f} bbl")
            print(f"   Medium Sour (mSour):  {self.monthly_accumulator['mSour']:>15,.2f} bbl")
            print(f"   Medium Sweet(mSweet): {self.monthly_accumulator['mSweet']:>15,.2f} bbl")
            print(f"   Light Sour  (lSour):  {self.monthly_accumulator['lSour']:>15,.2f} bbl")
            print(f"   Light Sweet (lSweet): {self.monthly_accumulator['lSweet']:>15,.2f} bbl")
            print(f"   {'─'*40}")
            total = sum(self.monthly_accumulator.values())
            print(f"   TOTAL:                {total:>15,.2f} bbl")
            print(f"{'='*60}\n")
            
            # REFINERY PROCESSING: Process monthly production through refineries
            if self.refinery_enabled:
                # Calculate total production for the completed month
                total_monthly_production = sum(self.monthly_accumulator.values())
                
                self._process_monthly_refinery_allocation()
                
                # Calculate total runs processed by refineries
                total_runs_processed = sum(r.runs_vol for r in self.refinery_agents)
                
                # Calculate remaining_Ready_to_export (monthly) - matching Final_refinery_runner
                # ready_to_export = total_production - total_runs
                self.monthly_pipeline_input = max(0.0, total_monthly_production - total_runs_processed)
                
                # Convert monthly to daily for pipeline allocation
                self.daily_pipeline_input = self._monthly_to_daily(
                    self.monthly_pipeline_input,
                    self._current_year,
                    self._current_month
                )
                
                # Reset pipeline storage at start of new month (matching notebook)
                self.pipeline_storage_buffer = 0.0
                self.pipeline_storage_days_used = 0
                # Reactivate pipelines
                if hasattr(self, 'pipeline_agents'):
                    for p in self.pipeline_agents:
                        p.is_active = True
                elif hasattr(self, 'pipeline'):
                    self.pipeline.is_active = True
                
                # Print refinery yields
                print(f"\n{'='*60}")
                print(f"🏭 REFINERY YIELDS - {month_name}")
                print(f"   Market Center: {self.market_center}")
                print(f"{'='*60}")
                for product, vol in self.monthly_refinery_yields.items():
                    print(f"   {product:<20}: {vol:>15,.2f} bbl")
                print(f"   {'─'*40}")
                total_yields = sum(self.monthly_refinery_yields.values())
                print(f"   TOTAL YIELDS:        {total_yields:>15,.2f} bbl")
                print(f"   TOTAL RUNS:          {total_runs_processed:>15,.2f} bbl")
                print(f"   READY TO EXPORT:     {self.monthly_pipeline_input:>15,.2f} bbl")
                print(f"   DAILY PIPELINE INPUT: {self.daily_pipeline_input:>15,.2f} bbl/day")
                print(f"{'='*60}\n")
            else:
                # If refinery not enabled, all production goes to pipeline
                total_monthly_production = sum(self.monthly_accumulator.values())
                self.monthly_pipeline_input = total_monthly_production
                self.daily_pipeline_input = self._monthly_to_daily(
                    self.monthly_pipeline_input,
                    self._current_year,
                    self._current_month
                )
            
            # Reset for the new month
            self.monthly_accumulator = self._create_empty_accumulator()
            self._current_month = current_month
            self._current_year = current_year
    
    def _check_drilling_constraint(self, well: WellAgent) -> bool:
        """
        Check if well can be drilled in current quarter.
        
        Args:
            well: WellAgent to check
            
        Returns:
            True if drilling is allowed, False if constraint exceeded
        """
        if not well.drilling_date or well.drilling_date > self.current_date:
            return True
        
        quarter_key = self._get_quarter(well.drilling_date)
        
        if quarter_key not in self.quarterly_drilling_tracker:
            self.quarterly_drilling_tracker[quarter_key] = {}
        
        constraint_limit = self.drilling_constraints.get(
            well.well_type,
            self.drilling_constraints["default"]
        )
        
        current_count = self.quarterly_drilling_tracker[quarter_key].get(well.well_type, 0)
        
        return current_count < constraint_limit

    def _load_wells_for_current_date(self) -> None:
        """No-op: Wells are added manually via API."""
        pass

    def _check_depletion(self) -> None:
        """
        Check for reserve depletion and shut down wells if needed.
        
        COMPLIANCE: If basin reserves are exhausted, wells stop producing
        but simulation continues until end_date.
        """
        if not self.reserves_available or self.basin_remaining_reserves is None:
            return
            
        if self.basin_remaining_reserves <= 0:
            for well in self.basin_wells:
                if well.is_active:
                    well.is_active = False
                    well.daily_production = 0.0
                    if not well.production_end_date:
                        well.production_end_date = self.current_date
            
            sim_logger.log_reserves_depleted(self.basin_name)
    
    def _is_reserves_tracking_active(self) -> bool:
        """
        Check if reserves tracking should be active for current date.
        
        Returns:
            True if tracking is active
        """
        if not self.reserves_available or self.reserves_effective_date is None:
            return False
        return self.current_date >= self.reserves_effective_date
    
    def _initialize_reserves_tracking(self) -> None:
        """
        Initialize remaining reserves when tracking becomes active.
        
        Called once when simulation date first reaches the reserves effective date.
        """
        if self._reserves_initialized:
            return
            
        if self._is_reserves_tracking_active() and self._initial_remaining_reserves is not None:
            self.basin_remaining_reserves = self._initial_remaining_reserves
            
            if self.basin_total_recoverable_resources and self.basin_total_recoverable_resources > 0:
                total_cumulative = self._historical_cumulative_production + self.basin_cumulative_production
                self.basin_recovery_factor = total_cumulative / self.basin_total_recoverable_resources
            
            self._reserves_initialized = True
            
            sim_logger.log_reserves_initialized(
                basin_name=self.basin_name,
                remaining_reserves=self.basin_remaining_reserves,
                effective_date=self.current_date.isoformat()
            )

    def step(self) -> None:
        """Advance one day in simulation time."""
        if not self.simulation_active or self.current_date >= self.end_date:
            self.simulation_active = False
            return

        self._load_wells_for_current_date()
        self._initialize_reserves_tracking()

        # Track drilling in current quarter
        quarter_key = self._get_quarter(self.current_date)
        for well in self.basin_wells:
            if well.drilling_date and well.drilling_date == self.current_date:
                if self._check_drilling_constraint(well):
                    if quarter_key not in self.quarterly_drilling_tracker:
                        self.quarterly_drilling_tracker[quarter_key] = {}

                    count = self.quarterly_drilling_tracker[quarter_key].get(well.well_type, 0)
                    self.quarterly_drilling_tracker[quarter_key][well.well_type] = count + 1
                else:
                    # Constraint exceeded - delay drilling
                    well.is_active = False
                    next_quarter_month = ((quarter_key[1] % 4) * 3) + 1
                    next_quarter_year = quarter_key[0] if quarter_key[1] < 4 else quarter_key[0] + 1
                    well.drilling_date = datetime(next_quarter_year, next_quarter_month, 1)

                    if well.production_start_date:
                        days_delay = 90
                        well.production_start_date = well.production_start_date + timedelta(days=days_delay)
                    
                    sim_logger.log_constraint_exceeded(
                        constraint_type="drilling",
                        details=f"Well {well.unique_id} drilling delayed to next quarter"
                    )

        # Execute all agent steps (pipeline.step() resets daily_transport at end of day)
        self.schedule.step()

        # Process production
        reserves_tracking_active = self._is_reserves_tracking_active()
        
        for well in self.basin_wells:
            if well.daily_potential_production > 0:
                # Get available capacity (max_capacity - current daily_transport)
                pipeline_remaining = self.pipeline.max_capacity - self.pipeline.daily_transport
                
                if reserves_tracking_active:
                    remaining_reserves = (
                        self.basin_remaining_reserves 
                        if self.basin_remaining_reserves is not None 
                        else float('inf')
                    )
                    actual_production = min(
                        well.daily_potential_production, 
                        remaining_reserves, 
                        pipeline_remaining
                    )
                else:
                    actual_production = min(well.daily_potential_production, pipeline_remaining)

                if actual_production > 0:
                    well.daily_production = actual_production
                    well.cumulative_production += actual_production

                    if self.basin_cumulative_production is None:
                        self.basin_cumulative_production = 0.0
                    self.basin_cumulative_production += actual_production

                    if reserves_tracking_active and self.basin_remaining_reserves is not None:
                        self.basin_remaining_reserves = max(
                            0.0, 
                            self.basin_remaining_reserves - actual_production
                        )

                    self.pipeline.add_flow(actual_production)
                    
                    # Accumulate production by crude grade
                    self._accumulate_production_by_grade(well, actual_production)
                else:
                    if pipeline_remaining <= 0:
                        well.daily_production = 0.0
                        well.status = "Choked"
                    else:
                        well.daily_production = 0.0
                        well.is_active = False
                        if not well.production_end_date:
                            well.production_end_date = self.current_date

        # Update recovery factor
        if reserves_tracking_active and self.basin_total_recoverable_resources and self.basin_total_recoverable_resources > 0:
            historical = self._historical_cumulative_production or 0.0
            total_cumulative = historical + self.basin_cumulative_production
            self.basin_recovery_factor = total_cumulative / self.basin_total_recoverable_resources

        # Allocate daily pipeline input from refinery (if refinery enabled)
        # This sets daily_transport for each pipeline via receive_flow()
        if self.refinery_enabled and self.daily_pipeline_input > 0:
            self._allocate_pipeline_daily_flow(self.daily_pipeline_input)
        
        # Collect pipeline daily output for ALL pipelines
        # IMPORTANT: This captures daily_transport BEFORE the NEXT day's step() resets it to 0
        # Each pipeline will have its own entry with:
        # - daily_input: Total input (same for all pipelines)
        # - daily_transport: Actual transported by THIS pipeline (different per pipeline)
        # - utilization_pct: Utilization for THIS pipeline
        if self.refinery_enabled:
            pipeline_outputs = self.get_all_pipelines_daily_output()
            if pipeline_outputs:
                self.pipeline_daily_outputs.extend(pipeline_outputs)
        
        self._check_depletion()
        self.datacollector.collect(self)
        self.current_date += timedelta(days=1)
        
        # Check for end of month and print/reset accumulator
        self._check_and_reset_monthly_accumulator()
 

    def get_simulation_state(self) -> Dict[str, Any]:
        """
        Get current simulation state.
        
        Returns:
            Dictionary containing complete simulation state
        """
        reserves_tracking_active = self._is_reserves_tracking_active()
        
        basin_state = {
            "name": self.basin_name,
            "country": self.basin_country,
            "market_center": self.basin_market_center,
            "total_recoverable_resources": (
                self.basin_total_recoverable_resources 
                if reserves_tracking_active 
                else None
            ),
            "remaining_reserves": (
                self.basin_remaining_reserves 
                if reserves_tracking_active 
                else None
            ),
            "recovery_factor": (
                self.basin_recovery_factor 
                if reserves_tracking_active 
                else None
            ),
            "cumulative_production": self.basin_cumulative_production,
            "num_wells": len(self.basin_wells),
            "wells": [w.get_state() for w in self.basin_wells],
            "reserves_available": self.reserves_available,
            "reserves_effective_date": (
                self.reserves_effective_date.isoformat() 
                if self.reserves_effective_date 
                else None
            ),
            "reserves_tracking_active": reserves_tracking_active,
        }
        
        return {
            "current_date": self.current_date.isoformat(),
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "days_remaining": max(0, (self.end_date - self.current_date).days),
            "simulation_active": self.simulation_active,
            "basin": basin_state,
            "pipeline": self.pipeline.get_state(),
            "monthly_accumulator": self.get_monthly_accumulator_state(),
            "refinery": self.get_refinery_state() if self.refinery_enabled else {"enabled": False},
        }
    
    def get_monthly_accumulator_state(self) -> Dict[str, Any]:
        """
        Get the current monthly accumulator state.
        
        Returns:
            Dictionary with accumulator values and metadata
        """
        return {
            "month": self._current_month,
            "year": self._current_year,
            "month_name": datetime(self._current_year, self._current_month, 1).strftime("%B %Y"),
            "market_center": self.market_center,
            "grade_splits_config": self.grade_splits,
            "accumulated": dict(self.monthly_accumulator),
            "total": sum(self.monthly_accumulator.values()),
        }

    def get_production_history(self) -> Dict[str, Any]:
        """
        Return current and previous state from minimal state collector.
        
        Returns:
            Dictionary with current_state, previous_state, and compatibility data
        """
        current_state = self.datacollector.get_current_state()
        previous_state = self.datacollector.get_previous_state()
        
        return {
            "current_state": current_state,
            "previous_state": previous_state,
            "model_data": self._state_to_model_dict(current_state) if current_state else {},
            "agent_data": self._state_to_agent_dict(current_state) if current_state else {},
        }
    
    def _state_to_model_dict(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Convert minimal state to model data dict format."""
        if not state:
            return {}
        return {
            "current_date": {0: state["current_date"]},
            "total_production": {0: state["basin"]["cumulative_production"]},
            "recovery_factor": {0: state["basin"]["recovery_factor"]},
            "daily_production": {0: state["summary"]["total_daily_production"]},
            "potential_production": {0: state["summary"]["total_potential_production"]},
            "num_active_wells": {0: state["summary"]["active_wells"]},
            "pipeline_utilization": {0: state["pipeline"]["current_utilization"]},
            "pipeline_capacity": {0: state["pipeline"]["max_capacity"]},
            "pipeline_utilization_pct": {0: (
                state["pipeline"]["current_utilization"] / state["pipeline"]["max_capacity"] * 100
            ) if state["pipeline"]["max_capacity"] > 0 else 0},
            "pipeline_operational": {0: state["pipeline"]["is_operational"]},
            "pipeline_total_transported": {0: state["pipeline"]["total_transported"]},
        }
    
    def _state_to_agent_dict(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Convert minimal state to agent data dict format."""
        if not state or "wells" not in state:
            return {}
        
        result = {
            "daily_production": {},
            "daily_potential_production": {},
            "cumulative_production": {},
            "is_active": {},
        }
        
        for i, (well_id, well_state) in enumerate(state["wells"].items()):
            result["daily_production"][i] = well_state["daily_production"]
            result["daily_potential_production"][i] = well_state["daily_potential_production"]
            result["cumulative_production"][i] = well_state["cumulative_production"]
            result["is_active"][i] = well_state["is_active"]
        
        return result

    # =============================================================================
    # REFINERY INTEGRATION METHODS
    # =============================================================================

    def _create_empty_refinery_accumulator(self) -> Dict[str, float]:
        """Create a fresh refinery yield accumulator with all products at 0."""
        return {product: 0.0 for product in REFINERY_PRODUCTS}

    def load_refineries(
        self,
        capacity_df: pd.DataFrame,
        mapping_df: Optional[pd.DataFrame] = None
    ) -> int:
        """
        Load refinery agents from capacity data.
        
        Args:
            capacity_df: DataFrame with refinery capacity data
            mapping_df: Optional DataFrame with yield conversion mapping
            
        Returns:
            Number of refineries loaded
        """
        self.refinery_mapping_df = mapping_df
        
        # Get unique refineries (one per refinery_id + configuration combo)
        unique_refineries = capacity_df.groupby([
            "refinery_id", "refinery_name", "basin", "configuration_name"
        ]).first().reset_index()
        
        loaded_count = 0
        for _, row in unique_refineries.iterrows():
            refinery = RefineryAgent(
                unique_id=self.well_counter,
                model=self,
                refinery_id=str(row.get("refinery_id", f"REF_{loaded_count}")),
                refinery_name=str(row.get("refinery_name", "Unknown")),
                basin=str(row.get("basin", self.basin_name)),
                configuration=str(row.get("configuration_name", "Simple Distillation")),
                effective_capacity=float(row.get("effective_capacity", 100000)),
                weight=float(row.get("weight", row.get("effective_capacity", 100000))),
                mapping_df=mapping_df,
            )
            self.schedule.add(refinery)
            self.refinery_agents.append(refinery)
            self.well_counter += 1
            loaded_count += 1
        
        self.refinery_enabled = loaded_count > 0
        
        logger.info(
            "Loaded %d refineries for market_center=%s",
            loaded_count, self.market_center
        )
        
        return loaded_count
    
    def load_pipelines(
        self,
        pipeline_df: pd.DataFrame
    ) -> int:
        """
        Load pipeline agents from pipeline data.
        
        Based on pipeline_agent_testing.ipynb structure.
        
        Args:
            pipeline_df: DataFrame with pipeline data (capacity_bpd already imputed)
            
        Returns:
            Number of pipelines loaded
        """
        # Remove default pipeline if pipelines are being loaded from data
        if self.pipeline_agents and len(self.pipeline_agents) == 1:
            default_pipeline = self.pipeline_agents[0]
            self.schedule.remove(default_pipeline)
            self.pipeline_agents = []
        
        loaded_count = 0
        for _, row in pipeline_df.iterrows():
            pipeline = PipelineAgent(
                unique_id=self.well_counter,
                model=self,
                pipeline_id=int(float(row.get("uspip_id", self.well_counter))),
                pipeline_name=str(row.get("group_name", f"Pipeline_{loaded_count}")),
                market_center=str(row.get("market_center", self.market_center)),
                basin=str(row.get("basin_name", self.basin_name)),
                capacity_bpd=float(row.get("capacity_bpd", 600_000)),  # Already imputed in data_loader
            )
            self.schedule.add(pipeline)
            self.pipeline_agents.append(pipeline)
            self.well_counter += 1
            loaded_count += 1
        
        # Update default pipeline reference to first loaded pipeline
        if self.pipeline_agents:
            self.pipeline = self.pipeline_agents[0]
        
        logger.info(
            "Loaded %d pipelines for market_center=%s",
            loaded_count, self.market_center
        )
        
        return loaded_count
 

    def _process_monthly_refinery_allocation(self) -> None:
        """
        Allocate monthly production to refineries and process yields.
        
        Called at the end of each month when the monthly accumulator resets.
        """
        if not self.refinery_enabled or not self.refinery_agents:
            return
        
        # Convert monthly accumulator to refinery-compatible grades
        grade_production = self._convert_accumulator_to_refinery_grades()
        
        # Reset refinery yields for this month
        self.monthly_refinery_yields = self._create_empty_refinery_accumulator()
        
        # Allocate production to refineries by grade
        for grade_name, production in grade_production.items():
            if production <= 0:
                continue
            
            # Find eligible refineries for this grade
            eligible_refineries = [
                r for r in self.refinery_agents
                if r.is_active and r.effective_capacity > 0
            ]
            
            if not eligible_refineries:
                continue
            
            # Calculate total weight for proportional allocation
            total_weight = sum(r.weight for r in eligible_refineries)
            if total_weight <= 0:
                continue
            
            remaining = production
            
            # Allocate proportionally, respecting capacity
            for refinery in eligible_refineries:
                if remaining <= 0:
                    break
                
                share = production * (refinery.weight / total_weight)
                allocation = min(share, refinery.effective_capacity, remaining)
                
                if allocation > 0:
                    refinery.allocate_crude(
                        grade_name=grade_name,
                        grade_element_name="na",
                        runs_vol=allocation,
                        year=self._current_year,
                        month=self._current_month
                    )
                    remaining -= allocation
        
        # Execute refinery processing
        for refinery in self.refinery_agents:
            refinery.step()
            
            # Aggregate yields
            for product, vol in refinery.model_yields.items():
                self.monthly_refinery_yields[product] += vol
            
            # Collect output rows
            # For export refineries, collect the export row (1 row)
            # For regular refineries, collect yield rows (len(model_yields) rows)
            if refinery.configuration.lower() == "export" and refinery.runs_vol > 0:
                # Export refinery: collect the last row (export record)
                if refinery.output_rows:
                    self.refinery_output_rows.append(refinery.output_rows[-1])
            else:
                # Regular refinery: collect yield rows
                num_yield_rows = len(refinery.model_yields)
                if num_yield_rows > 0:
                    self.refinery_output_rows.extend(refinery.output_rows[-num_yield_rows:])
        
        # Log refinery processing
        total_yields = sum(self.monthly_refinery_yields.values())
        logger.info(
            "Refinery processing for %d-%02d: total_yields=%.0f bbl",
            self._current_year, self._current_month, total_yields
        )
 

    def _convert_accumulator_to_refinery_grades(self) -> Dict[str, float]:
        """
        Convert monthly accumulator grades to refinery grade names.
        
        Returns:
            Dictionary mapping refinery grade names to production volumes
        """
        # Mapping from accumulator keys to refinery grade names
        accumulator_to_grade = {
            "hSour": "Heavy Sour",
            "hSweet": "Heavy Sweet",
            "mSour": "Medium Sour",
            "mSweet": "Medium Sweet",
            "lSour": "Light Sour",
            "lSweet": "Light Sweet",
        }
        
        return {
            accumulator_to_grade.get(key, key): vol
            for key, vol in self.monthly_accumulator.items()
        }

    def get_refinery_state(self) -> Dict[str, Any]:
        """
        Get current refinery state.
        
        Returns:
            Dictionary with refinery state information
        """
        if not self.refinery_enabled:
            return {"enabled": False, "refineries": [], "yields": {}}
        
        total_runs = sum(r.runs_vol for r in self.refinery_agents)
        total_yields = sum(self.monthly_refinery_yields.values())
        
        return {
            "enabled": True,
            "refinery_count": len(self.refinery_agents),
            "active_refineries": sum(1 for r in self.refinery_agents if r.is_active),
            "current_month": {
                "year": self._current_year,
                "month": self._current_month,
                "total_runs": total_runs,
                "total_yields": total_yields,
                "yields_by_product": dict(self.monthly_refinery_yields),
            },
            "cumulative": {
                "total_runs_processed": sum(r.total_runs_processed for r in self.refinery_agents),
                "total_yields_produced": {
                    product: sum(r.total_yields_produced.get(product, 0) for r in self.refinery_agents)
                    for product in REFINERY_PRODUCTS
                },
            },
            "refineries": [r.get_state() for r in self.refinery_agents],
        }

    def get_refinery_tick_output(self) -> Dict[str, Any]:
        """
        Get refinery output for current tick (for websocket streaming).
        
        Based on Final_refinery_runner.ipynb: ready_to_export = total_production - total_runs
        
        Returns:
            Dictionary with tick-specific refinery data including remaining_Ready_to_export
        """
        if not self.refinery_enabled:
            return {}
        
        # Calculate total production for current month (from monthly accumulator)
        total_monthly_production = sum(self.monthly_accumulator.values())
        total_runs = sum(r.runs_vol for r in self.refinery_agents)
        
        # Calculate remaining_Ready_to_export (basin level, monthly)
        # This matches Final_refinery_runner: ready_to_export = total_production - total_runs
        remaining_Ready_to_export = max(0.0, total_monthly_production - total_runs)
        
        return {
            "year": self._current_year,
            "month": self._current_month,
            "total_runs": total_runs,
            "total_yields": sum(self.monthly_refinery_yields.values()),
            "yields_by_product": dict(self.monthly_refinery_yields),
            "remaining_Ready_to_export": remaining_Ready_to_export,  # Basin level, monthly
            "refineries": [r.get_tick_output() for r in self.refinery_agents if r.runs_vol > 0],
        }

    # =============================================================
    # PIPELINE ALLOCATION METHODS
    # =============================================================
    
    @staticmethod
    def _monthly_to_daily(monthly_volume: float, year: int, month: int) -> float:
        """
        Convert monthly volume to daily volume.
        
        Args:
            monthly_volume: Monthly volume (bbl)
            year: Year
            month: Month (1-12)
            
        Returns:
            Daily volume (bbl/day)
        """
        days_in_month = pd.Period(f"{year}-{month:02d}").days_in_month
        return monthly_volume / days_in_month if days_in_month > 0 else 0.0
    
    def _allocate_pipeline_daily_flow(self, daily_input: float) -> None:
        """
        Allocate daily flow to pipelines (matching notebook logic).
        
        Supports multiple pipelines - allocates to active pipelines proportionally.
        
        Args:
            daily_input: Daily input volume from refinery (bbl/day)
        """
        if not hasattr(self, 'pipeline_agents') or not self.pipeline_agents:
            # Fallback to single pipeline
            if not hasattr(self, 'pipeline') or not self.pipeline:
                return
            pipelines = [self.pipeline]
        else:
            pipelines = self.pipeline_agents
        
        self.daily_pipeline_input = daily_input
        
        # Get active pipelines (matching notebook logic)
        active = [
            p for p in pipelines
            if p.is_operational and p.is_active
        ]
        
        if not active:
            # No active pipelines - handle overflow
            self._handle_pipeline_overflow(daily_input)
            return
        
        # Calculate total capacity
        total_capacity = sum(p.max_capacity for p in active)
        remaining = daily_input
        
        if total_capacity >= daily_input:
            # All input can be transported - allocate to pipelines sequentially (matching notebook)
            for p in active:
                alloc = min(p.max_capacity, remaining)
                p.receive_flow(alloc)
                remaining -= alloc
                if remaining <= 0:
                    break
        else:
            # Transport up to total capacity (each pipeline gets its full capacity)
            for p in active:
                p.receive_flow(p.max_capacity)
            
            remaining = daily_input - total_capacity
        
        # Handle any remaining overflow
        remaining = max(remaining, 0.0)
        if remaining > 0:
            self._handle_pipeline_overflow(remaining)
        else:
            # No overflow - reset storage days if buffer is empty
            if self.pipeline_storage_buffer <= 0:
                self.pipeline_storage_days_used = 0
    
    def _handle_pipeline_overflow(self, volume: float) -> None:
        """
        Handle overflow volume by adding to storage buffer.
        
        Args:
            volume: Overflow volume (bbl)
        """
        if volume > 0:
            self.pipeline_storage_buffer += volume
            self.pipeline_storage_days_used += 1
        else:
            # If no overflow, reset storage days if buffer is empty
            if self.pipeline_storage_buffer <= 0:
                self.pipeline_storage_days_used = 0
        
        # Check stress condition
        if self.pipeline_storage_days_used > self.pipeline_max_storage_days:
            # Stress flag - deactivate pipelines
            if hasattr(self, 'pipeline_agents'):
                for p in self.pipeline_agents:
                    p.is_active = False
            elif hasattr(self, 'pipeline'):
                self.pipeline.is_active = False
    
    def get_pipeline_daily_output(self, pipeline: PipelineAgent) -> Dict[str, Any]:
        """
        Get pipeline daily output for a specific pipeline.
        
        Captures daily_transport BEFORE step() resets it to 0.
        The daily_input is the total input for all pipelines (same for all),
        but daily_transport is the actual amount THIS pipeline transported.
        
        Args:
            pipeline: PipelineAgent instance
            
        Returns:
            Dictionary with daily pipeline metrics for this pipeline
        """
        pipeline_state = pipeline.get_state()
        
        # daily_transport is captured here BEFORE step() resets it
        # This is the actual amount this pipeline transported today
        daily_transport = pipeline_state.get("daily_transport", 0.0)
        utilization_pct = pipeline_state.get("utilization_pct", 0.0)
        
        return {
            "tick": self.schedule.steps,
            "date": self.current_date.isoformat(),
            "year": self.current_date.year,
            "month": self.current_date.month,
            "day": self.current_date.day,
            "pipeline_id": pipeline_state.get("pipeline_id", pipeline.unique_id),
            "pipeline_name": pipeline_state.get("pipeline_name", ""),
            "market_center": pipeline_state.get("market_center", ""),
            "basin": pipeline_state.get("basin", ""),
            "daily_input": self.daily_pipeline_input,  # Total daily input (same for all pipelines)
            "daily_transport": daily_transport,  # Actual transported by THIS pipeline (captured before reset)
            "utilization_pct": utilization_pct,  # Utilization for THIS pipeline
            "stress_flag": self.pipeline_storage_days_used > self.pipeline_max_storage_days,
            "storage_buffer": self.pipeline_storage_buffer,
            "storage_days_used": self.pipeline_storage_days_used,
            "max_storage_days": self.pipeline_max_storage_days,
            "capacity_bpd": pipeline_state.get("capacity_bpd", 0.0),
            "is_active": pipeline_state.get("is_active", False),
            "is_operational": pipeline_state.get("is_operational", False),
            "cumulative_transport": pipeline_state.get("cumulative_transport", 0.0),
        }
    
    def get_all_pipelines_daily_output(self) -> List[Dict[str, Any]]:
        """
        Get daily output for ALL pipelines.
        
        This captures daily_transport BEFORE step() resets it to 0.
        
        Returns:
            List of dictionaries, one per pipeline, with daily metrics
        """
        outputs = []
        
        # Get all pipelines
        if hasattr(self, 'pipeline_agents') and self.pipeline_agents:
            pipelines = self.pipeline_agents
        elif hasattr(self, 'pipeline') and self.pipeline:
            pipelines = [self.pipeline]
        else:
            return outputs
        
        # Collect output for each pipeline (capturing daily_transport before reset)
        for pipeline in pipelines:
            output = self.get_pipeline_daily_output(pipeline)
            if output:
                outputs.append(output)
        
        return outputs
    
    def get_pipeline_state(self) -> Dict[str, Any]:
        """
        Get complete pipeline state including daily outputs.
        
        Returns:
            Dictionary with pipeline state
        """
        if not hasattr(self, 'pipeline'):
            return {}
        
        pipeline_state = self.pipeline.get_state()
        daily_output = self.get_pipeline_daily_output()
        
        return {
            **pipeline_state,
            **daily_output,
        }
