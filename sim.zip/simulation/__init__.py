"""
Simulation module for SimOxy Simulation Engine.

This module exports the main simulation components and configuration.
"""

from .agents import (
    WellAgent,
    PipelineAgent,
)
from .model import BasinModel
from .runner import SimulationRunner

# Import constants from centralized config for backwards compatibility
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.simulation_config import (
    WELL_TYPE_PARAMETERS,
    DRIVE_MECHANISM_DECLINE_MULTIPLIER,
    CONFIGURATION_MULTIPLIER,
    CONSTANTS,
)

# Backwards compatibility aliases
DAYS_IN_YEAR = CONSTANTS.DAYS_IN_YEAR
DEFAULT_EUR_HORIZON_YEARS = CONSTANTS.DEFAULT_EUR_HORIZON_YEARS
MIN_ECONOMIC_PRODUCTION = CONSTANTS.MIN_ECONOMIC_PRODUCTION

__all__ = [
    "WellAgent",
    "PipelineAgent",
    "BasinModel",
    "SimulationRunner",
    "WELL_TYPE_PARAMETERS",
    "DRIVE_MECHANISM_DECLINE_MULTIPLIER",
    "CONFIGURATION_MULTIPLIER",
    "DAYS_IN_YEAR",
    "DEFAULT_EUR_HORIZON_YEARS",
    "MIN_ECONOMIC_PRODUCTION",
    "CONSTANTS",
]
