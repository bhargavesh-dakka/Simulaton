"""
RefineryAgent - Processes crude oil production into refined products.

This module implements the RefineryAgent class that simulates refinery operations,
converting crude oil inputs into various petroleum products based on refinery
configuration and crude grade.

COMPLIANCE: Implements refinery yield calculations for:
- Simple Distillation: Direct cut percentages
- Hydroskimming: Distillation + hydrotreating conversion
- Coking/Cracking: Heavy fuel oil conversion and redistribution
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Dict, Any, Optional, List, TYPE_CHECKING

import pandas as pd
from mesa import Agent

# Import centralized configuration
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from config.simulation_config import (
    RefineryConfiguration,
    RefineryProduct,
    REFINERY_PRODUCTS,
    CRACK_PRODUCTS,
    LIGHT_PRODUCTS,
    DEFAULT_REFINERY_YIELDS,
    MEDIUM_HIGH_PRODUCTS,
    MEDIUM_LOW_PRODUCTS,
    LIGHT_COKING_HIGH_PRODUCTS,
    LIGHT_COKING_LOW_PRODUCTS,
    LIGHT_CRACK_HIGH_PRODUCTS,
    LIGHT_CRACK_LOW_PRODUCTS,
    HEAVY_LIGHT_PRODUCTS
)
from utils.logging_config import get_logger

if TYPE_CHECKING:
    from simulation.model import BasinModel

# Module logger
logger = get_logger(__name__)


class RefineryAgent(Agent):
    """
    Refinery agent that processes crude oil into refined products.
    
    Receives monthly production by grade from BasinModel and calculates
    product yields based on refinery configuration and crude grade.
    
    Attributes:
        refinery_id: Unique identifier for this refinery
        refinery_name: Full refinery name (e.g., "United States | Baytown | ExxonMobil")
        basin: Basin location (e.g., "Gulf Coast Basin")
        configuration: Refinery type (Simple Distillation, Hydroskimming, Coking, Cracking)
        effective_capacity: Maximum processing capacity (bbl/month)
        weight: Historical run volume weight for allocation
        runs_vol: Current tick's crude input volume
        model_yields: Current tick's product yields
        total_runs_processed: Cumulative crude processed
        total_yields_produced: Cumulative product yields
    """

    def __init__(
        self,
        unique_id: int,
        model: "BasinModel",
        refinery_id: str,
        refinery_name: str,
        basin: str,
        configuration: str,
        effective_capacity: float,
        weight: float,
        mapping_df: Optional[pd.DataFrame] = None,
    ) -> None:
        """
        Initialize a RefineryAgent.
        
        Args:
            unique_id: Mesa agent unique identifier
            model: Parent BasinModel instance
            refinery_id: Unique refinery identifier
            refinery_name: Full refinery name
            basin: Basin location
            configuration: Refinery processing configuration
            effective_capacity: Maximum capacity (bbl/month)
            weight: Weight for proportional allocation
            mapping_df: Yield conversion mapping data (optional)
        """
        super().__init__(unique_id, model)
        
        # Static properties
        self.refinery_id = refinery_id
        self.refinery_name = refinery_name
        self.basin = basin
        self.configuration = configuration
        self.effective_capacity = effective_capacity
        self.weight = weight
        self.mapping_df = mapping_df
        
        # Dynamic state (per tick/month)
        self.runs_vol = 0.0
        self.grade_name: Optional[str] = None
        self.grade_element_name: Optional[str] = None
        self.year: Optional[int] = None
        self.month: Optional[int] = None
        self.model_yields: Dict[str, float] = defaultdict(float)
        
        # Cumulative tracking
        self.total_runs_processed = 0.0
        self.total_yields_produced: Dict[str, float] = defaultdict(float)
        
        # Output tracking for data collection
        self.output_rows: List[Dict[str, Any]] = []
        
        # Operational status
        self.is_active = True
        self.status = "Active"
        
        logger.debug(
            "RefineryAgent created: id=%s, name=%s, config=%s, capacity=%.0f",
            refinery_id, refinery_name, configuration, effective_capacity
        )

    def allocate_crude(
        self,
        grade_name: str,
        grade_element_name: str,
        runs_vol: float,
        year: int,
        month: int
    ) -> float:
        """
        Allocate crude oil for processing this tick.
        
        Args:
            grade_name: Crude grade (e.g., "Light Sweet")
            grade_element_name: Specific crude element
            runs_vol: Requested crude volume (bbl)
            year: Processing year
            month: Processing month
            
        Returns:
            Actual allocated volume (may be capped by capacity)
        """
        self.grade_name = grade_name
        self.grade_element_name = grade_element_name
        self.year = year
        self.month = month
        
        # Cap allocation at effective capacity
        self.runs_vol = min(runs_vol, self.effective_capacity)
        
        return self.runs_vol

    def step(self) -> None:
        """
        Execute one simulation step (one month for refinery).
        
        Calculates product yields based on configuration and input crude.
        """
        # Handle export configuration separately
        if self.configuration.lower() == "export":
            if self.runs_vol > 0:
                # Update cumulative totals for export
                self.total_runs_processed += self.runs_vol
                # Record export output
                self._record_export_output()
            self.model_yields = defaultdict[str, float](float)
            return
        
        # Skip if no runs
        if self.runs_vol <= 0:
            self.model_yields = defaultdict(float)
            return
        
        # Reset yields for this tick
        self.model_yields = defaultdict(float)
        
        # Calculate yields based on configuration
        self.calculate_yields()
        
        # Update cumulative totals
        self.total_runs_processed += self.runs_vol
        for product, vol in self.model_yields.items():
            self.total_yields_produced[product] += vol
        
        # Record output
        self._record_output()

    def calculate_yields(self) -> None:
        """
        Calculate product yields based on refinery configuration and crude grade.
        
        Implements grade-specific yield calculations for:
        - Simple Distillation: Direct cut percentages
        - Hydroskimming: Distillation + conversion factors
        - Coking: Grade-specific HFO conversion with different factors for Light/Medium/Heavy
        - Cracking: Grade-specific HFO conversion with different factors for Light/Medium/Heavy
        
        Updated implementation matches Final_refinery_runner notebook logic.
        """
        cfg = self.configuration.lower()
        grd = self.grade_name.lower() if self.grade_name else ""
        
        # ================= SIMPLE DISTILLATION ==================
        if cfg == "simple distillation":
            df = self._filter_mapping(["Simple Distillation"])
            for p in REFINERY_PRODUCTS:
                self.model_yields[p] = (
                    self.runs_vol * self._get_cut_pct(df, p) / 100
                )
        
        # ================= HYDROSKIMMING ========================
        elif cfg == "hydroskimming":
            df_sd = self._filter_mapping(["Simple Distillation"])
            df_hs = self._filter_mapping(["Hydroskimming"])
            
            for p in REFINERY_PRODUCTS:
                conv = self._get_avg_conv(df_hs, p)
                if conv is None:
                    conv = 1.0
                self.model_yields[p] = (
                    self.runs_vol *
                    self._get_cut_pct(df_sd, p) / 100 *
                    conv
                )
        
        # ================= COKING ====================
        elif cfg in ["coking"]:
            if grd in ["light sweet", "light sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_conv_low(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                    
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in LIGHT_COKING_LOW_PRODUCTS:
                    conv = self._get_conv_low(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
                
                # ---- Crack products (include cracked HFO share only) ----
                for p in LIGHT_COKING_HIGH_PRODUCTS:
                    conv = self._get_conv_high(df_cc, p)
                    if conv is None:
                        conv = 0.25
                    
                    effective_cut = self._get_cut_pct(df_sd, p)
                    
                    self.model_yields[p] = (
                        self.runs_vol *
                        effective_cut / 100 *
                        conv
                    )
            
            elif grd in ["medium sweet", "medium sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_conv_low(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in MEDIUM_LOW_PRODUCTS:
                    conv = self._get_avg_conv(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
                
                # ---- Crack products (include cracked HFO share only) ----
                for p in MEDIUM_HIGH_PRODUCTS:
                    conv = self._get_conv_high(df_cc, p)
                    if conv is None:
                        conv = 0.25
                    
                    effective_cut = self._get_cut_pct(df_sd, p)
                    
                    self.model_yields[p] = (
                        self.runs_vol *
                        effective_cut / 100 *
                        conv
                    )
            
            elif grd in ["heavy sweet", "heavy sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_avg_conv(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in HEAVY_LIGHT_PRODUCTS:
                    conv = self._get_conv_high(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
        
        # ================= CRACKING ====================
        elif cfg in ["cracking"]:
            if grd in ["light sweet", "light sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_conv_low(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in LIGHT_CRACK_LOW_PRODUCTS:
                    conv = self._get_conv_low(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
                
                # ---- Crack products (include cracked HFO share only) ----
                for p in LIGHT_CRACK_HIGH_PRODUCTS:
                    conv = self._get_conv_high(df_cc, p)
                    if conv is None:
                        conv = 0.25
                    
                    effective_cut = self._get_cut_pct(df_sd, p)
                    
                    self.model_yields[p] = (
                        self.runs_vol *
                        effective_cut / 100 *
                        conv
                    )
            
            elif grd in ["medium sweet", "medium sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_conv_low(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in LIGHT_CRACK_LOW_PRODUCTS:
                    conv = self._get_conv_low(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
                
                # ---- Crack products (include cracked HFO share only) ----
                for p in LIGHT_CRACK_HIGH_PRODUCTS:
                    conv = self._get_conv_high(df_cc, p)
                    if conv is None:
                        conv = 0.25
                    
                    effective_cut = self._get_cut_pct(df_sd, p)
                    
                    self.model_yields[p] = (
                        self.runs_vol *
                        effective_cut / 100 *
                        conv
                    )
            
            elif grd in ["heavy sweet", "heavy sour"]:
                df_sd = self._filter_mapping(["Simple Distillation"])
                df_cc = self._filter_mapping([self.configuration.capitalize()])
                
                # ---- Heavy Fuel Oil conversion ----
                hfo_cut = self._get_cut_pct(df_sd, RefineryProduct.HEAVY_FUEL_OIL.value)
                hfo_conv = self._get_avg_conv(df_cc, RefineryProduct.HEAVY_FUEL_OIL.value)
                
                if hfo_conv is None:
                    hfo_conv = 0.1
                
                # Remaining HFO
                self.model_yields[RefineryProduct.HEAVY_FUEL_OIL.value] = (
                    self.runs_vol * hfo_cut / 100 * hfo_conv
                )
                
                # ---- Light products (NO ZEROING, NO POOLING) ----
                for lp in HEAVY_LIGHT_PRODUCTS:
                    conv = self._get_conv_high(df_cc, lp)
                    if conv is None:
                        conv = 0.5
                    
                    self.model_yields[lp] = (
                        self.runs_vol *
                        self._get_cut_pct(df_sd, lp) / 100 *
                        conv
                    )
        
        else:
            # Fallback to default yields
            self._calculate_default_yields()
 

    def _calculate_default_yields(self) -> None:
        """Calculate yields using default percentages when no mapping available."""
        # Default to simple distillation yields
        yields = DEFAULT_REFINERY_YIELDS.get(
            RefineryConfiguration.SIMPLE_DISTILLATION.value, {}
        )
        for product, pct in yields.items():
            self.model_yields[product] = self.runs_vol * pct

    def _filter_mapping(self, configs: List[str]) -> pd.DataFrame:
        """
        Filter mapping data for grade and configuration.
        
        Args:
            configs: List of configuration names to match
            
        Returns:
            Filtered DataFrame
        """
        if self.mapping_df is None or self.mapping_df.empty:
            return pd.DataFrame()
        
        df = self.mapping_df.copy()
        
        
        # Normalize SPG_grade_element_name column to lowercase for comparison
        if "SPG_grade_element_name" in df.columns:
            df["SPG_grade_element_name"] = df["SPG_grade_element_name"].astype(str).str.lower().str.strip()
        
        # Normalize grade_element_name for comparison (handle both string and list)
        grade_element_normalized = None
        if self.grade_element_name:
            if isinstance(self.grade_element_name, str):
                grade_element_normalized = self.grade_element_name.lower().strip()
            else:
                grade_element_normalized = str(self.grade_element_name).lower().strip()
        
        # Primary filter
        df_filtered = df[
            (df["grade_name_match"] == self.grade_name) &
            (df["Proxy_Grade"].isin(["N", "R"])) &
            (df["Configuration"].isin(configs)) &
            (
                (df["SPG_grade_element_name"] == "na") |
                (df["SPG_grade_element_name"] == grade_element_normalized)
            )
        ]
        
        # Sort to prefer exact grade element over NA
        if not df_filtered.empty:
            df_filtered = df_filtered.sort_values(
                by="SPG_grade_element_name",
                key=lambda x: x != grade_element_normalized
            )
        
        # Fallback if no rows found
        if df_filtered.empty:
            df_filtered = df[
                (df["grade_name_match"] == self.grade_name) &
                (df["Proxy_Grade"] == "Y")
            ]
        
        return df_filtered
 

    def _get_cut_pct(self, df: pd.DataFrame, product: str) -> float:
        """Get cut percentage for a product from mapping data."""
        if df.empty:
            return 0.0
        filtered = df[df["SPG_ref_cut"] == product]
        return filtered["Cut_vol_pct"].sum() if not filtered.empty else 0.0

    def _get_avg_conv(self, df: pd.DataFrame, product: str) -> Optional[float]:
        """Get average conversion factor for a product."""
        if df.empty:
            return None
        row = df[df["SPG_ref_cut"] == product]
        if row.empty:
            return None
        return (row["Conv_Low"].iloc[0] + row["Conv_High"].iloc[0]) / 2

    def _get_conv_low(self, df: pd.DataFrame, product: str) -> Optional[float]:
        """Get low conversion factor for a product."""
        if df.empty:
            return None
        row = df[df["SPG_ref_cut"] == product]
        if row.empty:
            return None
        return row["Conv_Low"].iloc[0]
    
    def _get_conv_high(self, df: pd.DataFrame, product: str) -> Optional[float]:
        """Get high conversion factor for a product."""
        if df.empty:
            return None
        row = df[df["SPG_ref_cut"] == product]
        if row.empty:
            return None
        return row["Conv_High"].iloc[0]
 

    def _record_output(self) -> None:
        """Record output for data collection."""
        total_production = sum(self.model_yields.values())
        
        for product, vol in self.model_yields.items():
            self.output_rows.append({
                "refinery_id": self.refinery_id,
                "refinery_name": self.refinery_name,
                "basin": self.basin,
                "grade_name": self.grade_name,
                "grade_element_name": self.grade_element_name,
                "configuration": self.configuration,
                "year": self.year,
                "month": self.month,
                "runs": self.runs_vol,
                "process_unit": product,
                "yields_vol": vol,
                "total_yields": total_production,
            })

    def _record_export_output(self) -> None:
        """Record export output for export configuration refineries."""
        # For export refineries, record the crude volume as export
        # Use "Export" as the process_unit to indicate this is exported crude
        self.output_rows.append({
            "refinery_id": self.refinery_id,
            "refinery_name": self.refinery_name,
            "basin": self.basin,
            "grade_name": self.grade_name,
            "grade_element_name": self.grade_element_name,
            "configuration": self.configuration,
            "year": self.year,
            "month": self.month,
            "runs": self.runs_vol,
            "process_unit": "Export",
            "yields_vol": self.runs_vol,  # Export volume equals runs volume
            "total_yields": self.runs_vol,
        })
 

    def get_state(self) -> Dict[str, Any]:
        """
        Get current refinery state as dictionary.
        
        Returns:
            Dictionary containing all refinery state attributes
        """
        return {
            "id": self.unique_id,
            "refinery_id": self.refinery_id,
            "refinery_name": self.refinery_name,
            "basin": self.basin,
            "configuration": self.configuration,
            "effective_capacity": self.effective_capacity,
            "weight": self.weight,
            "is_active": self.is_active,
            "status": self.status,
            # Current tick state
            "runs_vol": self.runs_vol,
            "grade_name": self.grade_name,
            "grade_element_name": self.grade_element_name,
            "year": self.year,
            "month": self.month,
            "yields": dict(self.model_yields),
            "total_yields": sum(self.model_yields.values()),
            # Cumulative state
            "total_runs_processed": self.total_runs_processed,
            "total_yields_produced": dict(self.total_yields_produced),
            "cumulative_total_yields": sum(self.total_yields_produced.values()),
        }

    def get_minimal_state(self) -> Dict[str, Any]:
        """
        Get minimal state for efficient storage.
        
        Returns:
            Dictionary with only essential state values
        """
        return {
            "runs_vol": self.runs_vol,
            "yields": dict(self.model_yields),
            "total_runs_processed": self.total_runs_processed,
            "is_active": self.is_active,
        }

    def get_tick_output(self) -> Dict[str, Any]:
        """
        Get output for current tick (for websocket streaming).
        
        Returns:
            Dictionary with tick-specific refinery output
        """
        return {
            "refinery_id": self.refinery_id,
            "refinery_name": self.refinery_name,
            "basin": self.basin,
            "configuration": self.configuration,
            "year": self.year,
            "month": self.month,
            "runs_vol": self.runs_vol,
            "grade_name": self.grade_name,
            "yields": dict(self.model_yields),
            "total_yields": sum(self.model_yields.values()),
        }

    def reset_tick_state(self) -> None:
        """Reset per-tick state for next allocation cycle."""
        self.runs_vol = 0.0
        self.grade_name = None
        self.grade_element_name = None
        self.model_yields = defaultdict(float)
