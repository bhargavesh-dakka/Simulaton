"""
PipelineAgent - Pipeline Agent for Refinery Export Transportation.

This module implements the PipelineAgent class that handles transportation
of refined products from refineries to export markets.

Based on pipeline_agent_testing.ipynb - simplified structure matching notebook.

COMPLIANCE:
- Capacity imputation: 600,000 bbl/day when capacity is null/blank
- Daily transport tracking
- Utilization percentage calculation
- Storage overflow handling (via BasinModel)
"""

from __future__ import annotations

from typing import Dict, Any, TYPE_CHECKING

from mesa import Agent

# Import centralized configuration
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from utils.logging_config import get_logger

if TYPE_CHECKING:
    from simulation.model import BasinModel

# Module logger
logger = get_logger(__name__)


class PipelineAgent(Agent):
    """
    Pipeline Agent attached to a Market Center.

    Handles transportation of refined products from refineries to export.
    Receives daily input from refinery's remaining_Ready_to_export (converted from monthly).

    Based on pipeline_agent_testing.ipynb structure.

    Attributes:
        pipeline_id: Unique pipeline identifier
        pipeline_name: Pipeline name
        market_center: Market center location
        basin: Basin location
        max_capacity: Maximum daily capacity (bbl/day)
        is_operational: Whether pipeline is operational
        is_active: Whether pipeline is active (can be deactivated by stress)
        daily_transport: Daily transported volume (bbl)
        cumulative_transport: Cumulative transported volume (bbl)
        utilization_pct: Utilization percentage
        stranded_throughput: Stranded throughput (bbl)
    """

    def __init__(
        self,
        unique_id: int,
        model: "BasinModel",
        pipeline_id: int = None,
        pipeline_name: str = "Pipeline",
        market_center: str = "Permian",
        basin: str = "Permian Basin",
        capacity_bpd: float = 0.0,
    ) -> None:
        """
        Initialize a PipelineAgent.
        
        Args:
            unique_id: Mesa agent unique identifier
            model: Parent BasinModel instance
            pipeline_id: Unique pipeline identifier
            pipeline_name: Pipeline name
            market_center: Market center location
            basin: Basin location
            capacity_bpd: Capacity in barrels per day (bbl/day)
        """
        super().__init__(unique_id, model)
        
        # Pipeline identification
        self.pipeline_id = pipeline_id if pipeline_id is not None else unique_id
        self.pipeline_name = pipeline_name
        self.market_center = market_center
        self.basin = basin

        # Capacity (already imputed upstream with 600,000 if null/blank)
        self.max_capacity = float(capacity_bpd)

        # State
        self.is_operational = True  # Always operational if capacity > 0
        self.is_active = True  # Can be deactivated by stress conditions

        # Metrics
        self.daily_transport = 0.0  # Daily transported volume (bbl)
        self.cumulative_transport = 0.0  # Cumulative transported volume (bbl)
        self.utilization_pct = 0.0  # Utilization percentage
        self.stranded_throughput = 0.0  # Stranded throughput (bbl)

        logger.debug(
            "PipelineAgent created: id=%s, name=%s, capacity=%.0f bbl/day",
            self.pipeline_id, self.pipeline_name, self.max_capacity
        )

    # ---------------------------------------------------------------
    # PIPELINE LIFECYCLE
    # ---------------------------------------------------------------
    def activate(self) -> None:
        """Activate pipeline if capacity > 0"""
        if self.max_capacity > 0:
            self.is_active = True
            if not self.is_operational:
                self.is_operational = True
                logger.debug("Pipeline %s activated", self.pipeline_id)

    # ---------------------------------------------------------------
    # FLOW MANAGEMENT (Matching notebook exactly)
    # ---------------------------------------------------------------
    def receive_flow(self, volume: float) -> None:
        """
        Receive flow volume for this day.
        
        Args:
            volume: Volume to transport (bbl/day)
        """
        volume = max(volume, 0.0)

        self.daily_transport = volume
        self.cumulative_transport += volume

        self.utilization_pct = (
            (volume / self.max_capacity) * 100
            if self.max_capacity > 0 else 0.0
        )
    
    def add_flow(self, amount: float) -> float:
        """
        Add production flow to pipeline (backward compatibility for well production).
        
        This method is used by well production. It adds to existing daily transport.
        
        Args:
            amount: Production amount to add (bbl)
            
        Returns:
            Actual amount transported (may be capped by capacity)
        """
        if not self.is_operational or not self.is_active:
            return 0.0
        
        # For well production, add to existing daily transport
        current_daily = self.daily_transport
        available = max(0.0, self.max_capacity - current_daily)
        actual_flow = min(amount, available)
        
        if actual_flow > 0:
            self.daily_transport += actual_flow
            self.cumulative_transport += actual_flow
            
            self.utilization_pct = (
                (self.daily_transport / self.max_capacity) * 100
                if self.max_capacity > 0 else 0.0
            )
        
        return actual_flow

    # ---------------------------------------------------------------
    # PIPELINE STEP (Matching notebook)
    # ---------------------------------------------------------------
    def step(self) -> None:
        """Update pipeline state each simulation day"""
        # Reset daily transport at end of day (matching notebook)
        self.daily_transport = 0.0

    # ---------------------------------------------------------------
    # STATE EXPORT
    # ---------------------------------------------------------------
    def get_state(self) -> Dict[str, Any]:
        """
        Get complete pipeline state.
        
        Returns:
            Dictionary containing all pipeline state attributes
        """
        return {
            "id": self.unique_id,
            "pipeline_id": self.pipeline_id,
            "pipeline_name": self.pipeline_name,
            "market_center": self.market_center,
            "basin": self.basin,
            "capacity_bpd": self.max_capacity,
            "is_operational": self.is_operational,
            "is_active": self.is_active,
            "daily_transport": self.daily_transport,
            "cumulative_transport": self.cumulative_transport,
            "utilization_pct": self.utilization_pct,
            "stranded_throughput": self.stranded_throughput,
        }
    
    def get_tick_output(self) -> Dict[str, Any]:
        """
        Get output for current tick (for websocket streaming).
        
        Returns:
            Dictionary with tick-specific pipeline output
        """
        return {
            "pipeline_id": self.pipeline_id,
            "pipeline_name": self.pipeline_name,
            "market_center": self.market_center,
            "basin": self.basin,
            "capacity_bpd": self.max_capacity,
            "daily_transport": self.daily_transport,
            "cumulative_transport": self.cumulative_transport,
            "utilization_pct": self.utilization_pct,
            "is_active": self.is_active,
            "is_operational": self.is_operational,
        }

    def get_minimal_state(self) -> Dict[str, Any]:
        """
        Get minimal state for efficient storage.
        
        Returns:
            Dictionary with only essential state values
        """
        return {
            "daily_transport": self.daily_transport,
            "cumulative_transport": self.cumulative_transport,
            "utilization_pct": self.utilization_pct,
            "is_active": self.is_active,
        }
 