
from __future__ import annotations

import math
from datetime import datetime
from typing import Optional, Dict, Any, TYPE_CHECKING

from mesa import Agent

# Import centralized configuration
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from utils.logging_config import get_logger
from config.simulation_config import (
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    WELL_TYPE_PARAMETERS,
    DECLINE_TYPE_PARAMETERS,
    DRIVE_MECHANISM_DECLINE_MULTIPLIER,
    CONFIGURATION_MULTIPLIER,
    CRUDE_GRADE_PROBABILITIES,
    CONSTANTS,
    get_well_type_defaults,
)

if TYPE_CHECKING:
    from simulation.model import BasinModel

# Module logger
logger = get_logger(__name__)


class WellAgent(Agent):
    """
    SimOxy-Compliant WellAgent.
    
    Implements production simulation for individual wells including:
    - Hyperbolic/Exponential/Harmonic decline curves
    - Drive mechanism effects on decline rate
    - Configuration multipliers for productivity
    - Facility max capacity constraints
    - EUR limits and economic thresholds
    - Region-specific reserve depletion (via BasinModel)
    
    Attributes:
        unique_id: Unique identifier for this well
        well_type: Type of well (e.g., "Shale Oil", "Conventional Onshore")
        initial_production: Initial production rate in bbl/day
        decline_exponent: b-factor for hyperbolic decline (0=exponential, 1=harmonic)
        nominal_decline_rate: Annual nominal decline rate
        cumulative_production: Total production to date (bbl)
        daily_production: Realized production for current day (bbl/day)
        daily_potential_production: Calculated potential production (bbl/day)
        is_active: Whether well is currently producing
        status: Operational status (Active, Choked, Inactive)
    """

    def __init__(
        self,
        unique_id: str,
        model: "BasinModel",
        initial_production: Optional[float] = None,
        decline_exponent: Optional[float] = None,
        nominal_decline_rate: Optional[float] = None,
        decline_type: str = DeclineType.HYPERBOLIC.value,
        b_factor: Optional[float] = None,
        drilling_date: Optional[datetime] = None,
        production_start_date: Optional[datetime] = None,
        production_end_date: Optional[datetime] = None,
        eur: Optional[float] = None,
        well_type: Optional[str] = None,
        crude_grade: Optional[str] = None,
        location: str = "Permian Basin",
        basin: str = "Permian",
        max_capacity: Optional[float] = None,
        development_cost: float = 0.0,
        operational_status: str = "Active",
        drive_mechanism: str = DriveMechanism.SOLUTION_GAS_DRIVE.value,
        configuration: str = WellConfiguration.VERTICAL.value,
        ecr_enabled: bool = False,
        actual_production_data: Optional[Dict[str, float]] = None,
        api_number: Optional[int] = None,
        is_new: bool = True,
        last_known_qi: Optional[float] = None,
        last_known_di: Optional[float] = None,
        last_data_date: Optional[datetime] = None,
    ) -> None:
        """
        Initialize a WellAgent.
        
        Args:
            unique_id: Unique identifier for this well
            model: Parent BasinModel instance
            initial_production: Initial production rate (bbl/day). Defaults to well type typical_qi.
            decline_exponent: b-factor for decline curve. Defaults based on decline_type/well_type.
            nominal_decline_rate: Annual decline rate. Defaults based on well_type.
            decline_type: Type of decline curve (Exponential, Hyperbolic, Harmonic)
            b_factor: Alias for decline_exponent (takes precedence if both provided)
            drilling_date: Date when drilling started
            production_start_date: Date when production begins
            production_end_date: Date when production ends (optional)
            eur: Estimated Ultimate Recovery (bbl). Auto-calculated if not provided.
            well_type: Type of well (must be valid WellType)
            crude_grade: Crude oil grade. Auto-assigned based on well type if not provided.
            location: Well location/basin name
            basin: Basin identifier
            max_capacity: Maximum production capacity (bbl/day)
            development_cost: Well development cost
            operational_status: Initial operational status
            drive_mechanism: Reservoir drive mechanism
            configuration: Well completion configuration
            ecr_enabled: Whether Enhanced Completion Recovery is enabled
            actual_production_data: Historical production data (date string -> bbl)
            api_number: API well identifier
            is_new: Whether this well is from forecast (True) or from existing data (False)
            last_known_qi: Last known initial production from dim data (bbl/day) for decline curve fallback
            last_known_di: Last known decline rate from dim data (per month) for decline curve fallback
            last_data_date: Last date with actual production data, used as t=0 for decline curve fallback
            
        Raises:
            ValueError: If well_type, configuration, decline_type, or drive_mechanism is invalid
            ValueError: If offshore location has non-conventional well type
        """
        super().__init__(unique_id, model)

        self.well_type = well_type
        self.location = location
        self.basin = basin
        self.development_cost = development_cost
        self.operational_status = operational_status
        self.drive_mechanism = drive_mechanism
        self.configuration = configuration
        self.ecr_enabled = ecr_enabled
        self.decline_type = decline_type

        # Assign crude grade - use provided or assign based on well type probability
        self.crude_grade = crude_grade if crude_grade else self._assign_crude_grade()

        # Validate well type and configuration
        self._validate_well_parameters()

        # Production cost (Handbook: dynamic attribute)
        self.production_cost = 0.0

        # Get type-specific parameters
        params = WELL_TYPE_PARAMETERS.get(well_type, WELL_TYPE_PARAMETERS[WellType.CUSTOM.value])
        decline_params = DECLINE_TYPE_PARAMETERS.get(decline_type, DECLINE_TYPE_PARAMETERS[DeclineType.HYPERBOLIC.value])

        # Determine decline exponent (b-factor)
        if b_factor is not None:
            self.decline_exponent = b_factor
        elif decline_exponent is not None:
            self.decline_exponent = decline_exponent
        elif decline_params["b_factor"] is not None:
            self.decline_exponent = decline_params["b_factor"]
        else:
            self.decline_exponent = params["decline_exponent"]

        # Apply decline type multiplier to nominal decline rate
        base_decline_rate = nominal_decline_rate or params["nominal_decline_rate"]
        self.nominal_decline_rate = base_decline_rate * decline_params["decline_multiplier"]

        # Initial production (Qi) with configuration multiplier
        base_qi = initial_production or params.get("typical_qi", 100.0)
        self.initial_production = base_qi * CONFIGURATION_MULTIPLIER.get(
            configuration, 1.0
        )

        # Capacity
        default_capacity = self.initial_production * params.get("default_max_capacity_multiplier", 3.0)
        self.max_capacity = max_capacity or default_capacity

        # Production state
        self.drilling_date = drilling_date
        self.production_start_date = production_start_date or model.start_date
        self.production_end_date = production_end_date
        self.daily_production = 0.0
        self.daily_potential_production = 0.0
        
        # Initialize days_on_production and cumulative_production
        # For wells that started before simulation, account for prior production
        if self.production_start_date < model.start_date:
            # Calculate days already on production before simulation starts
            days_before_sim = (model.start_date - self.production_start_date).days
            self.days_on_production = days_before_sim
            # Calculate cumulative production before simulation
            self.cumulative_production = self._calculate_prior_cumulative_production(days_before_sim)
        else:
            self.days_on_production = 0
            self.cumulative_production = 0.0
        
        # Well status
        self.status = "Active" if operational_status.upper() == "ACTIVE" else "Inactive"
        self.is_active = (
            self.status == "Active" and 
            model.current_date >= self.production_start_date
        )

        # Calculate EUR
        self.eur = eur if eur is not None and eur > 0 else self._calculate_eur_estimate()

        # Actual production data
        self.actual_production_data = actual_production_data or {}
        self.has_historical_data = bool(self.actual_production_data)

        # API well identifier
        self.api_number = api_number
        
        # Well source indicator: False = from existing data, True = from forecast/manually added
        self.is_new = is_new
        
        # Last known decline curve parameters for fallback when historical data is missing
        # These come from dim data (qi_latest_bopd, Di_per_month_latest)
        self.last_known_qi = last_known_qi
        self.last_known_di = last_known_di  # Di per month from dim data
        self.last_data_date = last_data_date  # Last date with actual data (t=0 for fallback decline)

        logger.debug(
            "WellAgent created: id=%s, type=%s, qi=%.0f bbl/day, eur=%.0f bbl, is_new=%s, "
            "days_on_prod=%d, prior_cumulative=%.0f bbl",
            unique_id, well_type, self.initial_production, self.eur, is_new,
            self.days_on_production, self.cumulative_production
        )

    def _validate_well_parameters(self) -> None:
        """
        Validate well type, configuration, and compliance requirements.
        
        Raises:
            ValueError: If any parameter is invalid or compliance rules are violated
        """
        # Validate well type
        if self.well_type not in WellType.values():
            raise ValueError(
                f"Unsupported well_type: {self.well_type}. "
                f"Valid types: {sorted(WellType.values())}"
            )
        
        # Validate configuration
        if self.configuration not in WellConfiguration.values():
            raise ValueError(
                f"Unsupported configuration: {self.configuration}. "
                f"Valid types: {sorted(WellConfiguration.values())}"
            )
        
        # Validate decline type
        if self.decline_type not in DeclineType.values():
            raise ValueError(
                f"Unsupported decline_type: {self.decline_type}. "
                f"Valid types: {sorted(DeclineType.values())}"
            )

        # COMPLIANCE: Offshore wells must be exclusively conventional
        if (self.location and isinstance(self.location, str) and 
            "offshore" in self.location.lower()):
            if "conventional" not in self.well_type.lower():
                raise ValueError(
                    f"Offshore wells must be exclusively conventional (Handbook compliance). "
                    f"Got well_type='{self.well_type}' for location='{self.location}'"
                )

    def _assign_crude_grade(self) -> str:
        """
        Assign crude grade based on well type probability distribution.
        
        Returns:
            Crude grade string based on well type probabilities
        """
        if self.well_type not in CRUDE_GRADE_PROBABILITIES:
            return "Light Sweet"  # Default fallback

        probs = CRUDE_GRADE_PROBABILITIES[self.well_type]
        grades = list(probs.keys())
        probabilities = list(probs.values())

        return self.random.choices(grades, weights=probabilities, k=1)[0]

    def _validate_inputs(self) -> None:
        """Validate production parameters."""
        if self.initial_production <= 0:
            raise ValueError("initial_production must be > 0")
        if self.decline_exponent < 0:
            raise ValueError("decline_exponent must be ≥ 0")
        if self.nominal_decline_rate < 0:
            raise ValueError("nominal_decline_rate must be ≥ 0")
        if self.max_capacity < self.initial_production:
            self.max_capacity = self.initial_production

    def _calculate_prior_cumulative_production(self, days_before_sim: int) -> float:
        """
        Calculate cumulative production for days before simulation start.
        
        For wells that started producing before the simulation begins,
        this calculates how much they would have produced using the decline curve.
        
        Args:
            days_before_sim: Number of days the well produced before simulation start
            
        Returns:
            Cumulative production in barrels
        """
        if days_before_sim <= 0:
            return 0.0
        
        total = 0.0
        drive_factor = DRIVE_MECHANISM_DECLINE_MULTIPLIER.get(
            self.drive_mechanism, 1.0
        )
        effective_decline = self.nominal_decline_rate * drive_factor
        
        for day in range(days_before_sim):
            t_years = day / CONSTANTS.DAYS_IN_YEAR
            
            if self.decline_exponent == 0:
                # Exponential decline
                q_t = self.initial_production * math.exp(-effective_decline * t_years)
            else:
                # Hyperbolic/Harmonic decline
                denom = 1 + (self.decline_exponent * effective_decline * t_years)
                if denom <= 0:
                    break
                q_t = self.initial_production / (denom ** (1.0 / self.decline_exponent))
            
            # ECR: One-time 15% uplift at start
            if self.ecr_enabled and day == 0:
                q_t *= CONSTANTS.ECR_UPLIFT_FACTOR
            
            if q_t < CONSTANTS.MIN_ECONOMIC_PRODUCTION:
                break
            
            total += q_t
        
        return total

    def is_economic(self, q: float) -> bool:
        """
        Check if production rate is economic.
        
        Args:
            q: Production rate in bbl/day
            
        Returns:
            True if production is above economic limit and within EUR
        """
        return (
            q >= CONSTANTS.MIN_ECONOMIC_PRODUCTION and 
            self.cumulative_production < self.eur
        )

    def _calculate_eur_estimate(
        self, 
        horizon_years: int = CONSTANTS.DEFAULT_EUR_HORIZON_YEARS
    ) -> float:
        """
        Calculate Estimated Ultimate Recovery.
        
        Uses decline curve integration over the horizon period to estimate
        total recoverable production.
        
        Args:
            horizon_years: Number of years for EUR estimation
            
        Returns:
            EUR in barrels
        """
        total = 0.0
        max_days = int(horizon_years * CONSTANTS.DAYS_IN_YEAR)
        
        for day in range(max_days):
            t_years = day / CONSTANTS.DAYS_IN_YEAR
            drive_factor = DRIVE_MECHANISM_DECLINE_MULTIPLIER.get(
                self.drive_mechanism, 1.0
            )
            effective_decline = self.nominal_decline_rate * drive_factor
            
            if self.decline_exponent == 0:
                # Exponential decline
                q_t = self.initial_production * math.exp(-effective_decline * t_years)
            else:
                # Hyperbolic/Harmonic decline
                denom = 1 + (self.decline_exponent * effective_decline * t_years)
                if denom <= 0:
                    break
                q_t = self.initial_production / (denom ** (1.0 / self.decline_exponent))
            
            # ECR: One-time 15% uplift at start
            if self.ecr_enabled and t_years < 0.01:
                q_t *= CONSTANTS.ECR_UPLIFT_FACTOR
            
            if q_t < CONSTANTS.MIN_ECONOMIC_PRODUCTION:
                break
            
            total += q_t
        
        return total

    def _compute_decline_rate(self) -> float:
        """
        Compute daily production rate using decline curve.
        
        Returns:
            Production rate in bbl/day
        """
        t_years = self.days_on_production / CONSTANTS.DAYS_IN_YEAR
        drive_factor = DRIVE_MECHANISM_DECLINE_MULTIPLIER.get(
            self.drive_mechanism, 1.0
        )
        effective_decline = self.nominal_decline_rate * drive_factor
        
        if self.decline_exponent == 0:
            # Exponential decline
            q_t = self.initial_production * math.exp(-effective_decline * t_years)
        else:
            # Hyperbolic/Harmonic decline
            denom = 1 + (self.decline_exponent * effective_decline * t_years)
            if denom <= 0:
                return 0.0
            q_t = self.initial_production / (denom ** (1.0 / self.decline_exponent))
        
        # ECR: One-time 15% uplift at start
        if self.ecr_enabled and self.days_on_production == 1:
            q_t *= CONSTANTS.ECR_UPLIFT_FACTOR
        
        return q_t

    def _compute_fallback_decline_rate(self) -> float:
        """
        Compute production rate using decline curve when historical data is missing.
        
        This is used for wells that have historical production data but the current
        simulation date is beyond the last available data date. Uses qi and di from
        dim data (last known values) as the starting point for decline curve projection.
        
        The time t=0 is set to last_data_date, and we calculate decline from there.
        
        Returns:
            Production rate in bbl/day, or 0.0 if fallback parameters are not available
        """
        # Use last_known_qi if present; otherwise fall back to conventional onshore defaults
        fallback_params = get_well_type_defaults(WellType.CONVENTIONAL_ONSHORE.value)
        fallback_qi = self.last_known_qi if self.last_known_qi and self.last_known_qi > 0 else fallback_params["initial_production"]
        if fallback_qi is None or fallback_qi <= 0:
            return 0.0
        
        # Calculate days since last data date
        if self.last_data_date is not None:
            days_since_last_data = (self.model.current_date - self.last_data_date).days
        else:
            # If no last_data_date, use days_on_production as fallback
            days_since_last_data = self.days_on_production
        
        if days_since_last_data < 0:
            # Current date is before last data date, shouldn't happen but handle gracefully
            return fallback_qi
        
        t_years = days_since_last_data / CONSTANTS.DAYS_IN_YEAR
        
        # Use last_known_di if available, otherwise fall back to conventional onshore nominal decline
        # last_known_di is per month, convert to annual
        if self.last_known_di is not None and self.last_known_di > 0:
            # Di per month -> annualized (multiply by 12)
            effective_decline = self.last_known_di * 12
        else:
            # Fall back to conventional onshore nominal decline with drive mechanism adjustment
            drive_factor = DRIVE_MECHANISM_DECLINE_MULTIPLIER.get(
                self.drive_mechanism, 1.0
            )
            fallback_nominal_decline = fallback_params["nominal_decline_rate"]
            effective_decline = fallback_nominal_decline * drive_factor
        
        # Use well's b-factor (decline_exponent) for the curve shape
        if self.decline_exponent == 0:
            # Exponential decline
            q_t = fallback_qi * math.exp(-effective_decline * t_years)
        else:
            # Hyperbolic/Harmonic decline
            denom = 1 + (self.decline_exponent * effective_decline * t_years)
            if denom <= 0:
                return 0.0
            q_t = fallback_qi / (denom ** (1.0 / self.decline_exponent))
        
        return max(0.0, q_t)

    def set_well_status(self, status: str) -> None:
        """
        Update well status.
        
        Args:
            status: New status (Active, Choked, Inactive)
            
        Raises:
            ValueError: If status is not valid
        """
        allowed_statuses = {"Active", "Choked", "Inactive"}
        if status not in allowed_statuses:
            raise ValueError(f"Invalid well status: {status}")
        self.status = status
        self.is_active = (status == "Active")

    def set_well_production_capacity(
        self, 
        new_capacity: float, 
        recalc_eur: bool = True
    ) -> None:
        """
        Update well production capacity.
        
        Args:
            new_capacity: New maximum capacity in bbl/day
            recalc_eur: Whether to recalculate EUR
            
        Raises:
            ValueError: If capacity is negative
        """
        if new_capacity < 0:
            raise ValueError("Production capacity must be non-negative")
        self.max_capacity = new_capacity
        if recalc_eur:
            self.eur = self._calculate_eur_estimate()

    def step(self) -> None:
        """
        Execute one simulation step (one day).
        
        Updates production cost, checks production dates, calculates
        potential production, and updates well state.
        """
        # Update production cost
        base_cost = CONSTANTS.BASE_OPEX_PER_DAY
        config_multiplier = CONFIGURATION_MULTIPLIER.get(self.configuration, 1.0)
        self.production_cost = (
            base_cost * config_multiplier + 
            CONSTANTS.VARIABLE_OPEX_FACTOR * max(self.daily_production, 0.0)
        )

        # Not started yet
        if self.model.current_date < self.production_start_date:
            self.daily_production = 0.0
            self.is_active = False
            return

        # Check if well has reached its end date
        if self.production_end_date and self.model.current_date >= self.production_end_date:
            self.daily_production = 0.0
            self.is_active = False
            return

        # Well has reached production start date
        if self.model.current_date >= self.production_start_date:
            if not self.is_active and self.status == "Active":
                self.is_active = True
            self.days_on_production += 1

        # Handle 'Choked' status
        if self.status == "Choked":
            self.daily_production = 0.5 * self.daily_potential_production
            return

        if not self.is_active:
            self.daily_production = 0.0
            return

        # Check for actual production data
        current_date_str = self.model.current_date.strftime('%Y-%m-%d')
        actual_production = self.actual_production_data.get(current_date_str)

        if self.has_historical_data:
            if actual_production is not None:
                # Use actual production data when available
                potential = actual_production
            else:
                # Historical data well but no data for this date - use decline curve fallback
                potential = self._compute_fallback_decline_rate()
        else:
            potential = self._compute_decline_rate()

        # Economic limit check
        if not self.is_economic(potential) or potential is None:
            self.daily_potential_production = 0.0
            self.daily_production = 0.0
            return
        
        if isinstance(potential, float) and (math.isnan(potential) or math.isinf(potential) or potential < 0):
            self.daily_potential_production = 0.0
            self.daily_production = 0.0
            return

        # Set POTENTIAL production - BasinModel owns REALIZED production
        self.daily_potential_production = potential
        self.daily_production = 0.0

    def get_state(self) -> Dict[str, Any]:
        """
        Get current well state as dictionary.
        
        Returns:
            Dictionary containing all well state attributes
        """
        return {
            "id": self.unique_id,
            "api_number": self.api_number,
            "well_type": self.well_type,
            "crude_grade": self.crude_grade,
            "decline_type": self.decline_type,
            "location": self.location,
            "basin": self.basin,
            "drilling_date": self.drilling_date.isoformat() if self.drilling_date else None,
            "production_start_date": self.production_start_date.isoformat(),
            "production_end_date": self.production_end_date.isoformat() if self.production_end_date else None,
            "drive_mechanism": self.drive_mechanism,
            "configuration": self.configuration,
            "operational_status": self.operational_status,
            "initial_production": self.initial_production,
            "daily_potential_production": self.daily_potential_production,
            "daily_production": self.daily_production,
            "cumulative_production": self.cumulative_production,
            "eur": self.eur,
            "recovery_percentage": (self.cumulative_production / self.eur * 100) if self.eur else 0,
            "days_on_production": self.days_on_production,
            "decline_exponent": self.decline_exponent,
            "nominal_decline_rate": self.nominal_decline_rate,
            "max_capacity": self.max_capacity,
            "ecr_enabled": self.ecr_enabled,
            "status": self.status,
            "is_active": self.is_active,
            "production_cost": self.production_cost,
            "is_new": self.is_new,
        }

    def get_minimal_state(self) -> Dict[str, Any]:
        """
        Get minimal state for efficient t-1 storage.
        
        Returns:
            Dictionary with only essential state values
        """
        return {
            "days_on_production": self.days_on_production,
            "cumulative_production": self.cumulative_production,
            "daily_production": self.daily_production,
            "is_active": self.is_active,
            "status": self.status,
            "production_end_date": self.production_end_date.isoformat() if self.production_end_date else None,
        }

    def get_derived_potential_production(self, days_on_production: int) -> float:
        """
        Calculate potential production from days.
        
        Pure function that can derive daily_potential_production from
        days_on_production without storing it explicitly.
        
        Args:
            days_on_production: Number of days the well has been producing
            
        Returns:
            Potential production in bbl/day
        """
        t_years = days_on_production / CONSTANTS.DAYS_IN_YEAR
        drive_factor = DRIVE_MECHANISM_DECLINE_MULTIPLIER.get(
            self.drive_mechanism, 1.0
        )
        effective_decline = self.nominal_decline_rate * drive_factor
        
        if self.decline_exponent == 0:
            q_t = self.initial_production * math.exp(-effective_decline * t_years)
        else:
            denom = 1 + (self.decline_exponent * effective_decline * t_years)
            if denom <= 0:
                return 0.0
            q_t = self.initial_production / (denom ** (1.0 / self.decline_exponent))
        
        if self.ecr_enabled and days_on_production == 1:
            q_t *= CONSTANTS.ECR_UPLIFT_FACTOR
        
        return q_t

    def get_static_params(self) -> Dict[str, Any]:
        """
        Get static parameters that don't change during simulation.
        
        Returns:
            Dictionary of static well parameters
        """
        return {
            "id": self.unique_id,
            "api_number": self.api_number,
            "well_type": self.well_type,
            "crude_grade": self.crude_grade,
            "decline_type": self.decline_type,
            "location": self.location,
            "basin": self.basin,
            "drilling_date": self.drilling_date.isoformat() if self.drilling_date else None,
            "production_start_date": self.production_start_date.isoformat(),
            "drive_mechanism": self.drive_mechanism,
            "configuration": self.configuration,
            "initial_production": self.initial_production,
            "decline_exponent": self.decline_exponent,
            "nominal_decline_rate": self.nominal_decline_rate,
            "max_capacity": self.max_capacity,
            "eur": self.eur,
            "ecr_enabled": self.ecr_enabled,
        }

    def reconstruct_state_from_minimal(
        self, 
        minimal_state: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Reconstruct full state from minimal state.
        
        Args:
            minimal_state: State dict from get_minimal_state()
            
        Returns:
            Full state dict equivalent to get_state()
        """
        days = minimal_state["days_on_production"]
        cumulative = minimal_state["cumulative_production"]
        
        derived_potential = self.get_derived_potential_production(days)
        
        base_cost = CONSTANTS.BASE_OPEX_PER_DAY
        config_multiplier = CONFIGURATION_MULTIPLIER.get(self.configuration, 1.0)
        production_cost = (
            base_cost * config_multiplier + 
            CONSTANTS.VARIABLE_OPEX_FACTOR * max(minimal_state["daily_production"], 0.0)
        )
        
        return {
            **self.get_static_params(),
            "production_end_date": minimal_state["production_end_date"],
            "daily_potential_production": derived_potential,
            "daily_production": minimal_state["daily_production"],
            "cumulative_production": cumulative,
            "recovery_percentage": (cumulative / self.eur * 100) if self.eur else 0,
            "days_on_production": days,
            "status": minimal_state["status"],
            "is_active": minimal_state["is_active"],
            "production_cost": production_cost,
            "operational_status": "Active" if minimal_state["is_active"] else "Inactive",
        }


# Backwards compatibility alias
setWellStatus = WellAgent.set_well_status
setWellProductionCapacity = WellAgent.set_well_production_capacity
