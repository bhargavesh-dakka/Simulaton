"""
SimulationRunner - High-Level Simulation Interface.

This module provides a stable API for UI/frontend integration, wrapping
the BasinModel with validation, state management, and production reporting.

COMPLIANCE: SimOxy Simulation Runner
- Stable API for UI/frontend integration
- Well validation against handbook rules
- Regional reserve management
- Soft reset capability with well persistence
- Production history export for reporting
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional, List, Dict, Any, TYPE_CHECKING
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.simulation_config import (
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    VALIDATION_BOUNDS,
)
from utils.logging_config import get_logger
from exceptions import (
    SimulationNotInitializedError,
    WellValidationError,
    DateValidationError,
    OffshoreComplianceError,
)
from validators.well_validators import WellConfigSchema, validate_well_config
from .model import BasinModel

if TYPE_CHECKING:
    from .agents import WellAgent

# Module logger
logger = get_logger(__name__)


class SimulationRunner:
    """
    High-level runner for UI / API integration.

    Hierarchy: Country > Market Center > Basins > Wells

    COMPLIANCE:
    - Stable interface (no Mesa internals exposed)
    - Well validation against handbook rules
    - Supports soft reset with optional well persistence
    - Production and takeaway history export
    
    Attributes:
        model: The underlying BasinModel
        is_running: Whether simulation is currently running
        pause_requested: Whether pause has been requested
        total_steps: Total number of simulation steps
        completed_steps: Number of completed steps
    """

    __api_version__ = "1.1.0"

    def __init__(
        self,
        total_recoverable_resources: float,
        start_date: datetime,
        end_date: datetime,
        basin_name: str = "Permian Basin",
        market_center: str = "Permian",
        country: str = "US",
        basin_reserves: Optional[float] = None,
        load_from_excel: bool = False,
    ) -> None:
        """
        Initialize SimulationRunner.
        
        Args:
            total_recoverable_resources: Total recoverable oil (bbl)
            start_date: Simulation start date
            end_date: Simulation end date
            basin_name: Basin name
            market_center: Market center name
            country: Country code
            basin_reserves: Initial basin reserves (bbl)
            load_from_excel: Whether to load wells from Excel files
        """
        self._initial_basin_reserves = basin_reserves or total_recoverable_resources

        self.model = BasinModel(
            total_recoverable_resources=total_recoverable_resources,
            start_date=start_date,
            end_date=end_date,
            basin_name=basin_name,
            market_center=market_center,
            country=country,
            basin_reserves=basin_reserves,
        )

        self.is_running = False
        self.pause_requested = False
        self.total_steps = max(0, (end_date - start_date).days)
        self.completed_steps = 0

        # Persist well configs for soft reset
        self._well_configs: List[Dict[str, Any]] = []

        if load_from_excel:
            self._load_wells_from_excel()
        
        logger.info(
            "SimulationRunner initialized: basin=%s, period=%s to %s, total_steps=%d",
            basin_name,
            start_date.isoformat(),
            end_date.isoformat(),
            self.total_steps
        )

    def get_summary(self) -> Dict[str, Any]:
        """
        Return a summary of the simulation configuration and state.
        
        Returns:
            Dictionary with simulation summary
        """
        return {
            "basin_name": getattr(self.model, "basin_name", None),
            "country": getattr(self.model, "basin_country", None),
            "market_center": getattr(self.model, "basin_market_center", None),
            "start_date": getattr(self.model, "start_date", None),
            "end_date": getattr(self.model, "end_date", None),
            "total_recoverable_resources": getattr(self.model, "basin_total_recoverable_resources", None),
            "remaining_reserves": getattr(self.model, "basin_remaining_reserves", None),
            "cumulative_production": getattr(self.model, "basin_cumulative_production", None),
            "recovery_factor": getattr(self.model, "basin_recovery_factor", None),
            "num_wells": len(getattr(self.model, "basin_wells", [])),
        }

    def count_wells_in_simulation_range(self) -> int:
        """
        Return the number of wells currently loaded in the simulation.
        
        Returns:
            Number of wells in the model
        """
        return len(getattr(self.model, "basin_wells", []))

    # ------------------------------------------------------------------
    # CONFIGURATION
    # ------------------------------------------------------------------
    def set_drilling_constraints(self, constraints: Dict[str, Any]) -> None:
        """
        Set drilling constraints for the underlying BasinModel.
        
        Args:
            constraints: Dictionary of well_type -> max_wells_per_quarter
            
        Raises:
            AttributeError: If model doesn't support drilling constraints
        """
        if hasattr(self.model, "drilling_constraints"):
            self.model.drilling_constraints = constraints
            logger.info("Drilling constraints updated: %s", constraints)
        else:
            raise AttributeError("BasinModel does not support drilling constraints.")

    # ------------------------------------------------------------------
    # WELL LOADING
    # ------------------------------------------------------------------
    def _load_wells_from_excel(self) -> None:
        """Load wells from Excel data files with schema validation."""
        from utils.data_loader import load_and_merge_well_data
        
        wells_data, _ = load_and_merge_well_data(
            start_date=self.model.start_date,
            end_date=self.model.end_date,
            basin_name=self.model.basin_name,
            market_center=self.model.market_center,
            country=self.model.basin_country
        )

        required_fields = {
            "initial_production",
            "well_type",
            "decline_type",
            "b_factor",
            "nominal_decline_rate",
            "location",
            "basin",
            "production_start_date",
            "historical_production",
            "api_number",
        }

        for well_data in wells_data:
            missing = required_fields - well_data.keys()
            if missing:
                raise WellValidationError(
                    f"Well data missing required fields: {missing}",
                    field=str(missing)
                )

            well_data = dict(well_data)
            well_data.pop('api', None)

            well_config = {
                "initial_production": well_data["initial_production"],
                "well_type": well_data["well_type"],
                "decline_type": well_data["decline_type"],
                "b_factor": well_data["b_factor"],
                "nominal_decline_rate": well_data["nominal_decline_rate"],
                "location": well_data["location"],
                "basin": well_data["basin"],
                "production_start_date": well_data["production_start_date"],
                "actual_production_data": well_data["historical_production"],
                "api_number": well_data["api_number"],
                "operational_status": "Active",
                "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
                "configuration": WellConfiguration.VERTICAL.value,
                "ecr_enabled": False,
                # Fallback decline curve parameters from dim data
                "last_known_qi": well_data.get("last_known_qi", well_data["initial_production"]),
                "last_known_di": well_data.get("last_known_di"),
                "last_data_date": well_data.get("last_data_date"),
            }

            self._validate_well_config(well_config)
            self.model.add_well(**well_config)
            self._well_configs.append(dict(well_config))

    # ------------------------------------------------------------------
    # WELL MANAGEMENT
    # ------------------------------------------------------------------
    def _validate_well_config(self, cfg: Dict[str, Any]) -> None:
        """
        Validate well configuration against handbook rules.
        
        Args:
            cfg: Well configuration dictionary
            
        Raises:
            WellValidationError: If configuration is invalid
            DateValidationError: If dates are invalid
            OffshoreComplianceError: If offshore compliance fails
        """
        # Validate b_factor
        b_factor = cfg.get("b_factor", 0)
        if b_factor < VALIDATION_BOUNDS.B_FACTOR_MIN or b_factor > VALIDATION_BOUNDS.B_FACTOR_MAX:
            raise WellValidationError(
                f"b_factor out of compliance range ({VALIDATION_BOUNDS.B_FACTOR_MIN}–{VALIDATION_BOUNDS.B_FACTOR_MAX})",
                field="b_factor",
                value=b_factor,
                constraint=f"Must be between {VALIDATION_BOUNDS.B_FACTOR_MIN} and {VALIDATION_BOUNDS.B_FACTOR_MAX}"
            )

        # Validate decline rate
        decline_rate = cfg.get("nominal_decline_rate", 0)
        if decline_rate <= 0:
            raise WellValidationError(
                "Nominal decline rate must be positive",
                field="nominal_decline_rate",
                value=decline_rate,
                constraint="Must be > 0"
            )

        # Validate production_start_date
        prod_start = cfg.get("production_start_date")
        if prod_start is not None:
            if not isinstance(prod_start, datetime):
                raise WellValidationError(
                    "production_start_date must be a datetime object",
                    field="production_start_date",
                    value=type(prod_start).__name__
                )
            # Note: Wells with production_start_date before simulation start are allowed
            # These are existing wells that were already producing when the simulation begins

        # Validate offshore compliance
        location = cfg.get("location", "")
        well_type = cfg.get("well_type", "")
        if isinstance(location, str) and "offshore" in location.lower():
            if well_type != WellType.CONVENTIONAL_OFFSHORE.value:
                raise OffshoreComplianceError(
                    "Offshore wells must use 'Conventional Offshore' (COMPLIANCE)",
                    well_type=well_type,
                    location=location
                )

    def add_well(self, **kwargs) -> Dict[str, Any]:
        """
        Add a well and return its state (COMPLIANCE validated).
        
        Args:
            **kwargs: Well configuration parameters
            
        Returns:
            Dictionary containing the created well's state
            
        Raises:
            WellValidationError: If configuration is invalid
        """
        self._validate_well_config(kwargs)

        well = self.model.add_well(**kwargs)

        cfg = dict(kwargs)
        cfg.setdefault("well_type", well.well_type)
        cfg.setdefault("basin", well.basin)
        self._well_configs.append(cfg)

        logger.debug(
            "Well added via runner: id=%d, type=%s",
            well.unique_id,
            well.well_type
        )

        return well.get_state()

    # ------------------------------------------------------------------
    # SIMULATION CONTROL
    # ------------------------------------------------------------------
    def start(self) -> None:
        """Start the simulation."""
        self.is_running = True
        self.model.simulation_active = True
        logger.info("Simulation started")

    def pause(self) -> None:
        """Pause the simulation."""
        self.pause_requested = True
        logger.info("Simulation pause requested")

    def resume(self) -> None:
        """Resume the simulation."""
        self.pause_requested = False
        logger.info("Simulation resumed")

    def step(self) -> Dict[str, Any]:
        """
        Execute one simulation step.
        
        Returns:
            Current simulation state
        """
        if self.pause_requested or not self.model.simulation_active:
            return self.get_state()

        self.model.step()

        if self.model.simulation_active:
            self.completed_steps += 1

        if self.completed_steps >= self.total_steps:
            self.model.simulation_active = False
            self.is_running = False
            logger.info("Simulation completed: %d steps", self.completed_steps)

        return self.get_state()

    def run_steps(
        self, 
        num_steps: int, 
        return_all: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Run multiple simulation steps.
        
        Args:
            num_steps: Number of steps to run
            return_all: If True, return state after each step
            
        Returns:
            List of state dictionaries
        """
        states: List[Dict[str, Any]] = []

        for _ in range(num_steps):
            if not self.model.simulation_active:
                break
            state = self.step()
            if return_all:
                states.append(state)

        return states if return_all else [self.get_state()]

    # ------------------------------------------------------------------
    # STATE ACCESS
    # ------------------------------------------------------------------
    def get_state(self) -> Dict[str, Any]:
        """
        Get current simulation state with progress information.
        
        Returns:
            Dictionary with state and progress
        """
        sim_state = self.model.get_simulation_state()
        return {
            "state": sim_state,
            "progress": {
                "completed_steps": self.completed_steps,
                "total_steps": self.total_steps,
                "percentage": (
                    self.completed_steps / self.total_steps * 100
                    if self.total_steps > 0
                    else 0
                ),
            },
        }

    def get_production_data(self) -> Dict[str, Any]:
        """
        Get production data including history and basin state.
        
        Returns:
            Dictionary with production data
        """
        history = self.model.get_production_history()

        basin_state = {
            "name": self.model.basin_name,
            "country": self.model.basin_country,
            "market_center": self.model.basin_market_center,
            "total_recoverable_resources": self.model.basin_total_recoverable_resources,
            "remaining_reserves": self.model.basin_remaining_reserves,
            "cumulative_production": self.model.basin_cumulative_production,
            "recovery_factor": self.model.basin_recovery_factor,
            "num_wells": len(self.model.basin_wells),
            "wells": [w.get_state() for w in self.model.basin_wells],
        }

        return {
            "history": history,
            "basin": basin_state,
            "current_date": self.model.current_date.isoformat(),
        }

    # ------------------------------------------------------------------
    # RESET
    # ------------------------------------------------------------------
    def reset(self, keep_wells: bool = False) -> None:
        """
        Reset simulation; optionally restore wells.
        
        Args:
            keep_wells: If True, restore previously added wells
        """
        start_date = self.model.start_date
        end_date = self.model.end_date
        basin_name = self.model.basin_name
        market_center = self.model.market_center
        country = self.model.country

        configs = list(self._well_configs)
        self._well_configs.clear()

        self.model = BasinModel(
            total_recoverable_resources=self._initial_basin_reserves,
            start_date=start_date,
            end_date=end_date,
            basin_name=basin_name,
            market_center=market_center,
            country=country,
            basin_reserves=self._initial_basin_reserves,
        )

        self.completed_steps = 0
        self.is_running = False
        self.pause_requested = False

        if keep_wells:
            for cfg in configs:
                self.model.add_well(**cfg)
                self._well_configs.append(cfg)
        
        logger.info(
            "Simulation reset: keep_wells=%s, restored=%d wells",
            keep_wells,
            len(self._well_configs)
        )

    # ------------------------------------------------------------------
    # PIPELINE ACCESS
    # ------------------------------------------------------------------
    def get_pipeline_capacity(self) -> float:
        """
        Get pipeline maximum capacity.
        
        Returns:
            Maximum capacity in bbl/day
        """
        return self.model.pipeline.max_capacity

    def get_pipeline_utilization(self) -> Dict[str, Any]:
        """
        Get pipeline utilization details.
        
        Returns:
            Dictionary with utilization information
        """
        pipeline = self.model.pipeline
        return {
            "current_utilization": pipeline.current_utilization,
            "capacity": pipeline.max_capacity,
            "utilization_percentage": pipeline.get_utilization_percentage(),
            "total_transported": pipeline.total_transported,
            "is_operational": pipeline.is_operational,
            "days_operational": pipeline.days_operational,
        }

    def get_pipeline_state(self) -> Dict[str, Any]:
        """
        Get complete pipeline state.
        
        Returns:
            Dictionary with pipeline state
        """
        return self.model.pipeline.get_state()

    # ------------------------------------------------------------------
    # PRODUCTION VS TAKEAWAY
    # ------------------------------------------------------------------
    def get_production_vs_takeaway(self) -> List[Dict[str, Any]]:
        """
        Daily production vs pipeline takeaway comparison.
        
        Uses MinimalStateCollector - returns only current state (no history).
        
        Returns:
            List with single dictionary containing comparison data
        """
        current_state = self.model.datacollector.get_current_state()
        
        if not current_state:
            return []
        
        daily_prod = current_state["summary"]["total_daily_production"]
        transported = current_state["pipeline"]["current_utilization"]
        capacity = current_state["pipeline"]["max_capacity"]
        
        return [{
            "date": current_state["current_date"],
            "daily_production": daily_prod,
            "potential_production": current_state["summary"]["total_potential_production"],
            "pipeline_capacity": capacity,
            "pipeline_transported": transported,
            "pipeline_utilization_pct": (transported / capacity * 100) if capacity > 0 else 0,
            "pipeline_operational": current_state["pipeline"]["is_operational"],
            "gap": daily_prod - transported,
            "active_wells": current_state["summary"]["active_wells"],
            "total_wells": current_state["summary"]["total_wells"],
        }]
