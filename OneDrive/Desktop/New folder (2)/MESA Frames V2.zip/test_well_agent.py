"""
Test script for WellAgentSet
"""

from datetime import datetime, timedelta
import polars as pl

# Test imports
print('Testing imports...')
from simulation.agents.well_agent import WellAgentSet
from config.simulation_config import WellType, DeclineType, DriveMechanism, CONSTANTS
print('✓ Imports successful')


# Create a mock model class for testing
class MockModel:
    def __init__(self):
        self.start_date = datetime(2024, 1, 1)
        self.end_date = datetime(2024, 12, 31)
        self.current_date = datetime(2024, 1, 1)


def test_well_agent_set():
    # Test WellAgentSet initialization
    print('\nTesting WellAgentSet initialization...')
    model = MockModel()
    wells = WellAgentSet(model)
    print(f'✓ WellAgentSet created, initial count: {wells.agents.shape[0]}')

    # Test adding a single well
    print('\nTesting add_single_well...')
    wells.add_single_well(
        unique_id='well_001',
        well_type=WellType.SHALE_OIL.value,
        initial_production=500.0,
        decline_exponent=1.2,
        nominal_decline_rate=0.65,
        production_start_date=datetime(2024, 1, 1),
        drive_mechanism=DriveMechanism.SOLUTION_GAS_DRIVE.value,
    )
    print(f'✓ Single well added, count: {wells.agents.shape[0]}')

    # Test adding wells from DataFrame
    print('\nTesting add_wells from DataFrame...')
    wells_df = pl.DataFrame({
        'unique_id': ['well_002', 'well_003', 'well_004'],
        'well_type': [WellType.CONVENTIONAL_ONSHORE.value, WellType.SHALE_OIL.value, WellType.CONVENTIONAL_OFFSHORE.value],
        'initial_production': [200.0, 800.0, 1500.0],
        'decline_exponent': [0.5, 1.0, 0.8],
        'nominal_decline_rate': [0.15, 0.55, 0.20],
        'production_start_date': [datetime(2023, 6, 1), datetime(2024, 1, 1), datetime(2024, 2, 1)],
    })
    wells.add_wells(wells_df)
    print(f'✓ Wells from DataFrame added, total count: {wells.agents.shape[0]}')

    # Test step function
    print('\nTesting step() function...')
    result_df = wells.step()
    print(f'✓ Step executed')
    print(f'  Active wells: {wells.get_active_wells_count()}')
    print(f'  Total potential production: {wells.get_total_potential_production():.2f} bbl/day')

    # Advance simulation date and step again
    print('\nAdvancing 30 days and stepping...')
    model.current_date = datetime(2024, 2, 1)
    result_df = wells.step()
    print(f'✓ Step after 30 days')
    print(f'  Active wells: {wells.get_active_wells_count()}')
    print(f'  Total potential production: {wells.get_total_potential_production():.2f} bbl/day')

    # Test production by grade
    print('\nTesting get_production_by_grade...')
    by_grade = wells.get_production_by_grade()
    print(f'✓ Production by grade: {by_grade}')

    # Test wells summary
    print('\nTesting get_wells_summary...')
    summary = wells.get_wells_summary()
    print(f'✓ Summary:')
    print(f'  Total wells: {summary["total_wells"]}')
    print(f'  Active wells: {summary["active_wells"]}')
    print(f'  By well type: {summary["by_well_type"]}')

    # Test set_well_status
    print('\nTesting set_well_status...')
    # Get the unique_id (int) for well_001
    well_001_id = wells.agents.filter(pl.col('well_name') == 'well_001')['unique_id'][0]
    
    # First get production before choking
    wells.step()
    prod_before = wells.agents.filter(pl.col('well_name') == 'well_001')['daily_potential_production'][0]
    print(f'  Production before choke: {prod_before:.2f} bbl/day')
    
    wells.set_well_status([well_001_id], 'Choked')
    wells.step()
    choked_prod = wells.agents.filter(pl.col('well_name') == 'well_001')['daily_potential_production'][0]
    print(f'✓ Well choked, production reduced to: {choked_prod:.2f} bbl/day (expected ~50% of {prod_before:.2f})')

    # Test set_well_production_capacity
    print('\nTesting set_well_production_capacity...')
    well_002_id = wells.agents.filter(pl.col('well_name') == 'well_002')['unique_id'][0]
    wells.set_well_production_capacity([well_002_id], 100.0, recalc_eur=True)
    print(f'✓ Well production capacity updated')

    # Test prior cumulative production for existing wells
    print('\nTesting prior cumulative production...')
    existing_well = wells.agents.filter(pl.col('well_name') == 'well_002')
    cum_prod = existing_well['cumulative_production'][0]
    print(f'✓ Well_002 (started 2023-06-01) cumulative production: {cum_prod:.2f} bbl')

    print('\n' + '='*50)
    print('All tests passed! ✓')


if __name__ == '__main__':
    test_well_agent_set()
