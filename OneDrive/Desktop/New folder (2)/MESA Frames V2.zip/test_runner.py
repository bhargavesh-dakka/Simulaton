"""
Test module for SimulationRunner - validates all methods.
"""

import sys
from datetime import datetime, timedelta

import polars as pl

# Add parent to path for imports
sys.path.insert(0, '.')

from simulation.runner import SimulationRunner
from config.simulation_config import WellType


def test_init():
    """Test SimulationRunner initialization."""
    print("\n" + "="*60)
    print("TEST: __init__")
    print("="*60)
    
    runner = SimulationRunner(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
        basin_name="Test Basin",
        market_center="Permian",
        country="US",
    )
    
    assert runner.model is not None
    assert runner.is_running == False
    assert runner.pause_requested == False
    assert runner.total_steps == 30
    assert runner.completed_steps == 0
    
    print(f"✓ Model created: {runner.model.basin_name}")
    print(f"✓ Total steps: {runner.total_steps}")
    print(f"✓ is_running: {runner.is_running}")
    
    print("\n✓ __init__: PASSED")
    return runner


def test_get_summary(runner):
    """Test get_summary method."""
    print("\n" + "="*60)
    print("TEST: get_summary")
    print("="*60)
    
    summary = runner.get_summary()
    
    assert "basin_name" in summary
    assert "country" in summary
    assert "market_center" in summary
    assert "start_date" in summary
    assert "end_date" in summary
    assert "total_recoverable_resources" in summary
    assert "num_wells" in summary
    
    print(f"✓ Basin: {summary['basin_name']}")
    print(f"✓ Country: {summary['country']}")
    print(f"✓ Wells: {summary['num_wells']}")
    
    print("\n✓ get_summary: PASSED")


def test_count_wells_in_simulation_range(runner):
    """Test count_wells_in_simulation_range method."""
    print("\n" + "="*60)
    print("TEST: count_wells_in_simulation_range")
    print("="*60)
    
    count = runner.count_wells_in_simulation_range()
    assert count == 0  # No wells added yet
    print(f"✓ Well count (empty): {count}")
    
    print("\n✓ count_wells_in_simulation_range: PASSED")


def test_set_drilling_constraints(runner):
    """Test set_drilling_constraints method."""
    print("\n" + "="*60)
    print("TEST: set_drilling_constraints")
    print("="*60)
    
    constraints = {
        WellType.CONVENTIONAL_OFFSHORE.value: 5,
        "default": 100
    }
    
    runner.set_drilling_constraints(constraints)
    
    assert runner.model.drilling_constraints[WellType.CONVENTIONAL_OFFSHORE.value] == 5
    print(f"✓ Constraints set: {runner.model.drilling_constraints}")
    
    print("\n✓ set_drilling_constraints: PASSED")


def test_validate_well_config(runner):
    """Test _validate_well_config method."""
    print("\n" + "="*60)
    print("TEST: _validate_well_config")
    print("="*60)
    
    # Valid config should pass
    valid_config = {
        "b_factor": 1.0,
        "nominal_decline_rate": 0.05,
        "production_start_date": datetime(2024, 1, 1),
        "well_type": WellType.CONVENTIONAL_OFFSHORE.value,
    }
    
    try:
        runner._validate_well_config(valid_config)
        print("✓ Valid config passes validation")
    except Exception as e:
        print(f"✗ Valid config failed: {e}")
        raise
    
    # Invalid b_factor should fail
    invalid_config = {
        "b_factor": 5.0,  # Too high
        "nominal_decline_rate": 0.05,
    }
    
    try:
        runner._validate_well_config(invalid_config)
        print("✗ Invalid b_factor should have raised error")
        raise AssertionError("Expected WellValidationError")
    except Exception as e:
        if "b_factor" in str(e):
            print(f"✓ Invalid b_factor correctly rejected: {type(e).__name__}")
        else:
            raise
    
    print("\n✓ _validate_well_config: PASSED")


def test_add_well(runner):
    """Test add_well method."""
    print("\n" + "="*60)
    print("TEST: add_well")
    print("="*60)
    
    result = runner.add_well(
        well_name="TEST-001",
        well_type=WellType.CONVENTIONAL_OFFSHORE.value,
        initial_production=500.0,
        nominal_decline_rate=0.05,
        b_factor=1.0,
        qi_bopd=500.0,
        decline_rate=0.05,
    )
    
    assert "status" in result
    assert result["status"] == "added"
    print(f"✓ Well added: {result}")
    
    # Verify count increased
    count = runner.count_wells_in_simulation_range()
    assert count == 1
    print(f"✓ Well count now: {count}")
    
    print("\n✓ add_well: PASSED")


def test_start_pause_resume(runner):
    """Test start, pause, resume methods."""
    print("\n" + "="*60)
    print("TEST: start, pause, resume")
    print("="*60)
    
    # Start
    runner.start()
    assert runner.is_running == True
    assert runner.model.simulation_active == True
    print("✓ start(): is_running=True")
    
    # Pause
    runner.pause()
    assert runner.pause_requested == True
    print("✓ pause(): pause_requested=True")
    
    # Resume
    runner.resume()
    assert runner.pause_requested == False
    print("✓ resume(): pause_requested=False")
    
    print("\n✓ start/pause/resume: PASSED")


def test_step(runner):
    """Test step method."""
    print("\n" + "="*60)
    print("TEST: step")
    print("="*60)
    
    initial_steps = runner.completed_steps
    
    state = runner.step()
    
    assert "state" in state
    assert "progress" in state
    assert runner.completed_steps == initial_steps + 1
    
    print(f"✓ Step completed: {runner.completed_steps}")
    print(f"✓ State keys: {list(state.keys())}")
    print(f"✓ Progress: {state['progress']['percentage']:.1f}%")
    
    print("\n✓ step: PASSED")


def test_run_steps(runner):
    """Test run_steps method."""
    print("\n" + "="*60)
    print("TEST: run_steps")
    print("="*60)
    
    initial_steps = runner.completed_steps
    
    # Run 5 steps
    states = runner.run_steps(5, return_all=True)
    
    assert len(states) == 5
    assert runner.completed_steps == initial_steps + 5
    
    print(f"✓ Ran 5 steps, total now: {runner.completed_steps}")
    print(f"✓ States returned: {len(states)}")
    
    print("\n✓ run_steps: PASSED")


def test_get_state(runner):
    """Test get_state method."""
    print("\n" + "="*60)
    print("TEST: get_state")
    print("="*60)
    
    state = runner.get_state()
    
    assert "state" in state
    assert "progress" in state
    assert "is_running" in state
    assert "pause_requested" in state
    
    print(f"✓ State structure valid")
    print(f"✓ Progress: {state['progress']['completed_steps']}/{state['progress']['total_steps']}")
    print(f"✓ Avg step time: {state['progress']['avg_step_time_ms']:.2f}ms")
    
    print("\n✓ get_state: PASSED")


def test_get_production_data(runner):
    """Test get_production_data method."""
    print("\n" + "="*60)
    print("TEST: get_production_data")
    print("="*60)
    
    data = runner.get_production_data()
    
    assert "history" in data
    assert "basin" in data
    assert "current_date" in data
    
    print(f"✓ History entries: {len(data['history'])}")
    print(f"✓ Basin: {data['basin']['name']}")
    print(f"✓ Current date: {data['current_date']}")
    
    print("\n✓ get_production_data: PASSED")


def test_get_pipeline_capacity(runner):
    """Test get_pipeline_capacity method."""
    print("\n" + "="*60)
    print("TEST: get_pipeline_capacity")
    print("="*60)
    
    capacity = runner.get_pipeline_capacity()
    
    assert capacity > 0
    print(f"✓ Pipeline capacity: {capacity:,.0f} bbl/day")
    
    print("\n✓ get_pipeline_capacity: PASSED")


def test_get_pipeline_utilization(runner):
    """Test get_pipeline_utilization method."""
    print("\n" + "="*60)
    print("TEST: get_pipeline_utilization")
    print("="*60)
    
    util = runner.get_pipeline_utilization()
    
    assert "daily_transport" in util
    assert "capacity" in util
    assert "utilization_percentage" in util
    assert "cumulative_transported" in util
    
    print(f"✓ Daily transport: {util['daily_transport']:,.0f}")
    print(f"✓ Capacity: {util['capacity']:,.0f}")
    print(f"✓ Utilization: {util['utilization_percentage']:.2f}%")
    
    print("\n✓ get_pipeline_utilization: PASSED")


def test_get_pipeline_state(runner):
    """Test get_pipeline_state method."""
    print("\n" + "="*60)
    print("TEST: get_pipeline_state")
    print("="*60)
    
    state = runner.get_pipeline_state()
    
    assert isinstance(state, dict)
    print(f"✓ Pipeline state: {state}")
    
    print("\n✓ get_pipeline_state: PASSED")


def test_get_production_vs_takeaway(runner):
    """Test get_production_vs_takeaway method."""
    print("\n" + "="*60)
    print("TEST: get_production_vs_takeaway")
    print("="*60)
    
    comparison = runner.get_production_vs_takeaway()
    
    assert isinstance(comparison, list)
    if comparison:
        entry = comparison[0]
        assert "date" in entry
        assert "daily_production" in entry
        assert "pipeline_capacity" in entry
        assert "gap" in entry
        print(f"✓ Comparison entry: date={entry['date']}, production={entry['daily_production']:.0f}")
    else:
        print("✓ Empty comparison (no history yet)")
    
    print("\n✓ get_production_vs_takeaway: PASSED")


def test_reset(runner):
    """Test reset method."""
    print("\n" + "="*60)
    print("TEST: reset")
    print("="*60)
    
    # Reset without keeping wells
    runner.reset(keep_wells=False)
    
    assert runner.completed_steps == 0
    assert runner.is_running == False
    assert runner.count_wells_in_simulation_range() == 0
    
    print("✓ Reset without wells: count=0")
    
    # Add wells again
    runner.add_well(
        well_name="RESET-001",
        initial_production=500.0,
        nominal_decline_rate=0.05,
        b_factor=1.0,
        qi_bopd=500.0,
        decline_rate=0.05,
    )
    runner.add_well(
        well_name="RESET-002",
        initial_production=300.0,
        nominal_decline_rate=0.05,
        b_factor=1.0,
        qi_bopd=300.0,
        decline_rate=0.05,
    )
    
    assert runner.count_wells_in_simulation_range() == 2
    print("✓ Added 2 wells")
    
    # Reset keeping wells
    runner.reset(keep_wells=True)
    
    assert runner.completed_steps == 0
    assert runner.count_wells_in_simulation_range() == 2
    
    print("✓ Reset with keep_wells=True: count=2")
    
    print("\n✓ reset: PASSED")


def test_full_simulation():
    """Test a complete simulation run."""
    print("\n" + "="*60)
    print("TEST: Full Simulation Run")
    print("="*60)
    
    runner = SimulationRunner(
        total_recoverable_resources=10_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 15),  # 14 days
        basin_name="Full Test Basin",
    )
    
    # Add multiple wells
    for i in range(5):
        runner.add_well(
            well_name=f"FULL-{i:03d}",
            initial_production=1000.0 * (i + 1),
            nominal_decline_rate=0.05,
            b_factor=1.0,
            qi_bopd=1000.0 * (i + 1),
            decline_rate=0.05,
        )
    
    print(f"✓ Added 5 wells")
    
    # Run complete simulation
    results_df = runner.run_simulation()
    
    assert not results_df.is_empty()
    print(f"✓ Simulation completed: {results_df.shape[0]} steps")
    
    # Check final state
    summary = runner.get_summary()
    print(f"✓ Final cumulative production: {summary['cumulative_production']:,.0f} bbl")
    print(f"✓ Active wells: {summary['active_wells']}")
    
    # Check performance
    perf = runner.get_performance_metrics()
    print(f"✓ Avg step time: {perf['avg_step_time_ms']:.2f}ms")
    print(f"✓ Steps/second: {perf['steps_per_second']:.1f}")
    
    print("\n✓ Full Simulation: PASSED")


def run_all_tests():
    """Run all tests."""
    print("\n" + "="*60)
    print("RUNNING ALL SIMULATION RUNNER TESTS")
    print("="*60)
    
    passed = 0
    failed = 0
    
    try:
        # Create runner for sequential tests
        runner = test_init()
        passed += 1
        
        tests = [
            (test_get_summary, runner),
            (test_count_wells_in_simulation_range, runner),
            (test_set_drilling_constraints, runner),
            (test_validate_well_config, runner),
            (test_add_well, runner),
            (test_start_pause_resume, runner),
            (test_step, runner),
            (test_run_steps, runner),
            (test_get_state, runner),
            (test_get_production_data, runner),
            (test_get_pipeline_capacity, runner),
            (test_get_pipeline_utilization, runner),
            (test_get_pipeline_state, runner),
            (test_get_production_vs_takeaway, runner),
            (test_reset, runner),
        ]
        
        for test_func, arg in tests:
            try:
                test_func(arg)
                passed += 1
            except Exception as e:
                print(f"\n✗ {test_func.__name__} FAILED: {e}")
                import traceback
                traceback.print_exc()
                failed += 1
        
        # Full simulation test (standalone)
        try:
            test_full_simulation()
            passed += 1
        except Exception as e:
            print(f"\n✗ test_full_simulation FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
            
    except Exception as e:
        print(f"\n✗ test_init FAILED: {e}")
        import traceback
        traceback.print_exc()
        failed += 1
    
    print("\n" + "="*60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("="*60)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
