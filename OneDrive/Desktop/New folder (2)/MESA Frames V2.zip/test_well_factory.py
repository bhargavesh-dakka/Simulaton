"""
Test module for Well Factory - validates batch well creation.
"""

import sys
from datetime import datetime

import polars as pl

sys.path.insert(0, '.')

from simulation.model import BasinModel
from utils.well_factory import (
    WellCreationErrorType,
    FailedWellCreation,
    BatchCreationResult,
    validate_well_config,
    validate_configs_batch,
    validate_configs_vectorized,
    map_play_type_to_well_type,
    get_default_parameters,
    prepare_well_config,
    prepare_configs_from_forecast,
    prepare_configs_as_dataframe,
    create_wells_batch,
    create_wells_from_dataframe,
    create_wells_from_forecast,
    create_test_wells,
)
from config.simulation_config import WellType


def test_error_types():
    """Test error type enums and dataclasses."""
    print("\n" + "="*60)
    print("TEST: Error Types & Dataclasses")
    print("="*60)
    
    # Test FailedWellCreation
    failure = FailedWellCreation(
        config={"well_type": "Invalid"},
        error_type=WellCreationErrorType.INVALID_WELL_TYPE,
        error_message="Invalid well type",
        retry_possible=True
    )
    
    assert failure.error_type == WellCreationErrorType.INVALID_WELL_TYPE
    assert failure.retry_possible == True
    
    d = failure.to_dict()
    assert "error_type" in d
    assert d["error_type"] == "invalid_well_type"
    print(f"✓ FailedWellCreation: {d['error_type']}")
    
    # Test BatchCreationResult
    result = BatchCreationResult(
        total_attempted=100,
        total_created=95,
        total_failed=5
    )
    
    d = result.to_dict()
    assert d["success_rate"] == 95.0
    print(f"✓ BatchCreationResult: {d['success_rate']}% success rate")
    
    print("\n✓ Error Types & Dataclasses: PASSED")


def test_validate_well_config():
    """Test single config validation."""
    print("\n" + "="*60)
    print("TEST: validate_well_config")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    )
    
    # Valid config
    valid_config = {
        "well_type": WellType.SHALE_OIL.value,
        "production_start_date": datetime(2024, 1, 1),
        "b_factor": 1.0,
        "nominal_decline_rate": 0.05,
        "initial_production": 500.0,
    }
    
    error = validate_well_config(valid_config, model)
    assert error is None
    print("✓ Valid config passes validation")
    
    # Missing required field
    invalid_config = {"initial_production": 500.0}
    error = validate_well_config(invalid_config, model)
    assert error is not None
    assert error.error_type == WellCreationErrorType.VALIDATION_FAILED
    print(f"✓ Missing required fields rejected: {error.error_message}")
    
    # Invalid well type
    invalid_config = {
        "well_type": "InvalidType",
        "production_start_date": datetime(2024, 1, 1),
    }
    error = validate_well_config(invalid_config, model)
    assert error is not None
    assert error.error_type == WellCreationErrorType.INVALID_WELL_TYPE
    print(f"✓ Invalid well type rejected")
    
    # Invalid b_factor
    invalid_config = {
        "well_type": WellType.SHALE_OIL.value,
        "production_start_date": datetime(2024, 1, 1),
        "b_factor": 5.0,  # > 2
    }
    error = validate_well_config(invalid_config, model)
    assert error is not None
    assert error.error_type == WellCreationErrorType.INVALID_PARAMETERS
    print(f"✓ Invalid b_factor rejected")
    
    print("\n✓ validate_well_config: PASSED")


def test_validate_configs_batch():
    """Test batch validation."""
    print("\n" + "="*60)
    print("TEST: validate_configs_batch")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    )
    
    configs = [
        {  # Valid
            "well_type": WellType.SHALE_OIL.value,
            "production_start_date": datetime(2024, 1, 1),
            "initial_production": 500.0,
        },
        {  # Valid
            "well_type": WellType.CONVENTIONAL_ONSHORE.value,
            "production_start_date": datetime(2024, 2, 1),
            "initial_production": 300.0,
        },
        {  # Invalid - bad well type
            "well_type": "BadType",
            "production_start_date": datetime(2024, 3, 1),
        },
    ]
    
    valid, errors = validate_configs_batch(configs, model)
    
    assert len(valid) == 2
    assert len(errors) == 1
    print(f"✓ Batch validation: {len(valid)} valid, {len(errors)} invalid")
    
    print("\n✓ validate_configs_batch: PASSED")


def test_validate_configs_vectorized():
    """Test vectorized validation."""
    print("\n" + "="*60)
    print("TEST: validate_configs_vectorized")
    print("="*60)
    
    df = pl.DataFrame({
        "well_type": [WellType.SHALE_OIL.value, WellType.SHALE_OIL.value, "InvalidType"],
        "b_factor": [1.0, 0.5, 1.0],
        "nominal_decline_rate": [0.05, 0.03, 0.05],
        "initial_production": [500.0, 300.0, 400.0],
    })
    
    valid_df, invalid_df = validate_configs_vectorized(df)
    
    assert valid_df.shape[0] == 2
    assert invalid_df.shape[0] == 1
    print(f"✓ Vectorized validation: {valid_df.shape[0]} valid, {invalid_df.shape[0]} invalid")
    
    print("\n✓ validate_configs_vectorized: PASSED")


def test_map_play_type():
    """Test play type mapping."""
    print("\n" + "="*60)
    print("TEST: map_play_type_to_well_type")
    print("="*60)
    
    # Test known mappings
    assert map_play_type_to_well_type("SHALE") == WellType.SHALE_OIL.value
    print("✓ SHALE -> Shale Oil")
    
    # TIGHT maps to WellType.TIGHT in our config
    assert map_play_type_to_well_type("TIGHT") == WellType.TIGHT.value
    print(f"✓ TIGHT -> {WellType.TIGHT.value}")
    
    # Test unknown (should default)
    result = map_play_type_to_well_type("UNKNOWN_TYPE")
    assert result == WellType.CONVENTIONAL_ONSHORE.value
    print(f"✓ UNKNOWN_TYPE -> {result} (default)")
    
    print("\n✓ map_play_type_to_well_type: PASSED")


def test_get_default_parameters():
    """Test getting default parameters."""
    print("\n" + "="*60)
    print("TEST: get_default_parameters")
    print("="*60)
    
    defaults = get_default_parameters(WellType.SHALE_OIL.value)
    
    assert "initial_production" in defaults or "b_factor" in defaults
    print(f"✓ Got defaults for Shale Oil: {list(defaults.keys())}")
    
    print("\n✓ get_default_parameters: PASSED")


def test_prepare_well_config():
    """Test single config preparation."""
    print("\n" + "="*60)
    print("TEST: prepare_well_config")
    print("="*60)
    
    config = prepare_well_config(
        year=2024,
        month=6,
        play_type="SHALE",
        api_number=9000001,
        multiplier=1.2,
        model_basin="Permian Basin"
    )
    
    assert config["api_number"] == 9000001
    assert config["well_type"] == WellType.SHALE_OIL.value
    assert config["production_start_date"] == datetime(2024, 6, 1)
    assert config["basin"] == "Permian Basin"
    print(f"✓ Config prepared: API={config['api_number']}, type={config['well_type']}")
    
    print("\n✓ prepare_well_config: PASSED")


def test_prepare_configs_from_forecast():
    """Test preparing configs from forecast data."""
    print("\n" + "="*60)
    print("TEST: prepare_configs_from_forecast")
    print("="*60)
    
    forecast = [
        {"year": 2024, "month": 1, "play_type": "SHALE", "wells_count": 3},
        {"year": 2024, "month": 2, "play_type": "TIGHT", "wells_count": 2},
        {"year": 2024, "month": 3, "play_type": "OFFSHORE", "wells_count": 1},
    ]
    
    configs = prepare_configs_from_forecast(
        forecast_results=forecast,
        base_api_start=9000001,
        model_basin="Test Basin"
    )
    
    assert len(configs) == 6  # 3 + 2 + 1
    assert configs[0]["api_number"] == 9000001
    assert configs[5]["api_number"] == 9000006
    print(f"✓ Prepared {len(configs)} configs from forecast")
    print(f"  API range: {configs[0]['api_number']} - {configs[-1]['api_number']}")
    
    print("\n✓ prepare_configs_from_forecast: PASSED")


def test_prepare_configs_as_dataframe():
    """Test preparing configs as DataFrame."""
    print("\n" + "="*60)
    print("TEST: prepare_configs_as_dataframe")
    print("="*60)
    
    forecast = [
        {"year": 2024, "month": 1, "play_type": "SHALE", "wells_count": 5},
    ]
    
    df = prepare_configs_as_dataframe(
        forecast_results=forecast,
        base_api_start=9000001
    )
    
    assert isinstance(df, pl.DataFrame)
    assert df.shape[0] == 5
    assert "well_type" in df.columns
    print(f"✓ DataFrame shape: {df.shape}")
    
    print("\n✓ prepare_configs_as_dataframe: PASSED")


def test_create_wells_batch():
    """Test batch well creation."""
    print("\n" + "="*60)
    print("TEST: create_wells_batch")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=10_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
        basin_name="Test Basin",
    )
    
    configs = [
        {
            "well_name": f"BATCH-{i:03d}",
            "well_type": WellType.SHALE_OIL.value,
            "production_start_date": datetime(2024, 1, 1),
            "initial_production": 500.0,
            "qi_bopd": 500.0,
            "b_factor": 1.0,
            "decline_rate": 0.05,
            "nominal_decline_rate": 0.05,
        }
        for i in range(10)
    ]
    
    result = create_wells_batch(configs, model)
    
    assert result.total_attempted == 10
    assert result.total_created == 10
    assert result.total_failed == 0
    print(f"✓ Batch creation: {result.total_created}/{result.total_attempted} created")
    
    # Verify wells in model
    assert model.wells.agents.shape[0] == 10
    print(f"✓ Model has {model.wells.agents.shape[0]} wells")
    
    print("\n✓ create_wells_batch: PASSED")


def test_create_wells_from_dataframe():
    """Test creating wells from DataFrame."""
    print("\n" + "="*60)
    print("TEST: create_wells_from_dataframe")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=10_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    )
    
    wells_df = pl.DataFrame({
        "well_name": [f"DF-{i:03d}" for i in range(5)],
        "well_type": [WellType.SHALE_OIL.value] * 5,
        "production_start_date": [datetime(2024, 1, 1)] * 5,
        "initial_production": [500.0, 600.0, 700.0, 800.0, 900.0],
        "qi_bopd": [500.0, 600.0, 700.0, 800.0, 900.0],
        "b_factor": [1.0] * 5,
        "decline_rate": [0.05] * 5,
        "nominal_decline_rate": [0.05] * 5,
    })
    
    result = create_wells_from_dataframe(wells_df, model)
    
    assert result.total_created == 5
    print(f"✓ Created {result.total_created} wells from DataFrame")
    
    print("\n✓ create_wells_from_dataframe: PASSED")


def test_create_wells_from_forecast():
    """Test high-level forecast creation."""
    print("\n" + "="*60)
    print("TEST: create_wells_from_forecast")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=10_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
        basin_name="Permian Basin",
    )
    
    forecast = [
        {"year": 2024, "month": 1, "play_type": "SHALE", "wells_count": 5, "multiplier": 1.0},
        {"year": 2024, "month": 2, "play_type": "TIGHT", "wells_count": 3, "multiplier": 0.8},
    ]
    
    result = create_wells_from_forecast(
        forecast_results=forecast,
        model=model,
        base_api_start=9000001
    )
    
    assert result.total_attempted == 8
    assert result.total_created == 8
    print(f"✓ Created {result.total_created} wells from forecast")
    print(f"  Success rate: {result.to_dict()['success_rate']:.1f}%")
    
    print("\n✓ create_wells_from_forecast: PASSED")


def test_create_test_wells():
    """Test convenience function for test wells."""
    print("\n" + "="*60)
    print("TEST: create_test_wells")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=10_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    )
    
    result = create_test_wells(model, count=20, initial_production=1000.0)
    
    assert result.total_created == 20
    print(f"✓ Created {result.total_created} test wells")
    
    # Verify in model
    assert model.wells.agents.shape[0] == 20
    print(f"✓ Model has {model.wells.agents.shape[0]} wells")
    
    print("\n✓ create_test_wells: PASSED")


def run_all_tests():
    """Run all well factory tests."""
    print("\n" + "="*60)
    print("RUNNING ALL WELL FACTORY TESTS")
    print("="*60)
    
    tests = [
        test_error_types,
        test_validate_well_config,
        test_validate_configs_batch,
        test_validate_configs_vectorized,
        test_map_play_type,
        test_get_default_parameters,
        test_prepare_well_config,
        test_prepare_configs_from_forecast,
        test_prepare_configs_as_dataframe,
        test_create_wells_batch,
        test_create_wells_from_dataframe,
        test_create_wells_from_forecast,
        test_create_test_wells,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"\n✗ {test.__name__} FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "="*60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("="*60)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
