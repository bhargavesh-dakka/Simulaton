"""
Custom Exceptions for Mesa-Frames SimOxy Simulation Engine.

This module defines custom exception classes for handling
simulation-specific error conditions.
"""


from typing import Any


class SimulationError(Exception):
    """Base exception for all simulation errors."""
    pass


class SimulationNotInitializedError(SimulationError):
    """Raised when attempting operations before simulation is initialized."""
    
    def __init__(self, message: str = "Simulation has not been initialized"):
        self.message = message
        super().__init__(self.message)


class DataLoadError(SimulationError):
    """Raised when data loading fails."""
    
    def __init__(self, message: str, source: str = None):
        self.message = message
        self.source = source
        super().__init__(f"Data load error{f' from {source}' if source else ''}: {message}")


class WellValidationError(SimulationError):
    """Raised when well configuration validation fails."""
    
    def __init__(
        self, 
        message: str, 
        well_id: str = None, 
        field: str = None,
        value: Any = None,
        constraint: str = None
    ):
        self.message = message
        self.well_id = well_id
        self.field = field
        self.value = value
        self.constraint = constraint
        
        detail = f"Well {well_id}" if well_id else "Well"
        if field:
            detail += f" ({field})"
        if value is not None:
            detail += f" value={value}"
        if constraint:
            detail += f" [{constraint}]"
        super().__init__(f"{detail}: {message}")


class DateValidationError(SimulationError):
    """Raised when date validation fails."""
    
    def __init__(self, message: str, start_date=None, end_date=None):
        self.message = message
        self.start_date = start_date
        self.end_date = end_date
        
        detail = message
        if start_date and end_date:
            detail += f" (start={start_date}, end={end_date})"
        super().__init__(detail)


class ReserveDepletionError(SimulationError):
    """Raised when reserves are depleted."""
    
    def __init__(
        self, 
        message: str = "Basin reserves depleted",
        remaining: float = 0.0,
        requested: float = 0.0
    ):
        self.message = message
        self.remaining = remaining
        self.requested = requested
        super().__init__(
            f"{message} (remaining={remaining:.0f} bbl, requested={requested:.0f} bbl)"
        )


class OffshoreComplianceError(SimulationError):
    """Raised when offshore compliance rules are violated."""
    
    def __init__(self, message: str, well_type: str = None, location: str = None):
        self.message = message
        self.well_type = well_type
        self.location = location
        
        detail = message
        if well_type and location:
            detail += f" (well_type={well_type}, location={location})"
        super().__init__(detail)


class PipelineCapacityError(SimulationError):
    """Raised when pipeline capacity is exceeded."""
    
    def __init__(
        self, 
        message: str = "Pipeline capacity exceeded",
        capacity: float = 0.0,
        flow: float = 0.0
    ):
        self.message = message
        self.capacity = capacity
        self.flow = flow
        super().__init__(
            f"{message} (capacity={capacity:.0f} bbl/day, flow={flow:.0f} bbl/day)"
        )


class RefineryCapacityError(SimulationError):
    """Raised when refinery capacity is exceeded."""
    
    def __init__(
        self, 
        message: str = "Refinery capacity exceeded",
        refinery_id: str = None,
        capacity: float = 0.0,
        input_vol: float = 0.0
    ):
        self.message = message
        self.refinery_id = refinery_id
        self.capacity = capacity
        self.input_vol = input_vol
        
        detail = message
        if refinery_id:
            detail += f" (refinery={refinery_id})"
        super().__init__(
            f"{detail}: capacity={capacity:.0f}, input={input_vol:.0f}"
        )


class ConfigurationError(SimulationError):
    """Raised when configuration is invalid."""
    
    def __init__(self, message: str, parameter: str = None, value=None):
        self.message = message
        self.parameter = parameter
        self.value = value
        
        detail = message
        if parameter:
            detail += f" (parameter={parameter}"
            if value is not None:
                detail += f", value={value}"
            detail += ")"
        super().__init__(detail)


class DrillingConstraintError(SimulationError):
    """Raised when drilling constraints are violated."""
    
    def __init__(
        self, 
        message: str = "Drilling constraint violated",
        well_type: str = None,
        limit: int = 0,
        attempted: int = 0
    ):
        self.message = message
        self.well_type = well_type
        self.limit = limit
        self.attempted = attempted
        
        detail = message
        if well_type:
            detail += f" (well_type={well_type}, limit={limit}, attempted={attempted})"
        super().__init__(detail)


class ScenarioError(SimulationError):
    """Raised when scenario configuration is invalid."""
    
    def __init__(self, message: str, scenario_name: str = None):
        self.message = message
        self.scenario_name = scenario_name
        
        detail = message
        if scenario_name:
            detail = f"Scenario '{scenario_name}': {message}"
        super().__init__(detail)


class MesaFramesError(SimulationError):
    """Raised when mesa-frames specific operations fail."""
    
    def __init__(self, message: str, operation: str = None):
        self.message = message
        self.operation = operation
        
        detail = message
        if operation:
            detail = f"Mesa-frames {operation} failed: {message}"
        super().__init__(detail)
