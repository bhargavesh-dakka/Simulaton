"""
Configuration Package for Mesa-Frames SimOxy Simulation.

This package provides centralized configuration for the simulation engine.
"""

from .simulation_config import (
    # Enums
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    WellStatus,
    CrudeGrade,
    RefineryConfiguration,
    RefineryProduct,
    # Constants
    CONSTANTS,
    SimulationConstants,
    VALIDATION_BOUNDS,
    ValidationBounds,
    # Well parameters
    WELL_TYPE_PARAMETERS,
    DECLINE_TYPE_PARAMETERS,
    DRIVE_MECHANISM_DECLINE_MULTIPLIER,
    CONFIGURATION_MULTIPLIER,
    CRUDE_GRADE_PROBABILITIES,
    # Functions
    get_well_type_defaults,
    get_well_type_defaults_polars,
    get_decline_type_params_polars,
    get_drive_mechanism_multipliers_polars,
    get_configuration_multipliers_polars,
    # Refinery
    REFINERY_PRODUCTS,
    CRACK_PRODUCTS,
    LIGHT_PRODUCTS,
    DEFAULT_REFINERY_YIELDS,
    CRUDE_GRADE_TO_REFINERY_GRADE,
    get_default_refinery_yields_polars,
    # Mappings
    PLAY_TYPE_TO_WELL_TYPE,
    GRADE_KEY_MAPPING,
    GRADE_KEY_REVERSE_MAPPING,
)

__all__ = [
    # Enums
    "WellType",
    "DeclineType",
    "DriveMechanism",
    "WellConfiguration",
    "WellStatus",
    "CrudeGrade",
    "RefineryConfiguration",
    "RefineryProduct",
    # Constants
    "CONSTANTS",
    "SimulationConstants",
    "VALIDATION_BOUNDS",
    "ValidationBounds",
    # Well parameters
    "WELL_TYPE_PARAMETERS",
    "DECLINE_TYPE_PARAMETERS",
    "DRIVE_MECHANISM_DECLINE_MULTIPLIER",
    "CONFIGURATION_MULTIPLIER",
    "CRUDE_GRADE_PROBABILITIES",
    # Functions
    "get_well_type_defaults",
    "get_well_type_defaults_polars",
    "get_decline_type_params_polars",
    "get_drive_mechanism_multipliers_polars",
    "get_configuration_multipliers_polars",
    # Refinery
    "REFINERY_PRODUCTS",
    "CRACK_PRODUCTS",
    "LIGHT_PRODUCTS",
    "DEFAULT_REFINERY_YIELDS",
    "CRUDE_GRADE_TO_REFINERY_GRADE",
    "get_default_refinery_yields_polars",
    # Mappings
    "PLAY_TYPE_TO_WELL_TYPE",
    "GRADE_KEY_MAPPING",
    "GRADE_KEY_REVERSE_MAPPING",
]
