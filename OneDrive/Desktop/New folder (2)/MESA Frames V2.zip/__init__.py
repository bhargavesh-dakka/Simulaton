"""
Mesa-Frames Basin Simulation - Optimized Oil & Gas Simulation.

This package provides a high-performance basin simulation for oil & gas
production modeling using mesa-frames for vectorized agent operations.

FEATURES:
- Vectorized well production calculations
- Decline curve modeling (exponential, hyperbolic, harmonic)
- Pipeline capacity management
- Refinery product yield calculations
- Reserve depletion tracking

USAGE:
    from simulation import SimulationRunner
    from datetime import datetime
    
    runner = SimulationRunner(
        total_recoverable_resources=1_000_000_000,
        start_date=datetime(2020, 1, 1),
        end_date=datetime(2025, 12, 31),
        basin_name="Permian Basin",
        market_center="Permian",
        country="US",
    )
    
    # Add wells and run simulation
    results = runner.run_simulation()
"""

from simulation import (
    BasinModel,
    SimulationRunner,
    WellAgentSet,
    PipelineAgentSet,
    RefineryAgentSet,
)
from config import (
    WellType,
    DeclineType,
    DriveMechanism,
    CrudeGrade,
    WellConfiguration,
    CONSTANTS,
)

__all__ = [
    # Simulation
    "BasinModel",
    "SimulationRunner",
    "WellAgentSet",
    "PipelineAgentSet",
    "RefineryAgentSet",
    # Config
    "WellType",
    "DeclineType",
    "DriveMechanism",
    "CrudeGrade",
    "WellConfiguration",
    "CONSTANTS",
]

__version__ = "2.0.0"
__author__ = "Mesa-Frames Simulation Team"
