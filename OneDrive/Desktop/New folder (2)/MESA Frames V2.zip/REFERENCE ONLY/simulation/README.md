# Simulation Module Documentation

## Overview

The `simulation/` folder contains the core agent-based simulation engine for the SimOxy oil production simulation system. It implements a Mesa-based multi-agent model that simulates oil well production, pipeline infrastructure, and refinery operations over time.

## Architecture

The simulation follows a hierarchical agent-based architecture:

```
Country > Market Center > Basin > Wells
```

### Key Components

#### 1. BasinModel (`model.py`)
The main Mesa `Model` class that orchestrates the entire simulation.

**Key Features:**
- **Multi-Agent System**: Manages WellAgent, PipelineAgent, and RefineryAgent instances
- **Time Management**: Daily timestep simulation with date tracking
- **Data Collection**: Minimal state collection for memory efficiency
- **Reserve Tracking**: Handles basin-level reserve depletion and recovery factors
- **Grade Splits**: Market-specific crude quality distributions

**Core Methods:**
- `step()`: Advances simulation by one day
- `add_well()`: Adds new wells to the basin
- `load_reserves_data()`: Loads reserve estimates from CSV
- `load_grade_splits()`: Loads market-specific grade distributions

**Attributes:**
- `basin_wells`: List of WellAgent instances
- `pipeline`: PipelineAgent for takeaway capacity
- `current_date`: Current simulation date
- `reserves_data`: Reserve tracking information

#### 2. SimulationRunner (`runner.py`)
High-level interface for running simulations with configuration management.

**Key Features:**
- **Scenario Management**: Handles different drilling strategies and phases
- **Well Configuration**: Validates and manages well parameters
- **Soft Reset**: Preserves well configurations between runs
- **Progress Tracking**: Monitors simulation execution status

**Core Methods:**
- `start()`: Initializes simulation execution
- `step()`: Advances simulation one timestep
- `add_well()`: Adds wells with validation
- `reset()`: Soft reset preserving configurations

**Attributes:**
- `model`: Underlying BasinModel instance
- `is_running`: Execution status
- `total_steps`: Total simulation steps
- `completed_steps`: Progress counter

#### 3. Agent Classes (`agents/`)

##### WellAgent (`well_agent.py`)
Individual well production simulation with decline curve analysis.

**Production Models:**
- **Hyperbolic Decline**: `q = qi / (1 + b*Di*t)^(1/b)`
- **Exponential Decline**: `q = qi * e^(-Di*t)`
- **Harmonic Decline**: `q = qi / (1 + Di*t)`

**Key Features:**
- **Decline Curve Analysis**: Multiple decline models with drive mechanism effects
- **Economic Limits**: Automatic shut-in at minimum production thresholds
- **Historical Matching**: Uses actual production data when available
- **EUR Tracking**: Estimates ultimate recoverable reserves

**Configuration Parameters:**
- `initial_production`: Initial production rate (bbl/day)
- `nominal_decline_rate`: Annual decline rate
- `b_factor`: Hyperbolic exponent (0=exponential, 1=harmonic)
- `decline_type`: Decline curve model
- `drive_mechanism`: Reservoir drive type affecting decline

##### PipelineAgent (`pipeline_agent.py`)
Manages takeaway capacity and transportation infrastructure.

**Key Features:**
- **Capacity Constraints**: Limits production based on pipeline capacity
- **Utilization Tracking**: Monitors capacity utilization percentages
- **Storage Buffers**: Handles temporary storage during bottlenecks
- **Operational Status**: Tracks pipeline availability

##### RefineryAgent (`refinery_agent.py`)
Processes crude oil into refined products.

**Key Features:**
- **Product Yields**: Converts crude to gasoline, diesel, etc.
- **Grade Processing**: Handles different crude qualities
- **Capacity Limits**: Refinery throughput constraints
- **Market Demand**: Links to product demand curves

## Data Flow

### Initialization Phase
1. **Load Historical Data**: Production history and decline parameters
2. **Create Well Configurations**: Map historical wells to simulation parameters
3. **Initialize Agents**: Create WellAgent, PipelineAgent, RefineryAgent instances
4. **Set Initial Conditions**: Reserve levels, starting dates, capacities

### Execution Phase
1. **Daily Timestep Loop**:
   - Update current date
   - Calculate well production using decline curves
   - Check economic limits and shut-in wells
   - Update cumulative production
   - Apply capacity constraints
   - Track reserve depletion

2. **Scenario Logic**:
   - Apply drilling multipliers based on scenario phase
   - Add new wells according to strategy
   - Update infrastructure as needed

3. **Data Collection**:
   - Record daily production by well
   - Track infrastructure utilization
   - Monitor reserve depletion
   - Collect phase-specific statistics

### Output Phase
- **Time Series Data**: Daily production, well counts, utilization
- **Phase Summaries**: Aggregated statistics by scenario phase
- **Well-Level Data**: Individual well performance and economics
- **Infrastructure Metrics**: Pipeline utilization, refinery throughput

## Configuration

### Well Types
- **Shale Oil**: High initial production, rapid decline
- **Conventional Onshore**: Traditional onshore wells
- **Conventional Offshore**: Offshore production with higher costs
- **Tight Oil**: Low permeability formations

### Decline Parameters
- **Qi**: Initial production rate (bbl/day)
- **Di**: Nominal decline rate (annual)
- **b-factor**: Hyperbolic decline exponent
- **Drive Mechanism**: Affects decline rate multiplier

### Scenario Phases
- **Steady**: Normal drilling (1.0x multiplier)
- **Aggressive**: High drilling activity (3.0x multiplier)
- **Dormant**: Reduced activity (0.5x multiplier)
- **Normal**: No new drilling (0.0x multiplier)

## Usage Examples

### Basic Simulation Setup
```python
from simulation import SimulationRunner

# Create runner
runner = SimulationRunner(
    total_recoverable_resources=1e12,
    start_date=datetime(2020, 1, 1),
    end_date=datetime(2030, 1, 1),
    basin_name="Permian Basin"
)

# Add wells
runner.add_well(
    initial_production=500,
    nominal_decline_rate=0.15,
    well_type="Shale Oil"
)

# Run simulation
runner.start()
while runner.model.simulation_active:
    state = runner.step()
    # Process results
```

### Scenario Execution
```python
# Define scenario phases
scenario = {
    "name": "Boom-Bust Cycle",
    "sequence": ["Aggressive", "Dormant", "Steady"],
    "year_ranges": [2, 2, 3]
}

# Run with scenario logic
results = run_scenario(scenario, well_configs)
```

## Performance Considerations

### Memory Optimization
- **Minimal State Collection**: Only essential state stored per timestep
- **Efficient Data Structures**: Polars DataFrames for large datasets
- **Garbage Collection**: Automatic cleanup of inactive wells

### Computational Efficiency
- **Vectorized Calculations**: NumPy operations for decline curves
- **Sparse Data Handling**: Only active wells processed each timestep
- **Batch Processing**: Wells processed in parallel when possible

### Scalability Limits
- **Well Count**: Tested up to 10,000+ wells
- **Time Horizon**: Multi-decade simulations feasible
- **Data Resolution**: Daily timesteps with monthly aggregation options

## Validation & Testing

### Data Validation
- **Parameter Bounds**: All inputs validated against handbook limits
- **Historical Matching**: Production curves match historical data
- **Reserve Consistency**: Depletion tracking aligns with estimates

### Scenario Testing
- **Phase Transitions**: Smooth transitions between drilling strategies
- **Economic Limits**: Proper well shut-in at threshold production
- **Capacity Constraints**: Realistic infrastructure limitations

## Integration Points

### API Layer (`api.py`)
- **Endpoint Mapping**: REST API calls translate to SimulationRunner methods
- **Background Execution**: Long-running simulations use async processing
- **Result Formatting**: Simulation outputs formatted for API responses

### Data Layer (`data/`)
- **Historical Production**: `houston_fact_combined_cleaned.csv`
- **Decline Parameters**: `qi_di_b_factor_dimension.csv`
- **Reserve Estimates**: `reserves/reserves.csv`

### Configuration Layer (`config/`)
- **Constants**: Physical constants and multipliers
- **Validation Rules**: Parameter bounds and constraints
- **Type Definitions**: Enums for well types, decline models, etc.

## Troubleshooting

### Common Issues

**Memory Errors**
- Reduce simulation time horizon
- Use minimal state collection
- Check for data leaks in custom agents

**Slow Performance**
- Profile bottleneck operations
- Consider monthly instead of daily timesteps
- Optimize well count for testing

**Validation Failures**
- Check parameter bounds in config
- Verify data types and units
- Review handbook compliance rules

**Convergence Issues**
- Adjust decline curve parameters
- Check economic threshold settings
- Validate initial production rates

### Debugging Tools
- **Logging**: Enable debug logging for detailed execution traces
- **State Inspection**: Examine model state at any timestep
- **Well Analysis**: Individual well production plotting
- **Scenario Comparison**: Side-by-side scenario result analysis</content>
<parameter name="filePath">c:\Users\bhargavesh.dakka\OneDrive - Mu Sigma Business Solutions Pvt. Ltd\Documents\Mu-Sigma\OXY (Occidental Petroleum)\simEng 6\Simulaton\Simulation\simulation\README.md