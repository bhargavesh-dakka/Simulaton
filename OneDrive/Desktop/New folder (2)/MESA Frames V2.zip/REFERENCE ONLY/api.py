"""
SimOxy Simulation API - Backend for Oil & Gas Production Simulation

This API provides endpoints for running mixed-scenario oil production simulations
with configurable drilling strategies over time periods.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json

from simulation_service import SimulationService

# Create FastAPI app
app = FastAPI(
    title="SimOxy Simulation API",
    description="Oil & Gas Production Simulation API with Mixed Scenarios",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global simulation service instance
# simulation_service = SimulationService()  # Not needed anymore

# In-memory storage for demo (use database in production)
simulation_instances = {}  # simulation_id -> SimulationService instance
scenario_configs = {}      # scenario_id -> scenario config
running_scenarios = {}     # scenario_id -> status
completed_scenarios = {}   # scenario_id -> results

# Pydantic models for API requests/responses
class SimulationInit(BaseModel):
    """Request model for initializing a simulation."""
    total_recoverable_resources: int = Field(..., description="Total recoverable resources in barrels")
    start_date: datetime = Field(..., description="Simulation start date")
    end_date: datetime = Field(..., description="Simulation end date")
    basin_name: str = Field(..., description="Name of the basin")
    market_center: str = Field(..., description="Market center name")
    country: str = Field(..., description="Country name")

    class Config:
        json_schema_extra = {
            "example": {
                "total_recoverable_resources": 10000000000000000,
                "start_date": "2020-01-01T00:00:00",
                "end_date": "2030-01-01T00:00:00",
                "basin_name": "Houston Basin",
                "market_center": "Houston",
                "country": "UNITED STATES OF AMERICA"
            }
        }

class SimulationInitResponse(BaseModel):
    simulation_id: str
    message: str
    wells_loaded: int

class ScenarioConfig(BaseModel):
    name: str = Field(..., description="Name of the scenario")
    sequence: List[str] = Field(..., description="List of drilling phases (Steady, Aggressive, Dormant, Normal)")
    year_ranges: List[int] = Field(..., description="Years for each phase (must match sequence length)")

    class Config:
        schema_extra = {
            "example": {
                "name": "Mixed Scenario: Steady → Aggressive → Dormant",
                "sequence": ["Steady", "Aggressive", "Dormant"],
                "year_ranges": [2, 2, 2]
            }
        }

class ScenarioCreateResponse(BaseModel):
    scenario_id: str
    scenario_name: str
    phases: List[str]
    total_years: int
    message: str

class ScenarioRunRequest(BaseModel):
    simulation_id: str = Field(..., description="ID of the initialized simulation")
    scenario_id: str = Field(..., description="ID of the created scenario configuration")

    class Config:
        schema_extra = {
            "example": {
                "simulation_id": "550e8400-e29b-41d4-a716-446655440000",
                "scenario_id": "550e8400-e29b-41d4-a716-446655440001"
            }
        }

class ScenarioRunResponse(BaseModel):
    scenario_id: str
    message: str

class ScenarioStatus(BaseModel):
    scenario_id: str
    status: str  # "running", "completed", "failed"
    progress: Optional[float] = None
    message: Optional[str] = None
    created_at: datetime
    completed_at: Optional[datetime] = None

class PhaseSummary(BaseModel):
    phase: str
    years: float
    total_production_bbl: float
    total_wells_drilled: int

class SimulationResult(BaseModel):
    scenario_id: str
    scenario_name: str
    total_days: int
    phase_summaries: List[PhaseSummary]
    daily_data: List[Dict[str, Any]]

# In-memory storage for demo (use database in production)
running_scenarios = {}
completed_scenarios = {}

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "SimOxy Simulation API",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "POST /init-simulation": "Initialize a new simulation instance",
            "POST /create-scenario": "Create a scenario configuration",
            "POST /run-scenario": "Run a scenario with initialized simulation",
            "GET /scenario/{scenario_id}/status": "Get scenario execution status",
            "GET /scenario/{scenario_id}/results": "Get simulation results",
            "GET /scenarios": "List all scenarios"
        }
    }

@app.post("/init-simulation", response_model=SimulationInitResponse)
async def init_simulation(request: SimulationInit):
    """Initialize a new simulation instance."""
    try:
        # Create a new simulation service instance with user parameters
        sim_service = SimulationService(
            total_recoverable_resources=request.total_recoverable_resources,
            start_date=request.start_date,
            end_date=request.end_date,
            basin_name=request.basin_name,
            market_center=request.market_center,
            country=request.country
        )
        simulation_id = str(uuid.uuid4())

        # Store the simulation instance
        simulation_instances[simulation_id] = sim_service

        return SimulationInitResponse(
            simulation_id=simulation_id,
            message="Simulation initialized successfully",
            wells_loaded=len(sim_service.well_configs)
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to initialize simulation: {str(e)}"
        )

@app.post("/create-scenario", response_model=ScenarioCreateResponse)
async def create_scenario(config: ScenarioConfig):
    """Create a scenario configuration."""

    # Validate input
    if len(config.sequence) != len(config.year_ranges):
        raise HTTPException(
            status_code=400,
            detail="sequence and year_ranges must have the same length"
        )

    # Validate phase names
    valid_phases = ["Steady", "Aggressive", "Dormant", "Normal"]
    for phase in config.sequence:
        if phase not in valid_phases:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid phase '{phase}'. Valid phases: {valid_phases}"
            )

    # Generate scenario ID
    scenario_id = str(uuid.uuid4())

    # Store scenario configuration
    scenario_configs[scenario_id] = {
        'scenario_id': scenario_id,
        'config': config,
        'created_at': datetime.now()
    }

    return ScenarioCreateResponse(
        scenario_id=scenario_id,
        scenario_name=config.name,
        phases=config.sequence,
        total_years=sum(config.year_ranges),
        message="Scenario configuration created successfully"
    )

@app.post("/run-scenario", response_model=ScenarioRunResponse)
async def run_scenario(request: ScenarioRunRequest, background_tasks: BackgroundTasks):
    """Run a scenario with an initialized simulation."""

    # Validate simulation instance exists
    if request.simulation_id not in simulation_instances:
        raise HTTPException(
            status_code=404,
            detail=f"Simulation instance '{request.simulation_id}' not found. Initialize simulation first."
        )

    # Validate scenario config exists
    if request.scenario_id not in scenario_configs:
        raise HTTPException(
            status_code=404,
            detail=f"Scenario configuration '{request.scenario_id}' not found. Create scenario first."
        )

    # Get simulation service and scenario config
    sim_service = simulation_instances[request.simulation_id]
    scenario_data = scenario_configs[request.scenario_id]
    config = scenario_data['config']

    # Create scenario status
    scenario_status = ScenarioStatus(
        scenario_id=request.scenario_id,
        status="running",
        progress=0.0,
        message="Initializing simulation...",
        created_at=datetime.now()
    )

    running_scenarios[request.scenario_id] = scenario_status

    # Run simulation in background
    background_tasks.add_task(
        run_simulation_background,
        request.scenario_id,
        sim_service,
        config
    )

    return ScenarioRunResponse(
        scenario_id=request.scenario_id,
        message="Scenario execution started"
    )

@app.get("/scenario/{scenario_id}/status", response_model=ScenarioStatus)
async def get_scenario_status(scenario_id: str):
    """Get the status of a running or completed scenario."""

    if scenario_id in running_scenarios:
        return running_scenarios[scenario_id]
    elif scenario_id in completed_scenarios:
        return completed_scenarios[scenario_id]
    else:
        raise HTTPException(status_code=404, detail="Scenario not found")

@app.get("/scenario/{scenario_id}/results", response_model=SimulationResult)
async def get_scenario_results(scenario_id: str):
    """Get the results of a completed scenario."""

    if scenario_id not in completed_scenarios:
        raise HTTPException(status_code=404, detail="Scenario not found or not completed")

    scenario_data = completed_scenarios[scenario_id]

    # Convert to response format
    phase_summaries = [
        PhaseSummary(**phase) for phase in scenario_data.get("phase_summaries", [])
    ]

    return SimulationResult(
        scenario_id=scenario_id,
        scenario_name=scenario_data["scenario_name"],
        total_days=scenario_data["total_days"],
        phase_summaries=phase_summaries,
        daily_data=scenario_data["daily_data"]
    )

@app.get("/scenarios")
async def list_scenarios():
    """List all scenarios with their status."""

    all_scenarios = {}

    # Add running scenarios
    for scenario_id, status in running_scenarios.items():
        scenario_name = "Unknown"
        if scenario_id in scenario_configs:
            scenario_name = scenario_configs[scenario_id]['config'].name

        all_scenarios[scenario_id] = {
            "scenario_id": scenario_id,
            "status": status.status,
            "scenario_name": scenario_name,
            "created_at": status.created_at.isoformat(),
            "progress": status.progress
        }

    # Add completed scenarios
    for scenario_id, data in completed_scenarios.items():
        scenario_name = data.get("scenario_name", "Unknown")
        all_scenarios[scenario_id] = {
            "scenario_id": scenario_id,
            "status": "completed",
            "scenario_name": scenario_name,
            "created_at": data.get("created_at", "").isoformat(),
            "total_days": data["total_days"]
        }

    return {"scenarios": list(all_scenarios.values())}

async def run_simulation_background(scenario_id: str, sim_service: SimulationService, config: ScenarioConfig):
    """Run simulation in background thread."""

    try:
        # Update status
        running_scenarios[scenario_id].message = "Creating scenario configuration..."

        # Create scenario configuration
        scenario_config = sim_service.create_scenario(
            config.name,
            config.sequence,
            config.year_ranges
        )

        running_scenarios[scenario_id].message = "Running simulation..."

        # Run simulation
        result = await asyncio.get_event_loop().run_in_executor(
            None,
            sim_service.run_simulation,
            scenario_config,
            scenario_id
        )

        # Store results
        completed_scenarios[scenario_id] = result

        # Update status
        running_scenarios[scenario_id].status = "completed"
        running_scenarios[scenario_id].progress = 100.0
        running_scenarios[scenario_id].message = "Simulation completed successfully"
        running_scenarios[scenario_id].completed_at = datetime.now()

    except Exception as e:
        # Update status on failure
        running_scenarios[scenario_id].status = "failed"
        running_scenarios[scenario_id].message = f"Simulation failed: {str(e)}"
        running_scenarios[scenario_id].completed_at = datetime.now()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)