"""
Data Loading Utilities for Mesa-Frames SimOxy Simulation Engine.

This module provides optimized functions for loading and processing
well data from CSV files using Polars for vectorized operations.

Optimizations:
- Uses Polars lazy evaluation where beneficial
- Vectorized joins and aggregations
- Memory-efficient data structures
- Pre-computed lookup tables for simulation
"""

import polars as pl
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

from utils.logging_config import get_logger, TimedOperation

# Module logger
logger = get_logger(__name__)

# Default data directory (relative to project root)
DATA_DIR = Path(__file__).parent.parent / "data"


def get_data_path(filename: str) -> Path:
    """Get the full path to a data file.
    
    Args:
        filename: Name of the file (can include subdirectory)
        
    Returns:
        Full path to the data file
    """
    return DATA_DIR / filename


# =============================================================================
# REFINERY DATA LOADING FUNCTIONS
# =============================================================================

def load_refinery_capacity_data(
    market_center: str = "Houston",
    filename: str = "refinery/refinery_capacity.csv"
) -> pl.DataFrame:
    """Load refinery capacity data for a market center.
    
    Args:
        market_center: Market center to filter by
        filename: Name of the refinery capacity CSV file
        
    Returns:
        Polars DataFrame with refinery capacity data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Refinery capacity file not found: {file_path}")
    
    with TimedOperation("load_refinery_capacity", logger):
        df = pl.read_csv(str(file_path))
        
        # Filter by market center if specified
        if market_center and market_center != "All Market Centers":
            if "market_center" in df.columns:
                df = df.filter(pl.col("market_center") == market_center)
        
        return df


def load_refinery_mapping_data(
    filename: str = "refinery/crude_conversion_mapping.csv"
) -> pl.DataFrame:
    """Load crude-to-product conversion mapping data.
    
    Args:
        filename: Name of the mapping CSV file
        
    Returns:
        Polars DataFrame with conversion mapping data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Refinery mapping file not found: {file_path}")
    
    with TimedOperation("load_refinery_mapping", logger):
        df = pl.read_csv(str(file_path))
        
        # Normalize grade element names
        if "SPG_grade_element_name" in df.columns:
            df = df.with_columns(
                pl.col("SPG_grade_element_name").str.to_lowercase().str.strip_chars()
            )
        
        return df


def get_unique_refineries(
    market_center: str = "Houston",
    capacity_filename: str = "refinery/refinery_capacity.csv"
) -> pl.DataFrame:
    """Get unique refineries with their configurations.
    
    Args:
        market_center: Market center to filter by
        capacity_filename: Name of the capacity CSV file
        
    Returns:
        DataFrame with unique refinery configurations (one row per refinery)
    """
    capacity_df = load_refinery_capacity_data(market_center, capacity_filename)
    
    # Group by refinery to get unique configurations
    unique_refineries = capacity_df.group_by([
        "refinery_id", "refinery_name", "basin", "market_center",
        "configuration_name", "grade_name", "grade_element_name"
    ]).agg([
        pl.col("max_capacity").first(),
        pl.col("runs_vol_avg").first(),
        pl.col("effective_capacity").first(),
        pl.col("weight").first(),
    ])
    
    return unique_refineries


# =============================================================================
# DIMENSION DATA LOADING (DECLINE CURVES)
# =============================================================================

def load_dim_data(
    filename: str,
    schema_overrides: Optional[Dict[str, Any]] = None
) -> pl.DataFrame:
    """Load dimension (decline curve) data from CSV.
    
    Args:
        filename: Name of the dim CSV file
        schema_overrides: Optional schema overrides for polars
        
    Returns:
        Polars DataFrame with dim data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Dim data file not found: {file_path}")
    
    default_schema = {"api": pl.Utf8, "API": pl.Utf8}
    if schema_overrides:
        default_schema.update(schema_overrides)
    
    with TimedOperation("load_dim_data", logger):
        df = pl.read_csv(str(file_path), schema_overrides=default_schema)
        logger.info("Loaded dim data: %d rows, %d columns", df.shape[0], df.shape[1])
        return df


def load_fact_data(
    filename: str = "houston_fact_combined_cleaned.csv",
    schema_overrides: Optional[Dict[str, Any]] = None
) -> pl.DataFrame:
    """Load fact (production) data from CSV.
    
    Args:
        filename: Name of the fact CSV file
        schema_overrides: Optional schema overrides for polars
        
    Returns:
        Polars DataFrame with fact data
        
    Raises:
        FileNotFoundError: If file doesn't exist
    """
    file_path = get_data_path(filename)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Fact data file not found: {file_path}")
    
    default_schema = {"api": pl.Utf8, "API": pl.Utf8, "Well_ID": pl.Utf8}
    if schema_overrides:
        default_schema.update(schema_overrides)
    
    with TimedOperation("load_fact_data", logger):
        df = pl.read_csv(str(file_path), schema_overrides=default_schema)
        
        # Standardize column names if needed
        if "production_date" in df.columns and "production_vol_date" not in df.columns:
            df = df.rename({"production_date": "production_vol_date"})
        if "Well_ID" in df.columns and "api" not in df.columns:
            df = df.rename({"Well_ID": "api"})
            
        logger.info("Loaded fact data: %d rows, %d columns", df.shape[0], df.shape[1])
        return df


def parse_production_dates(
    df: pl.DataFrame, 
    date_column: str = "production_vol_date"
) -> pl.DataFrame:
    """Parse production dates with multiple format support.
    
    Tries multiple date formats to handle different data sources:
    - M/D/YYYY (e.g., 8/1/2024)
    - YYYY-MM-DD (e.g., 2024-08-01)
    
    Args:
        df: DataFrame with date column
        date_column: Name of the date column to parse
        
    Returns:
        DataFrame with parsed date column
    """
    if date_column not in df.columns:
        return df
    
    # Try M/D/YYYY format first
    try:
        return df.with_columns(
            pl.col(date_column).str.to_date("%-m/%-d/%Y")
        )
    except:
        pass
    
    # Try YYYY-MM-DD format
    try:
        return df.with_columns(
            pl.col(date_column).str.to_date("%Y-%m-%d")
        )
    except:
        pass
    
    # Last resort: automatic parsing
    try:
        return df.with_columns(
            pl.col(date_column).str.strptime(pl.Date, strict=False)
        )
    except:
        logger.warning("Could not parse date column: %s", date_column)
        return df


# =============================================================================
# FILTERING FUNCTIONS
# =============================================================================

def apply_standard_filters(
    df: pl.DataFrame,
    basin_name: Optional[str] = None,
    market_center: Optional[str] = None,
    country: Optional[str] = None
) -> pl.DataFrame:
    """Apply standard geographic filters to a DataFrame.
    
    Args:
        df: DataFrame to filter
        basin_name: Basin name to filter by (None or "All Basins" = no filter)
        market_center: Market center to filter by
        country: Country to filter by
        
    Returns:
        Filtered DataFrame
    """
    filters = []
    
    # Basin filter
    if basin_name and basin_name != "All Basins" and "basin" in df.columns:
        filters.append(pl.col("basin") == basin_name)
    
    # Market center filter
    if market_center and market_center != "All Market Centers":
        if "market_center_name" in df.columns:
            filters.append(pl.col("market_center_name") == market_center)
        elif "market_center" in df.columns:
            filters.append(pl.col("market_center") == market_center)
    
    # Country filter with flexible matching
    if country and country not in ["All Countries"]:
        if "country" in df.columns:
            country_value = country.upper()
            if country_value in ["UNITED STATES", "US", "USA", "UNITED STATES OF AMERICA"]:
                filters.append(pl.col("country").str.contains("(?i)UNITED STATES"))
            else:
                filters.append(pl.col("country").str.contains(f"(?i){country_value}"))
    
    if filters:
        df = df.filter(pl.all_horizontal(filters))
    
    return df


def apply_date_range_filter(
    df: pl.DataFrame,
    start_date: datetime,
    end_date: datetime,
    date_column: str = "prod_date"
) -> pl.DataFrame:
    """Apply date range filter to a DataFrame.
    
    Args:
        df: DataFrame to filter
        start_date: Start of date range
        end_date: End of date range
        date_column: Name of the date column
        
    Returns:
        Filtered DataFrame
    """
    if date_column not in df.columns:
        return df
    
    return df.filter(
        (pl.col(date_column) >= start_date.date()) &
        (pl.col(date_column) <= end_date.date())
    )


# =============================================================================
# WELL DATA LOADING AND MERGING
# =============================================================================

def count_wells_in_range(
    start_date: datetime,
    end_date: datetime,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_factor_dimension.csv"
) -> int:
    """Count existing wells from data files matching filter criteria.
    
    Wells are considered "existing" if their latest_production_date >= start_date.
    
    Args:
        start_date: Simulation start date
        end_date: Simulation end date
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file
        
    Returns:
        Number of unique wells matching criteria
    """
    try:
        dim_df = load_dim_data(dim_filename)
        dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
        
        # Filter by latest_production_date >= start_date
        if "latest_production_date" in dim_df.columns:
            start_date_str = start_date.strftime("%Y-%m-%d")
            dim_df = dim_df.filter(
                pl.col("latest_production_date") >= start_date_str
            )
        
        api_col = "api" if "api" in dim_df.columns else "API"
        return dim_df[api_col].n_unique()
        
    except Exception as e:
        logger.error("Error counting wells: %s", e)
        return 0


def load_and_merge_well_data(
    start_date: datetime,
    end_date: datetime,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_factor_dimension.csv",
    fact_filename: str = "houston_fact_combined_cleaned.csv",
    debug: bool = False
) -> Tuple[pl.DataFrame, Dict[str, Any]]:
    """Load and merge dim and fact data for wells.
    
    This is the main function for loading well data. It:
    1. Loads dim (decline curve) data
    2. Loads fact (production) data
    3. Applies geographic and date filters
    4. Merges the two datasets
    
    Args:
        start_date: Start of simulation date range
        end_date: End of simulation date range
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file
        fact_filename: Name of the fact CSV file
        debug: If True, return debug info
        
    Returns:
        Tuple of (merged DataFrame, metadata dict)
    """
    metadata = {
        "dim_file": dim_filename,
        "fact_file": fact_filename,
        "filters_applied": {
            "basin_name": basin_name,
            "market_center": market_center,
            "country": country,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
    }
    
    with TimedOperation("load_and_merge_well_data", logger):
        # Load dim data
        dim_df = load_dim_data(dim_filename)
        metadata["dim_rows_original"] = dim_df.shape[0]
        
        # Apply geographic filters
        dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
        metadata["dim_rows_after_geo_filter"] = dim_df.shape[0]
        
        # Filter by latest_production_date >= start_date
        if "latest_production_date" in dim_df.columns:
            start_date_str = start_date.strftime("%Y-%m-%d")
            dim_df = dim_df.filter(
                pl.col("latest_production_date") >= start_date_str
            )
        metadata["dim_rows_filtered"] = dim_df.shape[0]
        
        # Load and filter fact data
        fact_df = load_fact_data(fact_filename)
        metadata["fact_rows_original"] = fact_df.shape[0]
        
        fact_df = parse_production_dates(fact_df)
        fact_df = apply_date_range_filter(fact_df, start_date, end_date)
        fact_df = apply_standard_filters(fact_df, basin_name, market_center, country)
        metadata["fact_rows_filtered"] = fact_df.shape[0]
        
        # Determine join columns
        join_cols = ["country", "market_id", "basin_name", "well_type", "start_year"]
        available_join_cols = [c for c in join_cols if c in dim_df.columns and c in fact_df.columns]
        
        if available_join_cols:
            merged_df = fact_df.join(dim_df, on=available_join_cols, how="left")
        else:
            # Fallback: join on api if available
            if "api" in dim_df.columns and "api" in fact_df.columns:
                merged_df = fact_df.join(dim_df, on="api", how="left")
            else:
                merged_df = dim_df
                logger.warning("No common join columns found, returning dim data only")
        
        # Standardize production column name
        if "BOPD" in merged_df.columns and "bopd" not in merged_df.columns:
            merged_df = merged_df.rename({"BOPD": "bopd"})
        
        metadata["merged_rows"] = merged_df.shape[0]
        
        logger.info(
            "Merged data: %d rows, filters=%s",
            merged_df.shape[0], metadata["filters_applied"]
        )
        
        return merged_df, metadata


def create_well_summary(merged_df: pl.DataFrame) -> pl.DataFrame:
    """Create a summary DataFrame grouped by well API.
    
    Args:
        merged_df: Merged dim/fact DataFrame
        
    Returns:
        Summary DataFrame with one row per well
    """
    api_col = "api" if "api" in merged_df.columns else "API"
    
    agg_cols = [
        pl.col("bopd").count().alias("production_days") if "bopd" in merged_df.columns else pl.lit(0).alias("production_days"),
    ]
    
    # Add decline curve parameters
    for col, alias in [("Qi", "qi_bopd"), ("Di", "decline_rate"), ("avg_value", "b_factor")]:
        if col in merged_df.columns:
            agg_cols.append(pl.col(col).first().alias(alias))
    
    # Get last data date
    if "production_vol_date" in merged_df.columns:
        agg_cols.append(pl.col("production_vol_date").max().alias("last_data_date"))
    
    # Include Di_per_month_latest for fallback
    if "Di_per_month_latest" in merged_df.columns:
        agg_cols.append(pl.col("Di_per_month_latest").first().alias("di_latest"))
    
    # Group by API and aggregate
    if api_col in merged_df.columns:
        summary_df = merged_df.group_by(api_col).agg(agg_cols)
        return summary_df
    
    # Fallback: return empty DataFrame
    return pl.DataFrame()


def load_actual_production_data(
    fact_filename: str = "houston_fact_combined_cleaned.csv",
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    basin_name: Optional[str] = None,
    market_center: Optional[str] = None,
    country: Optional[str] = None
) -> Dict[int, Dict[str, float]]:
    """
    Load actual production data from CSV for wells.
    
    This function loads actual production data and returns it as a nested dictionary:
    {well_name: {date_str: production_value}}
    
    Args:
        fact_filename: Name of the fact CSV file
        start_date: Optional start date filter
        end_date: Optional end date filter
        basin_name: Optional basin name filter
        market_center: Optional market center filter
        country: Optional country filter
        
    Returns:
        Dictionary mapping well_name to {date: production} dictionary
    """
    try:
        # Use load_fact_data which already handles the path correctly
        fact_df = load_fact_data(fact_filename)
        
        # Parse production dates
        fact_df = parse_production_dates(fact_df)
        
        # Apply date range filter if provided
        if start_date or end_date:
            if start_date and end_date:
                fact_df = apply_date_range_filter(fact_df, start_date, end_date, "prod_date")
            elif start_date:
                fact_df = fact_df.filter(pl.col("prod_date") >= start_date.date())
            elif end_date:
                fact_df = fact_df.filter(pl.col("prod_date") <= end_date.date())
        
        # Apply geographic filters if provided
        fact_df = apply_standard_filters(fact_df, basin_name, market_center, country)
        
        # Get the API column name
        api_col = "api" if "api" in fact_df.columns else "API" if "API" in fact_df.columns else "Well_ID"
        
        # Get the production column name
        prod_col = "bopd" if "bopd" in fact_df.columns else "BOPD" if "BOPD" in fact_df.columns else "production"
        
        # Build the nested dictionary
        actual_production_data = {}
        
        for row in fact_df.iter_rows(named=True):
            well_id = int(row[api_col])
            prod_date = row["production_vol_date"]
            production = float(row[prod_col]) if row[prod_col] is not None else 0.0
            
            if well_id not in actual_production_data:
                actual_production_data[well_id] = {}
            
            # Format date as string for dictionary key
            date_str = prod_date.strftime("%Y-%m-%d")
            actual_production_data[well_id][date_str] = production
        
        logger.info(
            "Loaded actual production data: %d wells, %d total records",
            len(actual_production_data),
            fact_df.shape[0]
        )
        
        return actual_production_data
        
    except Exception as e:
        logger.error("Error loading actual production data: %s", e)
        return {}
    
    # Include production_start_date
    if "production_start_date" in merged_df.columns:
        agg_cols.append(pl.col("production_start_date").first().alias("production_start_date"))
    
    return merged_df.group_by(api_col).agg(agg_cols)


def get_available_well_types(
    start_date: datetime,
    end_date: datetime,
    basin_name: str = "All Basins",
    market_center: str = "All Market Centers",
    country: str = "All Countries",
    dim_filename: str = "qi_di_b_factor_dimension.csv"
) -> List[str]:
    """Get unique well types from dim data matching filter criteria.
    
    Args:
        start_date: Simulation start date
        end_date: Simulation end date
        basin_name: Basin name filter
        market_center: Market center filter
        country: Country filter
        dim_filename: Name of the dim CSV file
        
    Returns:
        List of unique well types
    """
    try:
        dim_df = load_dim_data(dim_filename)
        dim_df = apply_standard_filters(dim_df, basin_name, market_center, country)
        
        if "latest_production_date" in dim_df.columns:
            start_date_str = start_date.strftime("%Y-%m-%d")
            dim_df = dim_df.filter(
                pl.col("latest_production_date") >= start_date_str
            )
        
        if "play_type" in dim_df.columns:
            well_types = dim_df["play_type"].unique().to_list()
            return sorted([wt for wt in well_types if wt is not None])
        elif "well_type" in dim_df.columns:
            well_types = dim_df["well_type"].unique().to_list()
            return sorted([wt for wt in well_types if wt is not None])
        
        return []
    except Exception as e:
        logger.error("Error getting well types: %s", e)
        return []


# =============================================================================
# GRADE DATA LOADING
# =============================================================================

def load_grade_splits(market_center: str) -> Dict[str, float]:
    """Load crude grade split percentages for a market center.
    
    Args:
        market_center: The market center name (e.g., 'Houston')
        
    Returns:
        Dict with keys: hSour, hSweet, mSour, mSweet, lSour, lSweet
    """
    grade_splits = {
        "hSour": 0.0,
        "hSweet": 0.0,
        "mSour": 0.0,
        "mSweet": 0.0,
        "lSour": 0.0,
        "lSweet": 0.0,
    }
    
    grade_mapping = {
        "Heavy Sour": "hSour",
        "Heavy Sweet": "hSweet",
        "Medium Sour": "mSour",
        "Medium Sweet": "mSweet",
        "Light Sour": "lSour",
        "Light Sweet": "lSweet",
    }
    
    try:
        grade_path = get_data_path("grade/grade_data.csv")
        
        if not grade_path.exists():
            logger.warning("grade_data.csv not found, using defaults")
            return grade_splits
        
        df = pl.read_csv(str(grade_path))
        
        # Filter for market center (case-insensitive)
        if "market_center" in df.columns:
            filtered = df.filter(
                pl.col("market_center").str.to_lowercase().str.strip_chars() == 
                market_center.lower().strip()
            )
        else:
            filtered = df
        
        if filtered.is_empty():
            logger.info("No grade data for market_center='%s', using defaults", market_center)
            return grade_splits
        
        # Parse grade data
        for row in filtered.iter_rows(named=True):
            crude_quality = str(row.get("crude_quality", "")).strip()
            percentage = float(row.get("percentage", 0))
            
            if crude_quality in grade_mapping:
                key = grade_mapping[crude_quality]
                grade_splits[key] = percentage
        
        logger.info("Loaded grade splits for %s: %s", market_center, grade_splits)
        return grade_splits
        
    except Exception as e:
        logger.error("Error loading grade data: %s", e)
        return grade_splits


# =============================================================================
# RESERVES DATA LOADING
# =============================================================================

def load_reserves_data(
    market_center: str, 
    country: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    """Load reserves data from CSV for a given market center.
    
    Args:
        market_center: The market center name
        country: Optional country filter
        
    Returns:
        Dict with reserves data if found, None otherwise.
    """
    try:
        reserves_path = get_data_path("reserves/reserves.csv")
        
        if not reserves_path.exists():
            logger.warning("reserves.csv not found")
            return None
        
        df = pl.read_csv(str(reserves_path))
        
        if "market_center" not in df.columns:
            logger.error("'market_center' column not found in reserves data")
            return None
        
        # Filter by market center (case-insensitive)
        filtered = df.filter(
            pl.col("market_center").str.to_lowercase().str.strip_chars() == 
            market_center.lower().strip()
        )
        
        # Optional country filter
        if country and not filtered.is_empty() and "country" in df.columns:
            filtered = filtered.filter(
                pl.col("country").str.to_lowercase().str.strip_chars() == 
                country.lower().strip()
            )
        
        if filtered.is_empty():
            logger.info("No reserves data for market_center='%s'", market_center)
            return None
        
        row = filtered.row(0, named=True)
        
        # Parse effective date
        date_str = str(row.get("date_of_last_db_update", ""))
        effective_date = None
        if date_str and date_str != "null" and date_str != "nan":
            try:
                effective_date = datetime.strptime(date_str.split()[0], "%Y-%m-%d")
            except (ValueError, IndexError) as e:
                logger.warning("Could not parse date '%s': %s", date_str, e)
        
        reserves_data = {
            "country": str(row.get("country", "")),
            "market_center": str(row.get("market_center", "")),
            "basin_name": str(row.get("basin_name", "")),
            "main_parent_basin_name": str(row.get("main_parent_basin_name", "")),
            "crude_recoverable_pp_bbl": float(row.get("crude_recoverable_pp_bbl", 0) or 0),
            "crude_cumul_prod_bbl": float(row.get("crude_cumul_prod_bbl", 0) or 0),
            "crude_remaining_pp_bbl": float(row.get("crude_remaining_pp_bbl", 0) or 0),
            "oil_remaining_pp_bbl": float(row.get("oil_remaining_pp_bbl", 0) or 0),
            "cond_remaining_pp_bbl": float(row.get("cond_remaining_pp_bbl", 0) or 0),
            "effective_date": effective_date,
            "date_of_last_db_update": date_str,
            "date_of_last_refresh": str(row.get("date_of_last_refresh", "")),
        }
        
        logger.info(
            "Loaded reserves for %s: remaining=%.0f bbl",
            market_center, reserves_data["crude_remaining_pp_bbl"]
        )
        
        return reserves_data
        
    except Exception as e:
        logger.error("Error loading reserves data: %s", e)
        return None


# =============================================================================
# DRILLING RATE DATA
# =============================================================================

def load_drilling_rate_data() -> Tuple[pl.DataFrame, Dict[str, Dict[str, float]]]:
    """Load drilling rate data and slope coefficients.
    
    Returns:
        Tuple of (drilling_df, slope_dict)
    """
    drilling_rate_folder = DATA_DIR / "drilling_rate"
    
    try:
        drilling_df = pl.read_csv(str(drilling_rate_folder / "drilling_data.csv"))
        slope_df = pl.read_csv(str(drilling_rate_folder / "slope.csv"))
        
        # Create slope dictionary
        slope_dict = {}
        for row in slope_df.iter_rows(named=True):
            slope_dict[row["Play_Type"]] = {
                "slope": row["Slope"],
                "intercept": row["Intercept"]
            }
        
        return drilling_df, slope_dict
    except Exception as e:
        logger.warning("Error loading drilling rate data: %s", e)
        return pl.DataFrame(), {}


def calc_month_index(
    year: int, 
    month: int, 
    sim_start_year: int, 
    sim_start_month: int
) -> int:
    """Calculate month index relative to simulation start date.
    
    Args:
        year: Target year
        month: Target month
        sim_start_year: Simulation start year
        sim_start_month: Simulation start month
        
    Returns:
        Month index (1-based)
    """
    return (year - sim_start_year) * 12 + (month - sim_start_month) + 1


def build_historical_series(
    drilling_df: pl.DataFrame, 
    play_type: str, 
    sim_start_year: int, 
    sim_start_month: int
) -> Dict[int, int]:
    """Build dictionary of month_index -> drilling count for a play type.
    
    Args:
        drilling_df: DataFrame with drilling data
        play_type: Well type / play type to filter
        sim_start_year: Simulation start year
        sim_start_month: Simulation start month
        
    Returns:
        Dictionary mapping month index to drilling count
    """
    play_data = drilling_df.filter(pl.col("play_type") == play_type).sort("month")
    
    history = {}
    for row in play_data.iter_rows(named=True):
        data_year = row["year"]
        data_month = row["month"]
        month_idx = calc_month_index(data_year, data_month, sim_start_year, sim_start_month)
        history[month_idx] = row["Total_Drilled"]
    
    return history
