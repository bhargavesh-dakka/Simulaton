"""
Standardized Logging Configuration for Mesa-Frames SimOxy Simulation Engine.

This module provides centralized logging setup to ensure consistent
logging format, levels, and handlers across all simulation components.

Usage:
    # At application startup (e.g., in api.py):
    from utils.logging_config import setup_logging
    setup_logging(level="INFO")
    
    # In each module:
    from utils.logging_config import get_logger
    logger = get_logger(__name__)
    
    logger.info("Simulation started with %d wells", num_wells)
    logger.warning("Well %s has low production", api_number)
    logger.error("Failed to load data: %s", error_msg)
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Any, Dict
from functools import wraps
import time


# =============================================================================
# DEFAULT CONFIGURATION
# =============================================================================

DEFAULT_LOG_FORMAT = (
    "[%(asctime)s] %(levelname)-8s [%(name)s:%(lineno)d] %(message)s"
)
DEFAULT_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFAULT_LOG_LEVEL = "INFO"

# Loggers to suppress (noisy third-party libraries)
SUPPRESSED_LOGGERS = [
    "mesa",
    "mesa_frames",
    "urllib3",
    "httpcore",
    "httpx",
    "asyncio",
    "polars",
]


# =============================================================================
# SETUP FUNCTIONS
# =============================================================================

def setup_logging(
    level: str = DEFAULT_LOG_LEVEL,
    log_file: Optional[str] = None,
    log_format: str = DEFAULT_LOG_FORMAT,
    date_format: str = DEFAULT_DATE_FORMAT,
    suppress_noisy: bool = True,
) -> None:
    """
    Configure logging for the simulation engine.
    
    This function should be called once at application startup, typically
    in the main entry point (api.py or similar).
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional path to log file. If None, logs only to console.
        log_format: Format string for log messages
        date_format: Format string for timestamps
        suppress_noisy: If True, suppress verbose third-party loggers
        
    Example:
        # Basic setup
        setup_logging(level="INFO")
        
        # With file logging
        setup_logging(level="DEBUG", log_file="logs/simulation.log")
    """
    # Convert string level to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create handlers
    handlers = []
    
    # Console handler (always enabled)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(
        logging.Formatter(log_format, datefmt=date_format)
    )
    handlers.append(console_handler)
    
    # File handler (optional)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(
            logging.Formatter(log_format, datefmt=date_format)
        )
        handlers.append(file_handler)
    
    # Configure root logger
    logging.basicConfig(
        level=numeric_level,
        handlers=handlers,
        force=True
    )
    
    # Suppress noisy third-party loggers
    if suppress_noisy:
        for logger_name in SUPPRESSED_LOGGERS:
            logging.getLogger(logger_name).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a module.
    
    Args:
        name: Module name (typically __name__)
        
    Returns:
        Configured logger instance
        
    Example:
        logger = get_logger(__name__)
        logger.info("Processing %d wells", num_wells)
    """
    return logging.getLogger(name)


# =============================================================================
# SIMULATION LOGGER - STRUCTURED EVENTS
# =============================================================================

class SimulationLogger:
    """
    Structured simulation event logger.
    
    Provides methods for logging specific simulation events with
    consistent formatting and context.
    """
    
    def __init__(self, name: str):
        """Initialize with a module name."""
        self.logger = get_logger(name)
    
    def log_simulation_started(
        self,
        start_date: str,
        end_date: str,
        basin_name: str,
        num_wells: int,
        **extra: Any
    ) -> None:
        """Log simulation start event."""
        self.logger.info(
            "🚀 Simulation STARTED: basin=%s, period=%s to %s, wells=%d",
            basin_name, start_date, end_date, num_wells
        )
        if extra:
            self.logger.debug("Extra params: %s", extra)
    
    def log_simulation_step(
        self,
        step: int,
        current_date: str,
        total_production: float,
        active_wells: int,
        **extra: Any
    ) -> None:
        """Log simulation step event."""
        self.logger.debug(
            "📈 Step %d (%s): production=%.0f bbl, active_wells=%d",
            step, current_date, total_production, active_wells
        )
    
    def log_simulation_completed(
        self,
        total_steps: int,
        total_production: float,
        elapsed_time: float,
        **extra: Any
    ) -> None:
        """Log simulation completion event."""
        self.logger.info(
            "✅ Simulation COMPLETED: steps=%d, total_production=%.0f bbl, elapsed=%.2fs",
            total_steps, total_production, elapsed_time
        )
    
    def log_well_added(
        self,
        well_id: Any,
        well_type: str,
        initial_production: float,
        **extra: Any
    ) -> None:
        """Log well addition event."""
        self.logger.debug(
            "🛢️ Well added: id=%s, type=%s, qi=%.0f bbl/day",
            well_id, well_type, initial_production
        )
    
    def log_well_depleted(
        self,
        well_id: Any,
        cumulative_production: float,
        eur: float,
        **extra: Any
    ) -> None:
        """Log well depletion event."""
        self.logger.info(
            "⚠️ Well depleted: id=%s, cumulative=%.0f bbl, EUR=%.0f bbl",
            well_id, cumulative_production, eur
        )
    
    def log_monthly_production(
        self,
        year: int,
        month: int,
        production_by_grade: Dict[str, float],
        total: float,
        **extra: Any
    ) -> None:
        """Log monthly production summary."""
        self.logger.info(
            "📊 Monthly Production %04d-%02d: total=%.0f bbl, grades=%s",
            year, month, total, production_by_grade
        )
    
    def log_error(
        self,
        error_type: str,
        message: str,
        **extra: Any
    ) -> None:
        """Log error event."""
        self.logger.error(
            "❌ %s: %s",
            error_type, message
        )
        if extra:
            self.logger.error("Error context: %s", extra)


# =============================================================================
# PERFORMANCE TIMING DECORATOR
# =============================================================================

def log_execution_time(func):
    """
    Decorator to log function execution time.
    
    Example:
        @log_execution_time
        def run_simulation(self):
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        logger = get_logger(func.__module__)
        start_time = time.perf_counter()
        
        try:
            result = func(*args, **kwargs)
            elapsed = time.perf_counter() - start_time
            logger.debug(
                "⏱️ %s completed in %.4fs",
                func.__name__, elapsed
            )
            return result
        except Exception as e:
            elapsed = time.perf_counter() - start_time
            logger.error(
                "⏱️ %s failed after %.4fs: %s",
                func.__name__, elapsed, str(e)
            )
            raise
    
    return wrapper


def log_vectorized_operation(operation_name: str, num_records: int):
    """
    Decorator factory to log vectorized operation performance.
    
    Example:
        @log_vectorized_operation("well_production_calc", len(wells_df))
        def calculate_production(wells_df):
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger = get_logger(func.__module__)
            start_time = time.perf_counter()
            
            result = func(*args, **kwargs)
            elapsed = time.perf_counter() - start_time
            
            records_per_sec = num_records / elapsed if elapsed > 0 else 0
            logger.debug(
                "⚡ Vectorized %s: %d records in %.4fs (%.0f rec/s)",
                operation_name, num_records, elapsed, records_per_sec
            )
            return result
        return wrapper
    return decorator


# =============================================================================
# CONTEXT MANAGER FOR TIMED OPERATIONS
# =============================================================================

class TimedOperation:
    """
    Context manager for timing operations.
    
    Example:
        with TimedOperation("data_loading", logger):
            df = load_data()
    """
    
    def __init__(self, name: str, logger: Optional[logging.Logger] = None):
        self.name = name
        self.logger = logger or get_logger(__name__)
        self.start_time: Optional[float] = None
        self.elapsed: Optional[float] = None
    
    def __enter__(self):
        self.start_time = time.perf_counter()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.elapsed = time.perf_counter() - self.start_time
        if exc_type is None:
            self.logger.debug(
                "⏱️ %s completed in %.4fs",
                self.name, self.elapsed
            )
        else:
            self.logger.error(
                "⏱️ %s failed after %.4fs: %s",
                self.name, self.elapsed, exc_val
            )
        return False
