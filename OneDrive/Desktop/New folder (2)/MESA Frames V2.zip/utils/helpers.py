"""
General Helper Utilities for Mesa-Frames SimOxy Simulation Engine.

This module contains miscellaneous utility functions optimized for
vectorized operations with Polars DataFrames.
"""

import math
from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta
import polars as pl

from utils.logging_config import get_logger

logger = get_logger(__name__)


def sanitize_for_json(obj: Any) -> Any:
    """Recursively replace NaN/Inf values with None for valid JSON serialization.
    
    Args:
        obj: Any Python object (dict, list, float, etc.)
        
    Returns:
        Sanitized object safe for JSON serialization
    """
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_for_json(v) for v in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    return obj


def sanitize_dataframe_for_json(df: pl.DataFrame) -> pl.DataFrame:
    """Replace NaN/Inf values in a Polars DataFrame with None.
    
    Args:
        df: Polars DataFrame to sanitize
        
    Returns:
        DataFrame with NaN/Inf replaced by null
    """
    # Get float columns
    float_cols = [col for col, dtype in zip(df.columns, df.dtypes) 
                  if dtype in [pl.Float32, pl.Float64]]
    
    if not float_cols:
        return df
    
    # Replace inf values with null for all float columns
    return df.with_columns([
        pl.when(pl.col(col).is_infinite() | pl.col(col).is_nan())
        .then(None)
        .otherwise(pl.col(col))
        .alias(col)
        for col in float_cols
    ])


def build_prod_vs_takeaway_from_sample_points(
    runner, 
    sample_points: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Build production vs takeaway dataset from sample points.
    
    Args:
        runner: SimulationRunner instance
        sample_points: List of sample data points from the simulation
        
    Returns:
        List of production vs takeaway data points
    """
    logger.info("build_prod_vs_takeaway called with %d sample points", 
                len(sample_points) if sample_points else 0)
    
    if not runner or not sample_points:
        logger.warning("Returning empty - runner: %s, sample_points: %d",
                       runner is not None, len(sample_points) if sample_points else 0)
        return []

    pipeline_capacity = (
        runner.model.pipeline.max_capacity 
        if hasattr(runner, "model") and hasattr(runner.model, "pipeline") 
        else 0
    )
    
    result = []
    for point in sample_points:
        daily_prod = point.get("daily_production", 0.0)
        transported = min(daily_prod, pipeline_capacity)
        gap = max(0, daily_prod - pipeline_capacity)
        
        result.append({
            "date": point.get("date"),
            "daily_production": float(daily_prod),
            "potential_production": float(daily_prod),
            "pipeline_capacity": float(pipeline_capacity),
            "pipeline_transported": float(transported),
            "pipeline_utilization_pct": (transported / pipeline_capacity * 100) if pipeline_capacity > 0 else 0,
            "gap": float(gap),
            "active_wells": int(point.get("active_wells", 0)),
        })
    
    logger.info("Built %d production_vs_takeaway points", len(result))
    return result


def dataframe_to_sample_points(
    df: pl.DataFrame,
    date_col: str = "date",
    production_col: str = "total_daily_production",
    active_wells_col: str = "active_wells"
) -> List[Dict[str, Any]]:
    """Convert a Polars DataFrame to sample points format.
    
    Args:
        df: DataFrame with simulation results
        date_col: Name of date column
        production_col: Name of production column
        active_wells_col: Name of active wells column
        
    Returns:
        List of sample point dictionaries
    """
    result = []
    
    for row in df.iter_rows(named=True):
        point = {
            "date": row.get(date_col),
            "daily_production": row.get(production_col, 0.0),
            "active_wells": row.get(active_wells_col, 0),
        }
        result.append(point)
    
    return result


def get_quarter(date: datetime) -> tuple:
    """Return (year, quarter) tuple for a given date.
    
    Args:
        date: datetime object
        
    Returns:
        Tuple of (year, quarter)
    """
    quarter = (date.month - 1) // 3 + 1
    return (date.year, quarter)


def get_month_year(date: datetime) -> tuple:
    """Return (year, month) tuple for a given date.
    
    Args:
        date: datetime object
        
    Returns:
        Tuple of (year, month)
    """
    return (date.year, date.month)


def days_in_month(year: int, month: int) -> int:
    """Calculate the number of days in a given month.
    
    Args:
        year: Year
        month: Month (1-12)
        
    Returns:
        Number of days in the month
    """
    if month == 12:
        next_month = datetime(year + 1, 1, 1)
    else:
        next_month = datetime(year, month + 1, 1)
    
    this_month = datetime(year, month, 1)
    return (next_month - this_month).days


def create_date_range_dataframe(
    start_date: datetime,
    end_date: datetime,
    freq: str = "1d"
) -> pl.DataFrame:
    """Create a DataFrame with date range for simulation.
    
    Args:
        start_date: Start date
        end_date: End date
        freq: Frequency ('1d' for daily, '1mo' for monthly)
        
    Returns:
        DataFrame with date column and derived columns
    """
    dates = pl.date_range(
        start=start_date.date(),
        end=end_date.date(),
        interval=freq,
        eager=True
    )
    
    df = pl.DataFrame({"date": dates})
    
    # Add derived columns
    df = df.with_columns([
        pl.col("date").dt.year().alias("year"),
        pl.col("date").dt.month().alias("month"),
        pl.col("date").dt.day().alias("day"),
        ((pl.col("date").dt.month() - 1) // 3 + 1).alias("quarter"),
        (pl.col("date") - pl.col("date").min()).dt.total_days().alias("day_index"),
    ])
    
    return df


def vectorized_decline_curve(
    t_years: pl.Series,
    initial_production: pl.Series,
    decline_exponent: pl.Series,
    effective_decline: pl.Series
) -> pl.Series:
    """Calculate production rate using vectorized decline curve.
    
    Handles exponential (b=0) and hyperbolic/harmonic (b>0) decline.
    
    Args:
        t_years: Time in years since production start
        initial_production: Initial production rate (Qi) in bbl/day
        decline_exponent: b-factor for decline curve
        effective_decline: Effective annual decline rate
        
    Returns:
        Production rate in bbl/day
    """
    # For exponential decline (b = 0): q(t) = qi * exp(-D * t)
    # For hyperbolic decline (b > 0): q(t) = qi / (1 + b*D*t)^(1/b)
    
    return (
        pl.when(decline_exponent == 0)
        .then(initial_production * (-effective_decline * t_years).exp())
        .otherwise(
            initial_production / 
            ((1 + decline_exponent * effective_decline * t_years)
             .pow(1.0 / decline_exponent.clip(lower_bound=0.001)))
        )
    )


def calculate_eur_vectorized(
    initial_production: pl.Series,
    decline_exponent: pl.Series,
    nominal_decline_rate: pl.Series,
    drive_multiplier: pl.Series,
    horizon_years: int = 30,
    min_economic_production: float = 0.5
) -> pl.Series:
    """Calculate EUR (Estimated Ultimate Recovery) vectorized.
    
    Uses numerical integration over the decline curve.
    
    Args:
        initial_production: Initial production rate (Qi)
        decline_exponent: b-factor
        nominal_decline_rate: Annual nominal decline rate
        drive_multiplier: Drive mechanism multiplier
        horizon_years: Years to project
        min_economic_production: Economic limit
        
    Returns:
        EUR in barrels
    """
    effective_decline = nominal_decline_rate * drive_multiplier
    
    # For exponential decline (b=0): EUR = qi / D
    # For hyperbolic (b>0): EUR = qi / ((1-b) * D) for b<1
    # For harmonic (b=1): EUR = qi / D * ln(1 + D*t)
    
    # Simplified approximation using 30-year horizon
    days_in_year = 365.25
    max_days = int(horizon_years * days_in_year)
    
    # Use analytical formula for exponential case
    # Numerical approximation for hyperbolic
    eur_exponential = initial_production * days_in_year / effective_decline.clip(lower_bound=0.001)
    
    # For hyperbolic, use formula: EUR = qi * (1 + b*D*t)^(1-1/b) / ((1-1/b)*b*D)
    # Simplified: approximate as qi * days * adjustment_factor
    adjustment_factor = (
        pl.when(decline_exponent <= 0.5).then(1.0)
        .when(decline_exponent <= 1.0).then(1.5)
        .otherwise(2.0)
    )
    
    eur_hyperbolic = initial_production * max_days * adjustment_factor / (1 + effective_decline * horizon_years)
    
    return (
        pl.when(decline_exponent == 0)
        .then(eur_exponential)
        .otherwise(eur_hyperbolic)
    )


def chunk_dataframe(
    df: pl.DataFrame, 
    chunk_size: int
) -> List[pl.DataFrame]:
    """Split a DataFrame into chunks for batch processing.
    
    Args:
        df: DataFrame to split
        chunk_size: Maximum rows per chunk
        
    Returns:
        List of DataFrame chunks
    """
    n_rows = df.shape[0]
    chunks = []
    
    for i in range(0, n_rows, chunk_size):
        chunks.append(df.slice(i, chunk_size))
    
    return chunks


def merge_dataframes_on_date(
    dfs: List[pl.DataFrame],
    date_col: str = "date",
    how: str = "outer"
) -> pl.DataFrame:
    """Merge multiple DataFrames on date column.
    
    Args:
        dfs: List of DataFrames to merge
        date_col: Name of date column
        how: Join type
        
    Returns:
        Merged DataFrame
    """
    if not dfs:
        return pl.DataFrame()
    
    result = dfs[0]
    for df in dfs[1:]:
        result = result.join(df, on=date_col, how=how)
    
    return result.sort(date_col)


def calculate_cumulative_production(
    daily_production: pl.Series
) -> pl.Series:
    """Calculate cumulative production from daily production series.
    
    Args:
        daily_production: Daily production values
        
    Returns:
        Cumulative production series
    """
    return daily_production.cum_sum()


def rolling_average(
    series: pl.Series,
    window_size: int = 7
) -> pl.Series:
    """Calculate rolling average for a series.
    
    Args:
        series: Input series
        window_size: Window size for rolling average
        
    Returns:
        Rolling average series
    """
    return series.rolling_mean(window_size=window_size)


def resample_to_monthly(
    df: pl.DataFrame,
    date_col: str = "date",
    agg_cols: Optional[Dict[str, str]] = None
) -> pl.DataFrame:
    """Resample daily data to monthly aggregates.
    
    Args:
        df: DataFrame with daily data
        date_col: Name of date column
        agg_cols: Dict mapping column name to aggregation function
                  (e.g., {"production": "sum", "price": "mean"})
        
    Returns:
        Monthly aggregated DataFrame
    """
    if agg_cols is None:
        agg_cols = {}
    
    # Add year-month columns
    df = df.with_columns([
        pl.col(date_col).dt.year().alias("year"),
        pl.col(date_col).dt.month().alias("month"),
    ])
    
    # Build aggregation expressions
    agg_exprs = []
    for col, agg_func in agg_cols.items():
        if agg_func == "sum":
            agg_exprs.append(pl.col(col).sum().alias(col))
        elif agg_func == "mean":
            agg_exprs.append(pl.col(col).mean().alias(col))
        elif agg_func == "max":
            agg_exprs.append(pl.col(col).max().alias(col))
        elif agg_func == "min":
            agg_exprs.append(pl.col(col).min().alias(col))
        elif agg_func == "first":
            agg_exprs.append(pl.col(col).first().alias(col))
        elif agg_func == "last":
            agg_exprs.append(pl.col(col).last().alias(col))
    
    return df.group_by(["year", "month"]).agg(agg_exprs).sort(["year", "month"])


def format_number(value: float, precision: int = 2) -> str:
    """Format a number with thousand separators.
    
    Args:
        value: Number to format
        precision: Decimal precision
        
    Returns:
        Formatted string
    """
    if value is None or (isinstance(value, float) and (math.isnan(value) or math.isinf(value))):
        return "N/A"
    
    return f"{value:,.{precision}f}"


def format_percentage(value: float, precision: int = 1) -> str:
    """Format a decimal as percentage.
    
    Args:
        value: Decimal value (e.g., 0.15 for 15%)
        precision: Decimal precision
        
    Returns:
        Formatted percentage string
    """
    if value is None or (isinstance(value, float) and (math.isnan(value) or math.isinf(value))):
        return "N/A"
    
    return f"{value * 100:.{precision}f}%"


def calculate_days_between_dates(
    start_date: datetime,
    end_date: datetime
) -> int:
    """Calculate the number of days between two dates.
    
    Args:
        start_date: Start date
        end_date: End date
        
    Returns:
        Number of days
    """
    return (end_date - start_date).days
