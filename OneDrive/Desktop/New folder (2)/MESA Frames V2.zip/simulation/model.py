"""
BasinModel - Mesa-Frames Optimized Basin Simulation Model.

This module implements the main simulation model using mesa-frames ModelDF
for vectorized agent operations and efficient large-scale simulations.

OPTIMIZATION:
- Uses mesa-frames ModelDF for vectorized operations
- All well calculations performed as DataFrame operations
- Efficient memory usage with Polars DataFrames
- Supports simulations with 10,000+ wells efficiently

COMPLIANCE:
- Daily timesteps with monthly accumulation
- Reserve depletion tracking
- Production by grade allocation
- Refinery and pipeline integration
"""

from __future__ import annotations

import time
import calendar
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, TYPE_CHECKING

import polars as pl
from mesa_frames import ModelDF

from config.simulation_config import (
    WellType,
    CONSTANTS,
    GRADE_KEY_MAPPING,
    GRADE_KEY_REVERSE_MAPPING,
)
from utils.logging_config import get_logger, SimulationLogger, TimedOperation
from utils.data_loader import load_grade_splits, load_reserves_data, load_actual_production_data
from exceptions import ReserveDepletionError

from .agents import WellAgentSet, PipelineAgentSet, PipelineAgent, RefineryAgentSet

logger = get_logger(__name__)
sim_logger = SimulationLogger(__name__)


class MinimalStateCollector:
    """
    Minimal state collector that stores only t-1 state snapshot.
    
    Memory efficient: O(num_wells) instead of O(days × num_wells)
    
    Stores only essential state needed to derive computed values:
    - Basin: remaining_reserves, cumulative_production
    - Pipeline: total_transported, days_operational, max_capacity
    - Wells: days_on_production, cumulative_production, is_active, status
    
    All other values (daily_potential_production, recovery_factor, etc.) 
    can be derived from static parameters + minimal state.
    """
    
    def __init__(self):
        self.previous_state: Optional[Dict[str, Any]] = None
        self.current_state: Optional[Dict[str, Any]] = None
    
    def collect(self, model: "BasinModel") -> None:
        """Store minimal state snapshot - replaces previous with current."""
        self.previous_state = self.current_state
        
        reserves_tracking_active = (
            model._is_reserves_tracking_active() 
            if hasattr(model, '_is_reserves_tracking_active') 
            else False
        )
        
        # Get wells summary from DataFrame
        wells_df = model.wells.agents
        wells_dict = {}
        
        if not wells_df.is_empty():
            for row in wells_df.iter_rows(named=True):
                wells_dict[row["unique_id"]] = {
                    "days_on_production": row.get("days_on_production", 0),
                    "cumulative_production": row.get("cumulative_production", 0.0),
                    "daily_production": row.get("daily_production", 0.0),
                    "daily_potential_production": row.get("daily_potential_production", 0.0),
                    "is_active": row.get("is_active", False),
                    "status": row.get("status", "Active"),
                    "production_end_date": None,
                }
        
        total_daily = wells_df["daily_production"].sum() if not wells_df.is_empty() else 0.0
        total_potential = wells_df["daily_potential_production"].sum() if not wells_df.is_empty() else 0.0
        active_wells = model.wells.get_active_wells_count()
        
        self.current_state = {
            "current_date": model.current_date.isoformat(),
            "step": model._step_count,
            "reserves_tracking_active": reserves_tracking_active,
            "reserves_effective_date": (
                model.reserves_effective_date.isoformat() 
                if model.reserves_effective_date 
                else None
            ),
            "basin": {
                "remaining_reserves": model.basin_remaining_reserves if reserves_tracking_active else None,
                "recovery_factor": model.basin_recovery_factor if reserves_tracking_active else None,
                "cumulative_production": model.basin_cumulative_production,
                "total_recoverable_resources": model.basin_total_recoverable_resources,
            },
            "pipeline": {
                "cumulative_transport": model.pipeline.cumulative_transport,
                "daily_transport": model.pipeline.daily_transport,
                "max_capacity": model.pipeline.max_capacity,
                "capacity_bpd": model.pipeline.max_capacity,
                "utilization_pct": model.pipeline.utilization_pct,
                "is_operational": True,
                "is_active": True,
                # For backward compatibility
                "current_utilization": model.pipeline.daily_transport,
                "total_transported": model.pipeline.cumulative_transport,
                "utilization_percentage": model.pipeline.utilization_pct,
            },
            "wells": wells_dict,
            "summary": {
                "total_daily_production": total_daily,
                "total_potential_production": total_potential,
                "active_wells": active_wells,
                "total_wells": wells_df.shape[0],
            }
        }
    
    def get_previous_state(self) -> Optional[Dict[str, Any]]:
        """Return t-1 state snapshot."""
        return self.previous_state
    
    def get_current_state(self) -> Optional[Dict[str, Any]]:
        """Return current state snapshot."""
        return self.current_state
    
    def get_model_vars_dataframe(self) -> pl.DataFrame:
        """Compatibility method - returns current state as single-row DataFrame."""
        if self.current_state is None:
            return pl.DataFrame()
        
        pipeline_util_pct = 0.0
        if self.current_state["pipeline"]["max_capacity"] > 0:
            pipeline_util_pct = (
                self.current_state["pipeline"]["current_utilization"] / 
                self.current_state["pipeline"]["max_capacity"] * 100
            )
        
        data = {
            "current_date": [self.current_state["current_date"]],
            "total_production": [self.current_state["basin"]["cumulative_production"]],
            "recovery_factor": [self.current_state["basin"]["recovery_factor"]],
            "daily_production": [self.current_state["summary"]["total_daily_production"]],
            "potential_production": [self.current_state["summary"]["total_potential_production"]],
            "num_active_wells": [self.current_state["summary"]["active_wells"]],
            "pipeline_utilization": [self.current_state["pipeline"]["current_utilization"]],
            "pipeline_capacity": [self.current_state["pipeline"]["max_capacity"]],
            "pipeline_utilization_pct": [pipeline_util_pct],
            "pipeline_operational": [self.current_state["pipeline"]["is_operational"]],
            "pipeline_total_transported": [self.current_state["pipeline"]["total_transported"]],
        }
        return pl.DataFrame(data)
    
    def get_agent_vars_dataframe(self) -> pl.DataFrame:
        """Compatibility method - returns well states as DataFrame."""
        if self.current_state is None:
            return pl.DataFrame()
        
        rows = []
        for well_id, well_state in self.current_state["wells"].items():
            rows.append({
                "AgentID": well_id,
                "Step": self.current_state["step"],
                "daily_production": well_state["daily_production"],
                "daily_potential_production": well_state["daily_potential_production"],
                "cumulative_production": well_state["cumulative_production"],
                "is_active": well_state["is_active"],
            })
        return pl.DataFrame(rows)


class BasinModel(ModelDF):
    """
    Mesa-Frames optimized basin simulation model.
    
    This model orchestrates well, pipeline, and refinery agents using
    vectorized DataFrame operations for maximum performance.
    
    Hierarchy: Country > Market Center > Basins > Wells
    
    Attributes:
        start_date: Simulation start date
        end_date: Simulation end date
        current_date: Current simulation date
        basin_name: Name of the basin
        market_center: Market center name
        country: Country code
        wells: WellAgentSet instance
        pipelines: PipelineAgentSet instance (optional)
        refineries: RefineryAgentSet instance (optional)
        pipeline: Single pipeline for backward compatibility
    """
    
    def __init__(
        self,
        total_recoverable_resources: float,
        start_date: datetime,
        end_date: datetime,
        basin_name: str = "Permian Basin",
        market_center: str = "Permian",
        country: str = "US",
        basin_reserves: Optional[float] = None,
    ) -> None:
        """
        Initialize BasinModel.
        
        Args:
            total_recoverable_resources: Total recoverable oil (bbl)
            start_date: Simulation start date
            end_date: Simulation end date
            basin_name: Basin name
            market_center: Market center name
            country: Country code
            basin_reserves: Initial basin reserves (bbl)
        """
        super().__init__()
        
        self.start_date = start_date
        self.end_date = end_date
        self.current_date = start_date
        self.basin_name = basin_name
        self.market_center = market_center
        self.country = country
        
        # Basin properties
        self.basin_country = country
        self.basin_market_center = market_center
        
        # Initialize step counter
        self._step_count = 0
        
        # Load reserves data
        self.reserves_data = load_reserves_data(market_center, country)
        self.reserves_available = self.reserves_data is not None
        self.reserves_effective_date = (
            self.reserves_data['effective_date'] 
            if self.reserves_data 
            else None
        )
        
        # Initialize reserves tracking
        self.basin_cumulative_production = 0.0
        
        if self.reserves_available:
            self.basin_total_recoverable_resources = self.reserves_data['crude_recoverable_pp_bbl']
            self._initial_remaining_reserves = self.reserves_data['crude_remaining_pp_bbl']
            self._historical_cumulative_production = self.reserves_data['crude_cumul_prod_bbl']
            
            # Will be set when tracking becomes active
            self.basin_remaining_reserves = None
            self.basin_recovery_factor = None
            
            logger.info(
                "Reserves data loaded: initial_remaining=%.0f bbl",
                self._initial_remaining_reserves
            )
        else:
            self.basin_total_recoverable_resources = total_recoverable_resources
            self.basin_remaining_reserves = basin_reserves or total_recoverable_resources
            self.basin_recovery_factor = 0.0
            self._initial_remaining_reserves = None
            self._historical_cumulative_production = None
            logger.warning("No reserves data available. Using provided values.")
        
        self._reserves_initialized = False
        
        # Initialize agent sets
        self.wells = WellAgentSet(self)
        self.pipelines = PipelineAgentSet(self)
        self.refineries = RefineryAgentSet(self)
        
        # Single pipeline for backward compatibility
        self.pipeline = PipelineAgent(
            unique_id="default_pipeline",
            model=self,
            pipeline_name=f"{market_center}_pipeline",
            market_center=market_center,
            basin=basin_name,
            capacity_bpd=CONSTANTS.DEFAULT_PIPELINE_CAPACITY,
        )
        
        # Load grade splits for this market center
        self.grade_splits = load_grade_splits(market_center)
        
        # Monthly accumulator - tracks production by crude grade
        self.monthly_accumulator = self._create_empty_accumulator()
        self._current_month = start_date.month
        self._current_year = start_date.year
        
        # Monthly refinery yields accumulator
        self.monthly_refinery_yields: Dict[str, float] = {}
        self.refinery_enabled = False
        
        # Pipeline flow tracking
        self.monthly_pipeline_input = 0.0
        self.daily_pipeline_input = 0.0
        self.pipeline_storage_buffer = 0.0
        self.pipeline_storage_days_used = 0
        self.pipeline_max_storage_days = 7
        
        # Data collection
        self.simulation_history: List[Dict[str, Any]] = []
        self.simulation_active = True
        
        # Actual production data from CSV (for historical periods)
        # This dictionary maps well_name -> {date_str: production_value}
        self.actual_production_data: Dict[str, Dict[str, float]] = {}
        
        # Drilling constraints
        self.drilling_constraints = {
            WellType.CONVENTIONAL_OFFSHORE.value: CONSTANTS.DEFAULT_OFFSHORE_QUARTERLY_LIMIT,
            "default": float('inf')
        }
        self.quarterly_drilling_tracker: Dict[tuple, Dict[str, int]] = {}
        
        sim_logger.log_simulation_started(
            start_date=start_date.isoformat(),
            end_date=end_date.isoformat(),
            basin_name=basin_name,
            num_wells=0
        )
        
        logger.info(
            "BasinModel initialized: basin=%s, period=%s to %s",
            basin_name, start_date.isoformat(), end_date.isoformat()
        )
    
    def _create_empty_accumulator(self) -> Dict[str, float]:
        """Create a fresh monthly accumulator with all grades at 0."""
        return {
            "hSour": 0.0,   # Heavy Sour
            "hSweet": 0.0,  # Heavy Sweet
            "mSour": 0.0,   # Medium Sour
            "mSweet": 0.0,  # Medium Sweet
            "lSour": 0.0,   # Light Sour
            "lSweet": 0.0,  # Light Sweet
        }
    
    def _get_grade_key(self, crude_grade: str) -> str:
        """Map crude_grade string to accumulator key."""
        return GRADE_KEY_MAPPING.get(crude_grade, "lSweet")
    
    def _is_reserves_tracking_active(self) -> bool:
        """Check if reserves tracking should be active."""
        if not self.reserves_available:
            return False
        if self.reserves_effective_date is None:
            return True  # No effective date means always track
        return self.current_date >= self.reserves_effective_date
    
    def _initialize_reserves_tracking(self) -> None:
        """Initialize reserves tracking when effective date is reached."""
        if self._reserves_initialized:
            return
        
        self.basin_remaining_reserves = self._initial_remaining_reserves
        self.basin_recovery_factor = (
            self._historical_cumulative_production / 
            self.basin_total_recoverable_resources
            if self.basin_total_recoverable_resources > 0 else 0
        )
        self._reserves_initialized = True
        
        logger.info(
            "Reserves tracking initialized: remaining=%.0f bbl, recovery_factor=%.4f",
            self.basin_remaining_reserves, self.basin_recovery_factor
        )
    
    @property
    def basin_wells(self) -> List:
        """Property for backward compatibility - returns list representation."""
        if self.wells.agents.is_empty():
            return []
        return self.wells.to_dict_list()
    
    def add_well(self, **kwargs) -> None:
        """Add a single well to the model.
        
        Args:
            **kwargs: Well configuration parameters
        """
        # Generate unique ID if not provided
        if "unique_id" not in kwargs:
            kwargs["unique_id"] = f"well_{self._step_count}_{self.wells.agents.shape[0]}"
        
        # Set default production start date
        if "production_start_date" not in kwargs:
            kwargs["production_start_date"] = self.current_date
        
        self.wells.add_single_well(**kwargs)
        
        logger.debug("Well added via add_well: %s", kwargs.get("unique_id"))
    
    def add_wells_from_dataframe(self, wells_df: pl.DataFrame) -> None:
        """Add multiple wells from a DataFrame.
        
        This is the preferred method for bulk well loading.
        
        Args:
            wells_df: DataFrame with well configurations
        """
        self.wells.add_wells(wells_df)
        logger.info("Added %d wells from DataFrame", wells_df.shape[0])
    
    def load_actual_production_data(
        self,
        fact_filename: str = "houston_fact_combined_cleaned.csv",
        basin_name: Optional[str] = None,
        market_center: Optional[str] = None,
        country: Optional[str] = None
    ) -> None:
        """
        Load actual production data from CSV for wells.
        
        This data will be used instead of simulation for historical periods.
        Simulation will only be used for future periods (when no actuals exist).
        
        Args:
            fact_filename: Name of the fact CSV file
            basin_name: Optional basin name filter
            market_center: Optional market center filter
            country: Optional country filter
        """
        self.actual_production_data = load_actual_production_data(
            fact_filename=fact_filename,
            start_date=self.start_date,
            end_date=self.end_date,
            basin_name=basin_name or self.basin_name,
            market_center=market_center or self.market_center,
            country=country or self.country
        )
        
        logger.info(
            "Loaded actual production data: %d wells with historical data",
            len(self.actual_production_data)
        )
    
    def step(self) -> Dict[str, Any]:
        """Execute one simulation step (one day).
        
        This is the main simulation loop method. It:
        1. Updates current date
        2. Checks/activates reserves tracking
        3. Steps all well agents (vectorized production calculation)
        4. Allocates production to reserves
        5. Routes production through pipeline
        6. Accumulates production by grade
        7. Checks for monthly rollover (refinery processing)
        8. Collects data
        
        Returns:
            Dictionary with step results
        """
        if not self.simulation_active:
            return {"status": "inactive"}
        
        if self.current_date > self.end_date:
            self.simulation_active = False
            return {"status": "completed"}
        
        self._step_count += 1
        
        # Check if reserves tracking should start
        if self._is_reserves_tracking_active() and not self._reserves_initialized:
            self._initialize_reserves_tracking()
        
        # Step all wells (vectorized)
        self.wells.step()
        
        # Get total potential production
        wells_df = self.wells.agents
        total_potential = wells_df.filter(
            pl.col("is_active")
        )["daily_potential_production"].sum()
        
        # Allocate production against reserves
        if self._is_reserves_tracking_active() and self.basin_remaining_reserves is not None:
            if total_potential > self.basin_remaining_reserves:
                # Scale down production proportionally
                scale_factor = self.basin_remaining_reserves / total_potential if total_potential > 0 else 0
                
                realized_production = wells_df.with_columns([
                    (pl.col("daily_potential_production") * scale_factor).alias("realized")
                ])
                
                total_realized = realized_production["realized"].sum()
                self.basin_remaining_reserves = 0.0
                
                logger.warning(
                    "Reserves depleted! Scaled production from %.0f to %.0f bbl",
                    total_potential, total_realized
                )
            else:
                total_realized = total_potential
                self.basin_remaining_reserves -= total_realized
            
            # Update recovery factor
            self.basin_cumulative_production += total_realized
            self.basin_recovery_factor = (
                self.basin_cumulative_production / self.basin_total_recoverable_resources
                if self.basin_total_recoverable_resources > 0 else 0
            )
        else:
            total_realized = total_potential
            self.basin_cumulative_production += total_realized
        
        # Update wells with realized production (vectorized)
        if total_potential > 0:
            scale = total_realized / total_potential if total_potential > 0 else 0
            realized_series = wells_df["daily_potential_production"] * scale
            self.wells.update_production_vectorized(realized_series)
        
        # Route through pipeline
        transported = self.pipeline.add_flow(total_realized)
        self.daily_pipeline_input = transported
        self.monthly_pipeline_input += transported
        
        # Accumulate production by grade
        production_by_grade = self.wells.get_production_by_grade()
        for grade, production in production_by_grade.items():
            grade_key = self._get_grade_key(grade)
            self.monthly_accumulator[grade_key] += production * (total_realized / total_potential if total_potential > 0 else 0)
        
        # Check for monthly rollover
        self._check_and_reset_monthly_accumulator()
        
        # Collect step data
        step_data = {
            "date": self.current_date.isoformat(),
            "step": self._step_count,
            "total_potential_production": total_potential,
            "total_realized_production": total_realized,
            "active_wells": self.wells.get_active_wells_count(),
            "total_wells": self.wells.agents.shape[0],
            "pipeline_transported": transported,
            "pipeline_utilization_pct": self.pipeline.utilization_pct,
            "basin_remaining_reserves": self.basin_remaining_reserves,
            "basin_recovery_factor": self.basin_recovery_factor,
            "cumulative_production": self.basin_cumulative_production,
        }
        
        self.simulation_history.append(step_data)
        
        # Advance date
        self.current_date += timedelta(days=1)
        self.pipeline.reset_daily()
        
        return step_data
    
    def _check_and_reset_monthly_accumulator(self) -> None:
        """Check if we've moved to a new month and process accordingly."""
        current_month = self.current_date.month
        current_year = self.current_date.year
        
        if current_month != self._current_month or current_year != self._current_year:
            # Log completed month's production
            month_name = datetime(self._current_year, self._current_month, 1).strftime("%B %Y")
            total = sum(self.monthly_accumulator.values())
            
            sim_logger.log_monthly_production(
                year=self._current_year,
                month=self._current_month,
                production_by_grade=self.monthly_accumulator,
                total=total
            )
            
            # Process through refineries if enabled
            if self.refinery_enabled and not self.refineries.agents.is_empty():
                # Convert accumulator keys to crude grades
                crude_volumes = {}
                for key, volume in self.monthly_accumulator.items():
                    if volume > 0:
                        grade = GRADE_KEY_REVERSE_MAPPING.get(key)
                        if grade:
                            crude_volumes[grade] = volume
                
                if crude_volumes:
                    yields = self.refineries.allocate_crude(
                        crude_volumes,
                        self._current_year,
                        self._current_month
                    )
                    self.monthly_refinery_yields = self.refineries.get_total_yields()
            
            # Reset accumulator
            self.monthly_accumulator = self._create_empty_accumulator()
            self.monthly_pipeline_input = 0.0
            
            # Update month/year trackers
            self._current_month = current_month
            self._current_year = current_year
    
    def run_simulation(
        self, 
        steps: Optional[int] = None,
        progress_callback: Optional[callable] = None
    ) -> pl.DataFrame:
        """Run the simulation for specified number of steps or until end date.
        
        Args:
            steps: Number of steps to run (None = run until end_date)
            progress_callback: Optional callback for progress updates
            
        Returns:
            DataFrame with simulation results
        """
        start_time = time.perf_counter()
        
        total_steps = steps or (self.end_date - self.current_date).days
        completed = 0
        
        logger.info("Starting simulation run: %d steps", total_steps)
        
        while self.simulation_active and (steps is None or completed < steps):
            result = self.step()
            
            if result.get("status") in ["completed", "inactive"]:
                break
            
            completed += 1
            
            if progress_callback and completed % 30 == 0:  # Update every 30 days
                progress_callback(completed, total_steps)
        
        elapsed = time.perf_counter() - start_time
        
        sim_logger.log_simulation_completed(
            total_steps=completed,
            total_production=self.basin_cumulative_production,
            elapsed_time=elapsed
        )
        
        # Convert history to DataFrame
        if self.simulation_history:
            results_df = pl.DataFrame(self.simulation_history)
        else:
            results_df = pl.DataFrame()
        
        return results_df
    
    def get_state(self) -> Dict[str, Any]:
        """Get current model state.
        
        Returns:
            Dictionary with model state
        """
        return {
            "current_date": self.current_date.isoformat(),
            "step": self._step_count,
            "basin_name": self.basin_name,
            "market_center": self.market_center,
            "country": self.country,
            "total_wells": self.wells.agents.shape[0],
            "active_wells": self.wells.get_active_wells_count(),
            "basin_remaining_reserves": self.basin_remaining_reserves,
            "basin_cumulative_production": self.basin_cumulative_production,
            "basin_recovery_factor": self.basin_recovery_factor,
            "simulation_active": self.simulation_active,
            "wells_summary": self.wells.get_wells_summary(),
            "pipeline_summary": {
                "daily_transport": self.pipeline.daily_transport,
                "cumulative_transport": self.pipeline.cumulative_transport,
                "utilization_pct": self.pipeline.utilization_pct,
                "max_capacity": self.pipeline.max_capacity,
            },
        }
    
    def get_wells_dataframe(self) -> pl.DataFrame:
        """Get wells DataFrame.
        
        Returns:
            Polars DataFrame with all wells
        """
        return self.wells.agents
    
    def get_simulation_results(self) -> pl.DataFrame:
        """Get simulation history as DataFrame.
        
        Returns:
            DataFrame with simulation history
        """
        if self.simulation_history:
            return pl.DataFrame(self.simulation_history)
        return pl.DataFrame()
    
    def load_refineries(
        self, 
        refineries_df: pl.DataFrame,
        mapping_df: Optional[pl.DataFrame] = None
    ) -> None:
        """Load refineries from DataFrame.
        
        Args:
            refineries_df: DataFrame with refinery configurations
            mapping_df: Optional yield mapping DataFrame
        """
        self.refineries.add_refineries(refineries_df)
        
        if mapping_df is not None:
            self.refineries.set_mapping_data(mapping_df)
        
        self.refinery_enabled = True
        logger.info("Loaded %d refineries", refineries_df.shape[0])
    
    def load_pipelines(self, pipelines_df: pl.DataFrame) -> None:
        """Load pipelines from DataFrame.
        
        Args:
            pipelines_df: DataFrame with pipeline configurations
        """
        self.pipelines.add_pipelines(pipelines_df)
        logger.info("Loaded %d pipelines", pipelines_df.shape[0])
    
    def reset(self, keep_wells: bool = False) -> None:
        """Reset model to initial state.
        
        Args:
            keep_wells: If True, keep existing wells
        """
        self.current_date = self.start_date
        self._step_count = 0
        self.basin_cumulative_production = 0.0
        self._reserves_initialized = False
        self.simulation_active = True
        self.simulation_history = []
        self.monthly_accumulator = self._create_empty_accumulator()
        self._current_month = self.start_date.month
        self._current_year = self.start_date.year
        
        if self.reserves_available:
            self.basin_remaining_reserves = None
            self.basin_recovery_factor = None
        
        if not keep_wells:
            self.wells = WellAgentSet(self)
        
        self.pipeline.daily_transport = 0.0
        self.pipeline.cumulative_transport = 0.0
        self.pipeline.utilization_pct = 0.0
        
        logger.info("Model reset (keep_wells=%s)", keep_wells)
    
    # -----------------------------------------------------------------
    # Additional Methods for Full Feature Parity
    # -----------------------------------------------------------------
    
    def _get_selected_basins(self) -> List[str]:
        """
        Return list of selected basins based on wells in the model.
        
        Returns:
            List of unique basin names from wells
        """
        if self.wells.agents.is_empty():
            return [self.basin_name]
        
        if "basin" in self.wells.agents.columns:
            basins = self.wells.agents["basin"].unique().to_list()
            return basins if basins else [self.basin_name]
        
        return [self.basin_name]
    
    def _get_quarter(self, date: Optional[datetime] = None) -> tuple:
        """
        Get (year, quarter) tuple for a date.
        
        Args:
            date: Date to get quarter for (uses current_date if None)
            
        Returns:
            Tuple of (year, quarter number 1-4)
        """
        d = date or self.current_date
        quarter = (d.month - 1) // 3 + 1
        return (d.year, quarter)
    
    def _accumulate_production_by_grade(
        self, 
        wells_df: pl.DataFrame,
        scale_factor: float = 1.0
    ) -> None:
        """
        Accumulate production by crude grade into monthly accumulator.
        
        Args:
            wells_df: Wells DataFrame with production data
            scale_factor: Scale factor for production (reserves constraint)
        """
        production_by_grade = self.wells.get_production_by_grade()
        
        for grade, production in production_by_grade.items():
            grade_key = self._get_grade_key(grade)
            scaled_production = production * scale_factor
            self.monthly_accumulator[grade_key] += scaled_production
    
    def _check_drilling_constraint(
        self, 
        well_type: str,
        date: Optional[datetime] = None
    ) -> bool:
        """
        Check if a new well can be drilled based on quarterly constraints.
        
        Args:
            well_type: Type of well to drill
            date: Date for the constraint check (default: current_date)
            
        Returns:
            True if drilling is allowed, False if constraint exceeded
        """
        check_date = date or self.current_date
        quarter_key = self._get_quarter(check_date)
        
        # Get constraint for this well type
        constraint = self.drilling_constraints.get(
            well_type, 
            self.drilling_constraints.get("default", float('inf'))
        )
        
        # Initialize tracker for this quarter if needed
        if quarter_key not in self.quarterly_drilling_tracker:
            self.quarterly_drilling_tracker[quarter_key] = {}
        
        # Get current count
        current_count = self.quarterly_drilling_tracker[quarter_key].get(well_type, 0)
        
        return current_count < constraint
    
    def _load_wells_for_current_date(
        self, 
        well_schedule_df: pl.DataFrame
    ) -> int:
        """
        Load wells scheduled for the current date.
        
        Args:
            well_schedule_df: DataFrame with well schedules
            
        Returns:
            Number of wells loaded
        """
        # Filter wells for current date
        date_col = "production_start_date"
        if date_col not in well_schedule_df.columns:
            date_col = "start_date"
        
        if date_col not in well_schedule_df.columns:
            return 0
        
        # Filter by date
        today_wells = well_schedule_df.filter(
            pl.col(date_col) == self.current_date
        )
        
        if today_wells.is_empty():
            return 0
        
        # Add wells
        self.wells.add_wells(today_wells)
        
        # Update drilling tracker
        quarter_key = self._get_quarter()
        if quarter_key not in self.quarterly_drilling_tracker:
            self.quarterly_drilling_tracker[quarter_key] = {}
        
        # Count by well type
        if "well_type" in today_wells.columns:
            type_counts = today_wells.group_by("well_type").agg(pl.len().alias("count"))
            for row in type_counts.iter_rows(named=True):
                wt = row["well_type"]
                count = row["count"]
                prev = self.quarterly_drilling_tracker[quarter_key].get(wt, 0)
                self.quarterly_drilling_tracker[quarter_key][wt] = prev + count
        
        return today_wells.shape[0]
    
    def _check_depletion(self) -> bool:
        """
        Check if basin is depleted.
        
        Returns:
            True if reserves are depleted, False otherwise
        """
        if not self._is_reserves_tracking_active():
            return False
        
        if self.basin_remaining_reserves is None:
            return False
        
        return self.basin_remaining_reserves <= 0.0
    
    def get_simulation_state(self) -> Dict[str, Any]:
        """
        Get comprehensive simulation state dictionary.
        
        Returns:
            Full state dictionary including model, basin, pipeline, and wells
        """
        reserves_tracking = self._is_reserves_tracking_active()
        
        # Build wells state
        wells_state = {}
        if not self.wells.agents.is_empty():
            for row in self.wells.agents.iter_rows(named=True):
                wells_state[row["unique_id"]] = {
                    "days_on_production": row.get("days_on_production", 0),
                    "cumulative_production": row.get("cumulative_production", 0.0),
                    "daily_production": row.get("daily_production", 0.0),
                    "daily_potential_production": row.get("daily_potential_production", 0.0),
                    "is_active": row.get("is_active", False),
                    "status": row.get("status", "Active"),
                }
        
        # Calculate summary stats
        wells_df = self.wells.agents
        total_daily = wells_df["daily_production"].sum() if not wells_df.is_empty() else 0.0
        total_potential = wells_df["daily_potential_production"].sum() if not wells_df.is_empty() else 0.0
        active_wells = self.wells.get_active_wells_count()
        
        return {
            "current_date": self.current_date.isoformat(),
            "step": self._step_count,
            "reserves_tracking_active": reserves_tracking,
            "reserves_effective_date": (
                self.reserves_effective_date.isoformat() 
                if self.reserves_effective_date 
                else None
            ),
            "basin": {
                "name": self.basin_name,
                "market_center": self.market_center,
                "country": self.country,
                "remaining_reserves": self.basin_remaining_reserves if reserves_tracking else None,
                "recovery_factor": self.basin_recovery_factor if reserves_tracking else None,
                "cumulative_production": self.basin_cumulative_production,
                "total_recoverable_resources": self.basin_total_recoverable_resources,
                "is_depleted": self._check_depletion(),
            },
            "pipeline": {
                "cumulative_transport": self.pipeline.cumulative_transport,
                "daily_transport": self.pipeline.daily_transport,
                "max_capacity": self.pipeline.max_capacity,
                "utilization_pct": self.pipeline.utilization_pct,
                "is_operational": True,
                "storage_buffer": self.pipeline_storage_buffer,
            },
            "wells": wells_state,
            "summary": {
                "total_daily_production": total_daily,
                "total_potential_production": total_potential,
                "active_wells": active_wells,
                "total_wells": wells_df.shape[0],
            },
            "monthly_accumulator": dict(self.monthly_accumulator),
            "simulation_active": self.simulation_active,
        }
    
    def get_monthly_accumulator_state(self) -> Dict[str, Any]:
        """
        Get current state of monthly production accumulator.
        
        Returns:
            Dictionary with accumulator state
        """
        return {
            "year": self._current_year,
            "month": self._current_month,
            "production_by_grade": dict(self.monthly_accumulator),
            "total_production": sum(self.monthly_accumulator.values()),
            "pipeline_input": self.monthly_pipeline_input,
            "refinery_enabled": self.refinery_enabled,
            "refinery_yields": dict(self.monthly_refinery_yields) if self.monthly_refinery_yields else {},
        }
    
    def get_production_history(self) -> pl.DataFrame:
        """
        Get production history as DataFrame.
        
        Returns:
            DataFrame with production history
        """
        if self.simulation_history:
            return pl.DataFrame(self.simulation_history)
        return pl.DataFrame()
    
    def _state_to_model_dict(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert state dictionary to model-level summary.
        
        Args:
            state: Full state dictionary
            
        Returns:
            Model-level summary dictionary
        """
        pipeline_util_pct = 0.0
        if state["pipeline"]["max_capacity"] > 0:
            pipeline_util_pct = (
                state["pipeline"]["daily_transport"] / 
                state["pipeline"]["max_capacity"] * 100
            )
        
        return {
            "current_date": state["current_date"],
            "step": state["step"],
            "total_production": state["basin"]["cumulative_production"],
            "recovery_factor": state["basin"]["recovery_factor"],
            "remaining_reserves": state["basin"]["remaining_reserves"],
            "daily_production": state["summary"]["total_daily_production"],
            "potential_production": state["summary"]["total_potential_production"],
            "num_active_wells": state["summary"]["active_wells"],
            "num_total_wells": state["summary"]["total_wells"],
            "pipeline_utilization": state["pipeline"]["daily_transport"],
            "pipeline_capacity": state["pipeline"]["max_capacity"],
            "pipeline_utilization_pct": pipeline_util_pct,
            "is_depleted": state["basin"]["is_depleted"],
        }
    
    def _state_to_agent_dict(self, state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Convert state dictionary to agent-level list.
        
        Args:
            state: Full state dictionary
            
        Returns:
            List of agent state dictionaries
        """
        agents = []
        for well_id, well_state in state.get("wells", {}).items():
            agents.append({
                "well_id": well_id,
                "step": state["step"],
                "daily_production": well_state["daily_production"],
                "daily_potential_production": well_state["daily_potential_production"],
                "cumulative_production": well_state["cumulative_production"],
                "days_on_production": well_state["days_on_production"],
                "is_active": well_state["is_active"],
                "status": well_state["status"],
            })
        return agents
    
    # -----------------------------------------------------------------
    # Pipeline Flow Allocation Methods
    # -----------------------------------------------------------------
    
    def _monthly_to_daily(self, monthly_volume: float, month: int, year: int) -> float:
        """
        Convert monthly volume to daily average.
        
        Args:
            monthly_volume: Total volume for month (bbl)
            month: Month number (1-12)
            year: Year
            
        Returns:
            Daily average volume (bbl/day)
        """
        days_in_month = calendar.monthrange(year, month)[1]
        return monthly_volume / days_in_month if days_in_month > 0 else 0.0
    
    def _allocate_pipeline_daily_flow(
        self,
        total_production: float,
        pipelines: Optional[List[PipelineAgent]] = None
    ) -> Dict[str, float]:
        """
        Allocate daily production flow across pipelines.
        
        Uses priority-based allocation:
        1. Primary pipeline gets first allocation up to capacity
        2. Overflow goes to secondary pipelines
        3. Remaining overflow goes to storage buffer
        
        Args:
            total_production: Total daily production to allocate
            pipelines: Optional list of pipeline agents (uses self.pipeline if None)
            
        Returns:
            Dictionary mapping pipeline_id to allocated flow
        """
        allocation = {}
        remaining = total_production
        
        if pipelines is None:
            # Use single pipeline
            transported = self.pipeline.add_flow(remaining)
            allocation[self.pipeline.unique_id] = transported
            remaining -= transported
        else:
            # Use multiple pipelines in order
            for pipe in pipelines:
                if remaining <= 0:
                    allocation[pipe.unique_id] = 0.0
                    continue
                
                transported = pipe.add_flow(remaining)
                allocation[pipe.unique_id] = transported
                remaining -= transported
        
        # Handle overflow to storage
        if remaining > 0:
            self._handle_pipeline_overflow(remaining)
        
        return allocation
    
    def _handle_pipeline_overflow(self, overflow_volume: float) -> float:
        """
        Handle pipeline overflow by routing to storage buffer.
        
        Storage buffer has limited capacity (max days × average daily capacity).
        Overflow beyond buffer is lost/curtailed.
        
        Args:
            overflow_volume: Volume that couldn't fit in pipeline
            
        Returns:
            Volume actually stored (may be less than overflow)
        """
        max_storage = self.pipeline.max_capacity * self.pipeline_max_storage_days
        current_storage = self.pipeline_storage_buffer
        available = max_storage - current_storage
        
        stored = min(overflow_volume, available)
        self.pipeline_storage_buffer += stored
        
        if stored > 0:
            self.pipeline_storage_days_used += 1
            logger.debug(
                "Pipeline overflow: %.0f bbl stored (buffer: %.0f/%.0f)",
                stored, self.pipeline_storage_buffer, max_storage
            )
        
        curtailed = overflow_volume - stored
        if curtailed > 0:
            logger.warning(
                "Pipeline overflow curtailed: %.0f bbl lost",
                curtailed
            )
        
        return stored
    
    def get_pipeline_daily_output(
        self, 
        pipeline_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get daily output for a specific pipeline.
        
        Args:
            pipeline_id: Pipeline ID (uses default pipeline if None)
            
        Returns:
            Dictionary with pipeline daily metrics
        """
        if pipeline_id is None:
            pipe = self.pipeline
        else:
            # Look up in pipelines collection
            pipe_df = self.pipelines.agents.filter(
                pl.col("unique_id") == pipeline_id
            )
            if pipe_df.is_empty():
                return {"error": f"Pipeline {pipeline_id} not found"}
            
            row = pipe_df.row(0, named=True)
            return {
                "pipeline_id": pipeline_id,
                "daily_transport": row.get("daily_transport", 0.0),
                "capacity_bpd": row.get("capacity_bpd", 0.0),
                "utilization_pct": row.get("utilization_pct", 0.0),
            }
        
        return {
            "pipeline_id": pipe.unique_id,
            "daily_transport": pipe.daily_transport,
            "capacity_bpd": pipe.max_capacity,
            "utilization_pct": pipe.utilization_pct,
            "cumulative_transport": pipe.cumulative_transport,
        }
    
    def get_all_pipelines_daily_output(self) -> Dict[str, Dict[str, Any]]:
        """
        Get daily output for all pipelines.
        
        Returns:
            Dictionary mapping pipeline_id to output metrics
        """
        outputs = {}
        
        # Default pipeline
        outputs[self.pipeline.unique_id] = self.get_pipeline_daily_output()
        
        # Additional pipelines
        if not self.pipelines.agents.is_empty():
            for row in self.pipelines.agents.iter_rows(named=True):
                pid = row["unique_id"]
                outputs[pid] = {
                    "pipeline_id": pid,
                    "daily_transport": row.get("daily_transport", 0.0),
                    "capacity_bpd": row.get("capacity_bpd", 0.0),
                    "utilization_pct": row.get("utilization_pct", 0.0),
                    "cumulative_transport": row.get("cumulative_transport", 0.0),
                }
        
        return outputs
    
    def get_pipeline_state(self) -> Dict[str, Any]:
        """
        Get comprehensive pipeline system state.
        
        Returns:
            Dictionary with all pipeline state information
        """
        total_capacity = self.pipeline.max_capacity
        total_transport = self.pipeline.daily_transport
        total_cumulative = self.pipeline.cumulative_transport
        
        # Add from pipeline collection
        if not self.pipelines.agents.is_empty():
            total_capacity += self.pipelines.agents["capacity_bpd"].sum()
            if "daily_transport" in self.pipelines.agents.columns:
                total_transport += self.pipelines.agents["daily_transport"].sum()
            if "cumulative_transport" in self.pipelines.agents.columns:
                total_cumulative += self.pipelines.agents["cumulative_transport"].sum()
        
        return {
            "default_pipeline": self.get_pipeline_daily_output(),
            "additional_pipelines": self.get_all_pipelines_daily_output(),
            "total_capacity_bpd": total_capacity,
            "total_daily_transport": total_transport,
            "total_cumulative_transport": total_cumulative,
            "system_utilization_pct": (total_transport / total_capacity * 100) if total_capacity > 0 else 0.0,
            "storage_buffer": self.pipeline_storage_buffer,
            "storage_days_used": self.pipeline_storage_days_used,
            "max_storage_capacity": self.pipeline.max_capacity * self.pipeline_max_storage_days,
        }
