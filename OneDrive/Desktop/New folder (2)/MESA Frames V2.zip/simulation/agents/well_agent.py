"""
WellAgentSet - Vectorized Well Agents for Mesa-Frames SimOxy Simulation.

This module implements a vectorized well agent set using mesa-frames AgentSetPolars.
All operations are performed on entire DataFrames for maximum performance.

OPTIMIZATION:
- Uses Polars expressions for vectorized calculations
- Avoids Python loops for agent operations
- Batches all well computations into single DataFrame operations
- Supports efficient bulk operations on 10,000+ wells

COMPLIANCE:
- Implements hyperbolic/exponential/harmonic decline curves
- Supports drive mechanism effects on decline rate
- Configuration multipliers for productivity
- EUR limits and economic thresholds
"""

from __future__ import annotations

import math
from datetime import datetime
from typing import Optional, Dict, Any, List, TYPE_CHECKING
import numpy as np

import polars as pl
from mesa_frames import AgentSetPolars

from config.simulation_config import (
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    WellStatus,
    CrudeGrade,
    CONSTANTS,
    WELL_TYPE_PARAMETERS,
    DECLINE_TYPE_PARAMETERS,
    DRIVE_MECHANISM_DECLINE_MULTIPLIER,
    CONFIGURATION_MULTIPLIER,
    CRUDE_GRADE_PROBABILITIES,
    get_well_type_defaults,
    get_well_type_defaults_polars,
    get_drive_mechanism_multipliers_polars,
    get_configuration_multipliers_polars,
)
from utils.logging_config import get_logger

if TYPE_CHECKING:
    from simulation.model import BasinModel

logger = get_logger(__name__)


class WellAgentSet(AgentSetPolars):
    """
    Vectorized Well Agent Set using mesa-frames.
    
    All wells are stored in a single Polars DataFrame with vectorized operations
    for production calculations. This provides massive performance improvements
    over traditional agent-based models.
    
    DataFrame Columns:
        - unique_id: Unique well identifier
        - well_type: Type of well (Shale Oil, Conventional, etc.)
        - initial_production: Initial production rate (Qi) in bbl/day
        - decline_exponent: b-factor for decline curve
        - nominal_decline_rate: Annual decline rate
        - drive_mechanism: Reservoir drive type
        - configuration: Well configuration (Vertical, Horizontal, Frac)
        - crude_grade: Crude oil grade
        - production_start_date: Date when production begins
        - production_end_date: Date when production ends (optional)
        - days_on_production: Days since production started
        - cumulative_production: Total production to date (bbl)
        - daily_production: Realized production for current day (bbl/day)
        - daily_potential_production: Calculated potential production (bbl/day)
        - eur: Estimated Ultimate Recovery (bbl)
        - is_active: Whether well is currently producing
        - status: Operational status (Active, Choked, Inactive)
        - max_capacity: Maximum production capacity (bbl/day)
        - ecr_enabled: Whether Enhanced Completion Recovery is enabled
        - is_new: Whether this is a new well (forecast) or existing
    """
    
    def __init__(self, model: "BasinModel"):
        """Initialize the WellAgentSet.
        
        Args:
            model: Parent BasinModel instance
        """
        super().__init__(model)
        
        # Precompute lookup DataFrames for vectorized joins
        self._drive_multipliers_df = get_drive_mechanism_multipliers_polars()
        self._config_multipliers_df = get_configuration_multipliers_polars()
        self._well_defaults_df = get_well_type_defaults_polars()
        
        # Counter for generating unique integer IDs (mesa-frames requires int64)
        self._next_well_id = 1
        
        logger.info("WellAgentSet initialized for model")
    
    def add_wells(self, wells_df: pl.DataFrame) -> None:
        """Add multiple wells from a DataFrame.
        
        This is the preferred method for bulk well creation. The DataFrame
        should contain columns matching the well schema.
        
        Args:
            wells_df: DataFrame with well configurations
        """
        if wells_df.is_empty():
            logger.warning("Empty DataFrame passed to add_wells")
            return
        
        # Ensure required columns exist
        wells_df = self._prepare_wells_dataframe(wells_df)
        
        # Add the wells to the agent set
        self.add(wells_df)
        
        logger.info("Added %d wells to WellAgentSet", wells_df.shape[0])
    
    def add_single_well(
        self,
        unique_id: str,
        well_type: str = WellType.CONVENTIONAL_ONSHORE.value,
        initial_production: Optional[float] = None,
        decline_exponent: Optional[float] = None,
        nominal_decline_rate: Optional[float] = None,
        decline_type: str = DeclineType.HYPERBOLIC.value,
        production_start_date: Optional[datetime] = None,
        production_end_date: Optional[datetime] = None,
        eur: Optional[float] = None,
        crude_grade: Optional[str] = None,
        location: str = "Basin",
        max_capacity: Optional[float] = None,
        drive_mechanism: str = DriveMechanism.SOLUTION_GAS_DRIVE.value,
        configuration: str = WellConfiguration.VERTICAL.value,
        ecr_enabled: bool = False,
        is_new: bool = True,
        api_number: Optional[int] = None,
        last_known_qi: Optional[float] = None,
        last_known_di: Optional[float] = None,
        last_data_date: Optional[datetime] = None,
        **kwargs
    ) -> None:
        """Add a single well to the agent set.
        
        Args:
            unique_id: Unique well identifier
            well_type: Type of well
            initial_production: Initial production rate (bbl/day)
            decline_exponent: b-factor for decline curve
            nominal_decline_rate: Annual decline rate
            decline_type: Type of decline curve
            production_start_date: Date when production begins
            production_end_date: Date when production ends
            eur: Estimated Ultimate Recovery (bbl)
            crude_grade: Crude oil grade
            location: Well location
            max_capacity: Maximum production capacity (bbl/day)
            drive_mechanism: Reservoir drive mechanism
            configuration: Well configuration
            ecr_enabled: Whether ECR is enabled
            is_new: Whether this is a new well
            **kwargs: Additional well attributes
        """
        # Get defaults for well type
        defaults = get_well_type_defaults(well_type)
        
        # Handle decline type parameters
        decline_params = DECLINE_TYPE_PARAMETERS.get(
            decline_type, 
            DECLINE_TYPE_PARAMETERS[DeclineType.HYPERBOLIC.value]
        )
        
        # Determine b-factor
        b_factor = decline_exponent
        if b_factor is None:
            b_factor = decline_params.get("b_factor") or defaults["b_factor"]
        
        # Determine decline rate
        nom_decline = nominal_decline_rate or defaults["nominal_decline_rate"]
        nom_decline *= decline_params.get("decline_multiplier", 1.0)
        
        # Initial production with configuration multiplier
        qi = initial_production or defaults["initial_production"]
        qi *= CONFIGURATION_MULTIPLIER.get(configuration, 1.0)
        
        # Max capacity
        max_cap = max_capacity or qi * defaults["default_max_capacity_multiplier"]
        
        # Production dates
        start_date = production_start_date or self.model.start_date
        
        # Calculate days on production if well started before simulation
        if start_date < self.model.start_date:
            days_on_prod = (self.model.start_date - start_date).days
        else:
            days_on_prod = 0
        
        # Crude grade
        if crude_grade is None:
            crude_grade = self._assign_crude_grade(well_type)
        
        # Generate integer unique_id (mesa-frames requirement)
        int_id = self._next_well_id
        self._next_well_id += 1
        
        # Create single-row DataFrame
        well_data = {
            "unique_id": [int_id],
            "well_name": [unique_id],  # Store string ID as well_name
            "api_number": [api_number],  # Integer API number for actual production lookup
            "well_type": [well_type],
            "initial_production": [float(qi)],
            "decline_exponent": [float(b_factor)],
            "nominal_decline_rate": [float(nom_decline)],
            "decline_type": [decline_type],
            "drive_mechanism": [drive_mechanism],
            "configuration": [configuration],
            "crude_grade": [crude_grade],
            "location": [location],
            "production_start_date": [start_date],
            "production_end_date": [production_end_date],
            "days_on_production": [days_on_prod],
            "cumulative_production": [0.0],
            "daily_production": [0.0],
            "daily_potential_production": [0.0],
            "eur": [eur or 0.0],
            "max_capacity": [float(max_cap)],
            "is_active": [False],
            "status": [WellStatus.ACTIVE.value],
            "ecr_enabled": [ecr_enabled],
            "is_new": [is_new],
            "production_cost": [0.0],
            # Fallback decline curve parameters for wells with historical data
            "last_known_qi": [last_known_qi],
            "last_known_di": [last_known_di],
            "last_data_date": [last_data_date],
        }
        
        well_df = pl.DataFrame(well_data)
        
        # Calculate EUR if not provided
        if eur is None or eur <= 0:
            well_df = self._calculate_eur_for_wells(well_df)
        
        self.add(well_df)
        
        logger.debug(
            "Added well: id=%s, type=%s, qi=%.0f bbl/day",
            unique_id, well_type, qi
        )
    
    def _prepare_wells_dataframe(self, df: pl.DataFrame) -> pl.DataFrame:
        """Prepare and validate wells DataFrame.
        
        Adds missing columns with defaults and validates data types.
        
        Args:
            df: Input DataFrame with well data
            
        Returns:
            Prepared DataFrame with all required columns
        """
        # Handle unique_id - mesa-frames requires int64
        # If unique_id is string, rename to well_name and create int unique_id
        if "unique_id" in df.columns:
            if df["unique_id"].dtype == pl.Utf8:
                # String IDs - rename to well_name
                df = df.rename({"unique_id": "well_name"})
                # Generate integer IDs
                start_id = self._next_well_id
                df = df.with_columns(
                    pl.arange(start_id, start_id + df.shape[0], eager=True).alias("unique_id")
                )
                self._next_well_id = start_id + df.shape[0]
            elif df["unique_id"].dtype != pl.Int64:
                # Cast to int64
                df = df.with_columns(pl.col("unique_id").cast(pl.Int64))
        else:
            # Generate integer IDs
            start_id = self._next_well_id
            df = df.with_columns(
                pl.arange(start_id, start_id + df.shape[0], eager=True).alias("unique_id")
            )
            self._next_well_id = start_id + df.shape[0]
        
        # Ensure well_name column exists
        if "well_name" not in df.columns:
            df = df.with_columns(
                pl.col("unique_id").cast(pl.Utf8).alias("well_name")
            )
        
        # Define default values for missing columns
        defaults = {
            "well_type": WellType.CONVENTIONAL_ONSHORE.value,
            "decline_type": DeclineType.HYPERBOLIC.value,
            "drive_mechanism": DriveMechanism.SOLUTION_GAS_DRIVE.value,
            "configuration": WellConfiguration.VERTICAL.value,
            "crude_grade": CrudeGrade.LIGHT_SWEET.value,
            "location": "Basin",
            "days_on_production": 0,
            "cumulative_production": 0.0,
            "daily_production": 0.0,
            "daily_potential_production": 0.0,
            "is_active": False,
            "status": WellStatus.ACTIVE.value,
            "ecr_enabled": False,
            "is_new": True,
            "production_cost": 0.0,
        }
        
        # Add api_number column for actual production data matching
        if "api_number" not in df.columns:
            df = df.with_columns(pl.lit(None).cast(pl.Int64).alias("api_number"))
        
        # Add fallback decline curve columns for wells with historical data
        if "last_known_qi" not in df.columns:
            df = df.with_columns(pl.lit(None).cast(pl.Float64).alias("last_known_qi"))
        if "last_known_di" not in df.columns:
            df = df.with_columns(pl.lit(None).cast(pl.Float64).alias("last_known_di"))
        if "last_data_date" not in df.columns:
            df = df.with_columns(pl.lit(None).cast(pl.Date).alias("last_data_date"))
        
        # Add missing columns
        for col, default_value in defaults.items():
            if col not in df.columns:
                df = df.with_columns(pl.lit(default_value).alias(col))
        
        # Add production_start_date if missing (default to simulation start)
        if "production_start_date" not in df.columns:
            df = df.with_columns(
                pl.lit(self.model.start_date).alias("production_start_date")
            )
            if col not in df.columns:
                df = df.with_columns(pl.lit(default_value).alias(col))
        
        # Join with well type defaults for missing parameters
        if "initial_production" not in df.columns or df["initial_production"].null_count() > 0:
            df = df.join(
                self._well_defaults_df, 
                on="well_type", 
                how="left"
            )
            
            if "initial_production" not in df.columns:
                df = df.with_columns(
                    pl.col("default_initial_production").alias("initial_production")
                )
            else:
                df = df.with_columns(
                    pl.col("initial_production").fill_null(pl.col("default_initial_production"))
                )
            
            # Fill other missing parameters
            if "decline_exponent" not in df.columns:
                df = df.with_columns(
                    pl.col("default_b_factor").alias("decline_exponent")
                )
            else:
                df = df.with_columns(
                    pl.col("decline_exponent").fill_null(pl.col("default_b_factor"))
                )
            
            if "nominal_decline_rate" not in df.columns:
                df = df.with_columns(
                    pl.col("default_nominal_decline_rate").alias("nominal_decline_rate")
                )
            else:
                df = df.with_columns(
                    pl.col("nominal_decline_rate").fill_null(pl.col("default_nominal_decline_rate"))
                )
        
        # Apply configuration multiplier to initial production
        df = df.join(self._config_multipliers_df, on="configuration", how="left")
        df = df.with_columns(
            (pl.col("initial_production") * pl.col("config_productivity_multiplier").fill_null(1.0))
            .alias("initial_production")
        )
        
        # Set max capacity if not provided
        if "max_capacity" not in df.columns:
            df = df.with_columns(
                (pl.col("initial_production") * 3.0).alias("max_capacity")
            )
        else:
            df = df.with_columns(
                pl.col("max_capacity").fill_null(pl.col("initial_production") * 3.0)
            )
        
        # Ensure decline_exponent exists (use b_factor if available)
        if "decline_exponent" not in df.columns:
            if "b_factor" in df.columns:
                df = df.with_columns(
                    pl.col("b_factor").fill_null(1.0).alias("decline_exponent")
                )
            else:
                df = df.with_columns(
                    pl.lit(1.0).alias("decline_exponent")  # Default b-factor = 1.0 (hyperbolic)
                )
        
        # Calculate EUR if not provided
        if "eur" not in df.columns:
            df = df.with_columns(pl.lit(0.0).alias("eur"))
        
        df = self._calculate_eur_for_wells(df)
        
        # Clean up temporary columns
        cols_to_drop = [c for c in df.columns if c.startswith("default_") or c == "config_productivity_multiplier"]
        if cols_to_drop:
            df = df.drop(cols_to_drop)
        
        # Validate well parameters (well type, configuration, compliance)
        df = self._validate_well_parameters(df)
        
        # Validate production inputs
        df = self._validate_inputs(df)
        
        # Calculate prior cumulative production for existing wells
        df = self._calculate_prior_cumulative_production(df)
        
        return df
    
    def _assign_crude_grade(self, well_type: str) -> str:
        """Assign crude grade based on well type probability distribution.
        
        Args:
            well_type: Type of well
            
        Returns:
            Crude grade string
        """
        probs = CRUDE_GRADE_PROBABILITIES.get(
            well_type, 
            CRUDE_GRADE_PROBABILITIES[WellType.CUSTOM.value]
        )
        
        grades = list(probs.keys())
        probabilities = list(probs.values())
        
        # Use numpy for random selection
        return np.random.choice(grades, p=probabilities)
    
    def _validate_well_parameters(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Validate well type, configuration, and compliance requirements.
        
        Args:
            df: DataFrame with well parameters
            
        Returns:
            Validated DataFrame
            
        Raises:
            ValueError: If any parameter is invalid or compliance rules are violated
        """
        # Validate well types
        valid_well_types = set(WellType.values())
        invalid_types = df.filter(
            ~pl.col("well_type").is_in(valid_well_types)
        )
        if invalid_types.shape[0] > 0:
            bad_types = invalid_types["well_type"].unique().to_list()
            raise ValueError(
                f"Unsupported well_type(s): {bad_types}. "
                f"Valid types: {sorted(valid_well_types)}"
            )
        
        # Validate configurations
        valid_configs = set(WellConfiguration.values())
        if "configuration" in df.columns:
            invalid_configs = df.filter(
                ~pl.col("configuration").is_in(valid_configs)
            )
            if invalid_configs.shape[0] > 0:
                bad_configs = invalid_configs["configuration"].unique().to_list()
                raise ValueError(
                    f"Unsupported configuration(s): {bad_configs}. "
                    f"Valid types: {sorted(valid_configs)}"
                )
        
        # Validate decline types
        valid_decline_types = set(DeclineType.values())
        if "decline_type" in df.columns:
            invalid_decline = df.filter(
                ~pl.col("decline_type").is_in(valid_decline_types)
            )
            if invalid_decline.shape[0] > 0:
                bad_decline = invalid_decline["decline_type"].unique().to_list()
                raise ValueError(
                    f"Unsupported decline_type(s): {bad_decline}. "
                    f"Valid types: {sorted(valid_decline_types)}"
                )
        
        # COMPLIANCE: Offshore wells must be exclusively conventional
        if "location" in df.columns:
            offshore_non_conventional = df.filter(
                (pl.col("location").str.to_lowercase().str.contains("offshore")) &
                (~pl.col("well_type").str.to_lowercase().str.contains("conventional"))
            )
            if offshore_non_conventional.shape[0] > 0:
                bad_wells = offshore_non_conventional["unique_id"].to_list()[:5]
                raise ValueError(
                    f"Offshore wells must be exclusively conventional (Handbook compliance). "
                    f"Non-compliant wells: {bad_wells}"
                )
        
        return df
    
    def _validate_inputs(self, df: pl.DataFrame) -> pl.DataFrame:
        """Validate production parameters.
        
        Args:
            df: DataFrame with well parameters
            
        Returns:
            Validated DataFrame with corrected values
            
        Raises:
            ValueError: If critical parameters are invalid
        """
        # Validate initial production > 0
        invalid_qi = df.filter(pl.col("initial_production") <= 0)
        if invalid_qi.shape[0] > 0:
            bad_wells = invalid_qi["unique_id"].to_list()[:5]
            raise ValueError(
                f"initial_production must be > 0. Invalid wells: {bad_wells}"
            )
        
        # Validate decline_exponent >= 0
        if "decline_exponent" in df.columns:
            invalid_b = df.filter(pl.col("decline_exponent") < 0)
            if invalid_b.shape[0] > 0:
                bad_wells = invalid_b["unique_id"].to_list()[:5]
                raise ValueError(
                    f"decline_exponent must be >= 0. Invalid wells: {bad_wells}"
                )
        
        # Validate nominal_decline_rate >= 0
        if "nominal_decline_rate" in df.columns:
            invalid_d = df.filter(pl.col("nominal_decline_rate") < 0)
            if invalid_d.shape[0] > 0:
                bad_wells = invalid_d["unique_id"].to_list()[:5]
                raise ValueError(
                    f"nominal_decline_rate must be >= 0. Invalid wells: {bad_wells}"
                )
        
        # Fix max_capacity < initial_production
        if "max_capacity" in df.columns:
            df = df.with_columns([
                pl.when(pl.col("max_capacity") < pl.col("initial_production"))
                .then(pl.col("initial_production"))
                .otherwise(pl.col("max_capacity"))
                .alias("max_capacity")
            ])
        
        return df
    
    def _calculate_prior_cumulative_production(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Calculate cumulative production for days before simulation start.
        
        For wells that started producing before the simulation begins,
        this calculates how much they would have produced using the decline curve.
        
        Args:
            df: DataFrame with well parameters
            
        Returns:
            DataFrame with cumulative_production calculated for existing wells
        """
        sim_start = self.model.start_date
        
        # Calculate days before simulation
        df = df.with_columns([
            pl.when(pl.col("production_start_date") < sim_start)
            .then(
                (pl.lit(sim_start) - pl.col("production_start_date")).dt.total_days()
            )
            .otherwise(0)
            .alias("_days_before_sim")
        ])
        
        # Join with drive mechanism multipliers
        df = df.join(self._drive_multipliers_df, on="drive_mechanism", how="left")
        
        # Calculate effective decline
        df = df.with_columns([
            (pl.col("nominal_decline_rate") * pl.col("drive_decline_multiplier").fill_null(1.0))
            .alias("_effective_decline")
        ])
        
        # Calculate prior cumulative production using numerical integration approximation
        # For simplicity, use analytical formula where possible:
        # Exponential: Q(t) = qi/D * (1 - exp(-D*t))
        # Hyperbolic (b != 1): Q(t) = qi^b / ((1-b)*Di) * (qi^(1-b) - q(t)^(1-b))
        # Harmonic (b=1): Q(t) = qi/Di * ln(1 + Di*t)
        
        days_in_year = CONSTANTS.DAYS_IN_YEAR
        
        df = df.with_columns([
            pl.when(pl.col("_days_before_sim") <= 0)
            .then(0.0)
            .otherwise(
                pl.when(pl.col("decline_exponent") == 0)
                # Exponential decline: Q = qi/D * (1 - exp(-D*t))
                .then(
                    pl.col("initial_production") * days_in_year / 
                    pl.col("_effective_decline").clip(lower_bound=0.001) *
                    (1 - (-pl.col("_effective_decline") * pl.col("_days_before_sim") / days_in_year).exp())
                )
                .when(pl.col("decline_exponent") == 1)
                # Harmonic decline: Q = qi/Di * ln(1 + Di*t)
                .then(
                    pl.col("initial_production") * days_in_year /
                    pl.col("_effective_decline").clip(lower_bound=0.001) *
                    (1 + pl.col("_effective_decline") * pl.col("_days_before_sim") / days_in_year).log()
                )
                .otherwise(
                    # Hyperbolic approximation: average rate * days
                    pl.col("initial_production") * pl.col("_days_before_sim") * 0.6
                )
            )
            .alias("_prior_cumulative")
        ])
        
        # Update cumulative_production for wells that had no prior value
        df = df.with_columns([
            pl.when(
                (pl.col("cumulative_production") == 0) & 
                (pl.col("_days_before_sim") > 0)
            )
            .then(pl.col("_prior_cumulative"))
            .otherwise(pl.col("cumulative_production"))
            .alias("cumulative_production")
        ])
        
        # Clean up temporary columns
        temp_cols = ["_days_before_sim", "_effective_decline", "_prior_cumulative", "drive_decline_multiplier"]
        cols_to_drop = [c for c in temp_cols if c in df.columns]
        if cols_to_drop:
            df = df.drop(cols_to_drop)
        
        return df
    
    def is_economic_vectorized(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Check if production rate is economic (vectorized).
        
        Args:
            df: DataFrame with daily_potential_production and cumulative_production
            
        Returns:
            DataFrame with is_economic column
        """
        df = df.with_columns([
            (
                (pl.col("daily_potential_production") >= CONSTANTS.MIN_ECONOMIC_PRODUCTION) &
                (pl.col("cumulative_production") < pl.col("eur"))
            ).alias("is_economic")
        ])
        return df
    
    def _compute_fallback_decline_rate(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Compute production rate using decline curve when historical data is missing.
        
        This is used for wells that have historical production data but the current
        simulation date is beyond the last available data date. Uses last_known_qi 
        and last_known_di from dim data as the starting point for decline curve projection.
        
        Args:
            df: DataFrame with well parameters including last_known_qi, last_known_di, last_data_date
            
        Returns:
            DataFrame with fallback_production column
        """
        current_date = self.model.current_date
        
        # Check if we have the required columns
        has_fallback_cols = all(c in df.columns for c in ["last_known_qi", "last_known_di", "last_data_date"])
        
        if not has_fallback_cols:
            # No fallback data available, return zeros
            df = df.with_columns([pl.lit(0.0).alias("fallback_production")])
            return df
        
        # Get fallback defaults
        fallback_defaults = get_well_type_defaults(WellType.CONVENTIONAL_ONSHORE.value)
        fallback_qi_default = fallback_defaults["initial_production"]
        fallback_di_default = fallback_defaults["nominal_decline_rate"]
        
        # Calculate days since last data date
        df = df.with_columns([
            pl.when(pl.col("last_data_date").is_not_null())
            .then(
                (pl.lit(current_date) - pl.col("last_data_date")).dt.total_days()
            )
            .otherwise(pl.col("days_on_production"))
            .alias("_days_since_last_data")
        ])
        
        # Use last_known values or fallback
        df = df.with_columns([
            pl.when(pl.col("last_known_qi").is_not_null() & (pl.col("last_known_qi") > 0))
            .then(pl.col("last_known_qi"))
            .otherwise(fallback_qi_default)
            .alias("_fallback_qi"),
            
            # last_known_di is per month, convert to annual (multiply by 12)
            pl.when(pl.col("last_known_di").is_not_null() & (pl.col("last_known_di") > 0))
            .then(pl.col("last_known_di") * 12)
            .otherwise(fallback_di_default)
            .alias("_fallback_di")
        ])
        
        # Calculate t_years from last data date
        df = df.with_columns([
            (pl.col("_days_since_last_data") / CONSTANTS.DAYS_IN_YEAR).alias("_t_years_fallback")
        ])
        
        # Calculate fallback production
        df = df.with_columns([
            pl.when(pl.col("_days_since_last_data") < 0)
            # Current date before last data date - return last known qi
            .then(pl.col("_fallback_qi"))
            .otherwise(
                pl.when(pl.col("decline_exponent") == 0)
                # Exponential decline
                .then(
                    pl.col("_fallback_qi") * 
                    (-pl.col("_fallback_di") * pl.col("_t_years_fallback")).exp()
                )
                # Hyperbolic/Harmonic decline
                .otherwise(
                    pl.col("_fallback_qi") /
                    (
                        (1 + pl.col("decline_exponent") * pl.col("_fallback_di") * pl.col("_t_years_fallback"))
                        .pow(1.0 / pl.col("decline_exponent").clip(lower_bound=0.001))
                    )
                )
            )
            .clip(lower_bound=0.0)
            .alias("fallback_production")
        ])
        
        # Clean up temporary columns
        temp_cols = ["_days_since_last_data", "_fallback_qi", "_fallback_di", "_t_years_fallback"]
        cols_to_drop = [c for c in temp_cols if c in df.columns]
        if cols_to_drop:
            df = df.drop(cols_to_drop)
        
        return df
    
    def _calculate_eur_for_wells(
        self, 
        df: pl.DataFrame,
        horizon_years: int = CONSTANTS.DEFAULT_EUR_HORIZON_YEARS
    ) -> pl.DataFrame:
        """Calculate EUR for wells using vectorized operations.
        
        Args:
            df: DataFrame with well parameters
            horizon_years: Years for EUR projection
            
        Returns:
            DataFrame with EUR column updated
        """
        # For wells with EUR already set and > 0, keep existing values
        # For others, calculate from decline curve
        
        # Join with drive mechanism multipliers
        df = df.join(self._drive_multipliers_df, on="drive_mechanism", how="left")
        
        # Calculate effective decline rate
        df = df.with_columns(
            (pl.col("nominal_decline_rate") * pl.col("drive_decline_multiplier").fill_null(1.0))
            .alias("effective_decline")
        )
        
        days_in_year = CONSTANTS.DAYS_IN_YEAR
        max_days = int(horizon_years * days_in_year)
        
        # Simplified EUR calculation:
        # For exponential (b=0): EUR ≈ qi / D * days_in_year
        # For hyperbolic (b>0): EUR ≈ qi * adjustment_factor / effective_decline
        
        df = df.with_columns(
            pl.when(pl.col("eur") > 0)
            .then(pl.col("eur"))
            .otherwise(
                pl.when(pl.col("decline_exponent") == 0)
                .then(
                    pl.col("initial_production") * days_in_year / 
                    pl.col("effective_decline").clip(lower_bound=0.001)
                )
                .otherwise(
                    # Hyperbolic approximation
                    pl.col("initial_production") * max_days * 
                    pl.when(pl.col("decline_exponent") <= 0.5).then(1.0)
                    .when(pl.col("decline_exponent") <= 1.0).then(1.5)
                    .otherwise(2.0) / 
                    (1 + pl.col("effective_decline") * horizon_years)
                )
            )
            .alias("eur")
        )
        
        # Clean up temporary columns
        if "drive_decline_multiplier" in df.columns:
            df = df.drop("drive_decline_multiplier")
        if "effective_decline" in df.columns:
            df = df.drop("effective_decline")
        
        return df
    
    def step(self) -> pl.DataFrame:
        """Execute one simulation step for all wells.
        
        This is the main vectorized production calculation method.
        It updates all wells in a single DataFrame operation.
        
        IMPORTANT: Uses actual production from CSV when available.
        Simulation is only used for future periods (when no actuals exist).
        
        Returns:
            DataFrame with updated well states
        """
        if self.agents.is_empty():
            return self.agents
        
        current_date = self.model.current_date
        current_date_str = current_date.strftime("%Y-%m-%d")
        
        # Get the agents DataFrame
        df = self.agents
        
        # Check if actual production data exists for current date
        # Look up actual production from model's actual_production_data dict
        # Keys in actual_production_dict are integer API numbers
        actual_production_dict = getattr(self.model, 'actual_production_data', {})
        
        # Create a column for actual production today
        # The actual_production_dict is keyed by integer api_number, not well_name
        if actual_production_dict and "api_number" in df.columns:
            # Get list of API numbers that have actual production data
            api_keys = set(actual_production_dict.keys())
            
            df = df.with_columns([
                pl.when(
                    pl.col("api_number").is_not_null() &
                    pl.col("api_number").is_in(list(api_keys))
                )
                .then(
                    pl.col("api_number").map_elements(
                        lambda api: float(actual_production_dict.get(api, {}).get(current_date_str, 0)) 
                                    if api in actual_production_dict and current_date_str in actual_production_dict.get(api, {}) 
                                    else None,
                        return_dtype=pl.Float64
                    )
                )
                .otherwise(None)
                .alias("_actual_production_today")
            ])
        else:
            # No actual production data available
            df = df.with_columns([
                pl.lit(None).cast(pl.Float64).alias("_actual_production_today")
            ])
        
        # Mark wells that used actual production
        df = df.with_columns([
            pl.col("_actual_production_today").is_not_null().alias("_used_actual_production")
        ])
        
        # Join with drive mechanism multipliers for decline calculation
        df = df.join(self._drive_multipliers_df, on="drive_mechanism", how="left")
        
        # Calculate time in years
        df = df.with_columns([
            # Days on production calculation
            pl.when(pl.col("production_start_date") <= current_date)
            .then(
                (pl.lit(current_date) - pl.col("production_start_date")).dt.total_days() + 1
            )
            .otherwise(0)
            .alias("days_on_production"),
        ])
        
        # Calculate t_years and effective decline
        df = df.with_columns([
            (pl.col("days_on_production") / CONSTANTS.DAYS_IN_YEAR).alias("t_years"),
            (pl.col("nominal_decline_rate") * pl.col("drive_decline_multiplier").fill_null(1.0))
            .alias("effective_decline"),
        ])
        
        # Calculate simulated production using vectorized decline curve
        # This is ONLY used for wells without actual production data (future periods)
        df = df.with_columns([
            pl.when(pl.col("decline_exponent") == 0)
            # Exponential decline: q(t) = qi * exp(-D * t)
            .then(
                pl.col("initial_production") * 
                (-pl.col("effective_decline") * pl.col("t_years")).exp()
            )
            # Hyperbolic/Harmonic decline: q(t) = qi / (1 + b*D*t)^(1/b)
            .otherwise(
                pl.col("initial_production") / 
                (
                    (1 + pl.col("decline_exponent") * pl.col("effective_decline") * pl.col("t_years"))
                    .pow(1.0 / pl.col("decline_exponent").clip(lower_bound=0.001))
                )
            )
            .alias("_simulated_production")
        ])
        
        # Use actual production if available, otherwise use simulated production
        df = df.with_columns([
            pl.when(pl.col("_used_actual_production"))
            .then(pl.col("_actual_production_today"))
            .otherwise(pl.col("_simulated_production"))
            .alias("daily_potential_production")
        ])
        
        # Apply fallback decline rate for wells with historical data
        # (wells where last_data_date exists and current date is past it)
        has_fallback_cols = all(c in df.columns for c in ["last_known_qi", "last_data_date"])
        if has_fallback_cols:
            df = self._compute_fallback_decline_rate(df)
            
            # Use fallback production when appropriate
            df = df.with_columns([
                pl.when(
                    (pl.col("last_data_date").is_not_null()) &
                    (current_date > pl.col("last_data_date")) &
                    (~pl.col("is_new"))
                )
                .then(pl.col("fallback_production"))
                .otherwise(pl.col("daily_potential_production"))
                .alias("daily_potential_production")
            ])
            
            # Clean up fallback column
            if "fallback_production" in df.columns:
                df = df.drop("fallback_production")
        
        # Apply ECR uplift on first day
        df = df.with_columns([
            pl.when(
                (pl.col("ecr_enabled")) & 
                (pl.col("days_on_production") == 1)
            )
            .then(pl.col("daily_potential_production") * CONSTANTS.ECR_UPLIFT_FACTOR)
            .otherwise(pl.col("daily_potential_production"))
            .alias("daily_potential_production")
        ])
        
        # Determine if well is active
        df = df.with_columns([
            pl.when(
                (pl.col("production_start_date") <= current_date) &
                (pl.col("status") == WellStatus.ACTIVE.value) &
                (pl.col("daily_potential_production") >= CONSTANTS.MIN_ECONOMIC_PRODUCTION) &
                (pl.col("cumulative_production") < pl.col("eur"))
            )
            .then(True)
            .otherwise(False)
            .alias("is_active")
        ])
        
        # Choked wells are also active (but at reduced rate)
        df = df.with_columns([
            pl.when(pl.col("status") == WellStatus.CHOKED.value)
            .then(True)
            .otherwise(pl.col("is_active"))
            .alias("is_active")
        ])
        
        # Check production end date
        df = df.with_columns([
            pl.when(
                (pl.col("production_end_date").is_not_null()) &
                (pl.col("production_end_date") <= current_date)
            )
            .then(False)
            .otherwise(pl.col("is_active"))
            .alias("is_active")
        ])
        
        # Handle choked wells - 50% production
        df = df.with_columns([
            pl.when(pl.col("status") == WellStatus.CHOKED.value)
            .then(pl.col("daily_potential_production") * 0.5)
            .otherwise(pl.col("daily_potential_production"))
            .alias("daily_potential_production")
        ])
        
        # Set potential production to 0 for inactive wells
        df = df.with_columns([
            pl.when(~pl.col("is_active"))
            .then(0.0)
            .otherwise(pl.col("daily_potential_production"))
            .alias("daily_potential_production")
        ])
        
        # Cap at max capacity
        df = df.with_columns([
            pl.col("daily_potential_production")
            .clip(upper_bound=pl.col("max_capacity"))
            .alias("daily_potential_production")
        ])
        
        # Reset daily_production (will be set by model after allocation)
        df = df.with_columns([
            pl.lit(0.0).alias("daily_production")
        ])
        
        # Calculate production cost
        df = df.join(self._config_multipliers_df, on="configuration", how="left")
        df = df.with_columns([
            (
                CONSTANTS.BASE_OPEX_PER_DAY * 
                pl.col("config_productivity_multiplier").fill_null(1.0) +
                CONSTANTS.VARIABLE_OPEX_FACTOR * pl.col("daily_potential_production")
            ).alias("production_cost")
        ])
        
        # Clean up temporary columns
        temp_cols = [
            "t_years", "effective_decline", "drive_decline_multiplier",
            "config_productivity_multiplier"
        ]
        cols_to_drop = [c for c in temp_cols if c in df.columns]
        if cols_to_drop:
            df = df.drop(cols_to_drop)
        
        # Update agents DataFrame
        self._agents = df
        
        return self.agents
    
    def update_production(self, production_by_well: Dict[str, float]) -> None:
        """Update realized production for wells.
        
        Called by the model after reserve allocation.
        
        Args:
            production_by_well: Dict mapping well_id to realized production (bbl)
        """
        if not production_by_well:
            return
        
        # Create update DataFrame
        updates = pl.DataFrame({
            "unique_id": list(production_by_well.keys()),
            "realized_production": list(production_by_well.values())
        })
        
        # Join and update
        df = self.agents.join(updates, on="unique_id", how="left")
        
        df = df.with_columns([
            pl.col("realized_production").fill_null(0.0).alias("daily_production"),
            (pl.col("cumulative_production") + pl.col("realized_production").fill_null(0.0))
            .alias("cumulative_production")
        ])
        
        if "realized_production" in df.columns:
            df = df.drop("realized_production")
        
        self._agents = df
    
    def update_production_vectorized(self, realized_production: pl.Series) -> None:
        """Update realized production using vectorized operation.
        
        This is more efficient than update_production when production values
        are already in order matching the agents DataFrame.
        
        Args:
            realized_production: Series of realized production values
        """
        df = self.agents
        
        df = df.with_columns([
            realized_production.alias("daily_production"),
            (pl.col("cumulative_production") + realized_production).alias("cumulative_production")
        ])
        
        self._agents = df
    
    def get_total_potential_production(self) -> float:
        """Get total potential production for all active wells.
        
        Returns:
            Total potential production in bbl/day
        """
        return self.agents.filter(
            pl.col("is_active")
        )["daily_potential_production"].sum()
    
    def get_production_by_grade(self) -> Dict[str, float]:
        """Get total production grouped by crude grade.
        
        Returns:
            Dict mapping grade to total production
        """
        if self.agents.is_empty():
            return {}
        
        grouped = self.agents.filter(
            pl.col("is_active")
        ).group_by("crude_grade").agg(
            pl.col("daily_potential_production").sum().alias("total_production")
        )
        
        return dict(
            zip(
                grouped["crude_grade"].to_list(),
                grouped["total_production"].to_list()
            )
        )
    
    def get_active_wells_count(self) -> int:
        """Get count of active wells.
        
        Returns:
            Number of active wells
        """
        if self.agents.is_empty():
            return 0
        if "is_active" not in self.agents.columns:
            return 0
        return self.agents.filter(pl.col("is_active")).shape[0]
    
    def get_wells_summary(self) -> Dict[str, Any]:
        """Get summary statistics for all wells.
        
        Returns:
            Dictionary with summary statistics
        """
        df = self.agents
        
        if df.is_empty():
            return {
                "total_wells": 0,
                "active_wells": 0,
                "total_potential_production": 0.0,
                "total_cumulative_production": 0.0,
                "by_well_type": {},
                "by_crude_grade": {},
            }
        
        active_df = df.filter(pl.col("is_active"))
        
        # Group by well type
        by_type = df.group_by("well_type").agg([
            pl.count().alias("count"),
            pl.col("daily_potential_production").sum().alias("production"),
        ])
        
        # Group by crude grade
        by_grade = active_df.group_by("crude_grade").agg([
            pl.count().alias("count"),
            pl.col("daily_potential_production").sum().alias("production"),
        ])
        
        return {
            "total_wells": df.shape[0],
            "active_wells": active_df.shape[0],
            "total_potential_production": active_df["daily_potential_production"].sum(),
            "total_cumulative_production": df["cumulative_production"].sum(),
            "by_well_type": dict(zip(by_type["well_type"].to_list(), by_type["count"].to_list())),
            "by_crude_grade": dict(zip(by_grade["crude_grade"].to_list(), by_grade["production"].to_list())),
        }
    
    def set_well_status(
        self, 
        well_ids: List[int], 
        status: str
    ) -> None:
        """Set status for specific wells.
        
        Args:
            well_ids: List of well IDs (integers) to update
            status: New status (Active, Choked, Inactive)
        """
        if status not in WellStatus.values():
            raise ValueError(f"Invalid status: {status}")
        
        df = self.agents
        
        df = df.with_columns([
            pl.when(pl.col("unique_id").is_in(well_ids))
            .then(pl.lit(status))
            .otherwise(pl.col("status"))
            .alias("status"),
            
            pl.when(pl.col("unique_id").is_in(well_ids))
            .then(status == WellStatus.ACTIVE.value)
            .otherwise(pl.col("is_active"))
            .alias("is_active")
        ])
        
        self._agents = df
    
    def set_well_production_capacity(
        self,
        well_ids: List[int],
        new_capacity: float,
        recalc_eur: bool = True
    ) -> None:
        """
        Update well production capacity for specific wells.
        
        Args:
            well_ids: List of well IDs (integers) to update
            new_capacity: New maximum capacity in bbl/day
            recalc_eur: Whether to recalculate EUR
            
        Raises:
            ValueError: If capacity is negative
        """
        if new_capacity < 0:
            raise ValueError("Production capacity must be non-negative")
        
        df = self.agents
        
        # Update max_capacity for specified wells
        df = df.with_columns([
            pl.when(pl.col("unique_id").is_in(well_ids))
            .then(pl.lit(new_capacity))
            .otherwise(pl.col("max_capacity"))
            .alias("max_capacity")
        ])
        
        # Recalculate EUR if requested
        if recalc_eur:
            # Only recalculate for affected wells
            affected_df = df.filter(pl.col("unique_id").is_in(well_ids))
            affected_df = self._calculate_eur_for_wells(affected_df)
            
            # Merge back
            not_affected = df.filter(~pl.col("unique_id").is_in(well_ids))
            df = pl.concat([not_affected, affected_df])
        
        self._agents = df
        
        logger.debug(
            "Updated production capacity for %d wells to %.0f bbl/day",
            len(well_ids), new_capacity
        )
    
    def get_wells_by_type(self, well_type: str) -> pl.DataFrame:
        """Get all wells of a specific type.
        
        Args:
            well_type: Well type to filter
            
        Returns:
            Filtered DataFrame
        """
        return self.agents.filter(pl.col("well_type") == well_type)
    
    def get_wells_by_grade(self, crude_grade: str) -> pl.DataFrame:
        """Get all wells producing a specific crude grade.
        
        Args:
            crude_grade: Crude grade to filter
            
        Returns:
            Filtered DataFrame
        """
        return self.agents.filter(pl.col("crude_grade") == crude_grade)
    
    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Convert agents to list of dictionaries.
        
        Returns:
            List of well state dictionaries
        """
        return self.agents.to_dicts()
