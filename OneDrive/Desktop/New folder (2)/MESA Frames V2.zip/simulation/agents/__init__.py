"""
Simulation Agents Package for Mesa-Frames SimOxy Simulation.

This package contains vectorized agent classes for the oil & gas simulation:

- WellAgentSet: Vectorized well production agents
- PipelineAgentSet: Vectorized pipeline transportation agents
- RefineryAgentSet: Vectorized refinery processing agents

All agent sets use Polars DataFrames for efficient vectorized operations.
"""

from .well_agent import WellAgentSet
from .pipeline_agent import PipelineAgentSet, PipelineAgent
from .refinery_agent import RefineryAgentSet

__all__ = [
    "WellAgentSet",
    "PipelineAgentSet",
    "PipelineAgent",
    "RefineryAgentSet",
]
