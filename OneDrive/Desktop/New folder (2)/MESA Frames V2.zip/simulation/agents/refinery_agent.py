"""
RefineryAgentSet - Vectorized Refinery Agents for Mesa-Frames SimOxy Simulation.

This module implements a vectorized refinery agent set using mesa-frames AgentSetPolars.
Processes crude oil production into refined products based on refinery configuration.

OPTIMIZATION:
- Vectorized yield calculations
- Efficient grade-to-product mapping
- Batch processing of multiple refineries

COMPLIANCE:
- Implements refinery yield calculations for:
  - Simple Distillation: Direct cut percentages
  - Hydroskimming: Distillation + hydrotreating conversion
  - Coking/Cracking: Heavy fuel oil conversion and redistribution
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Optional, Dict, Any, List, TYPE_CHECKING

import polars as pl
from mesa_frames import AgentSetPolars

from config.simulation_config import (
    RefineryConfiguration,
    RefineryProduct,
    REFINERY_PRODUCTS,
    CRACK_PRODUCTS,
    LIGHT_PRODUCTS,
    DEFAULT_REFINERY_YIELDS,
    CRUDE_GRADE_TO_REFINERY_GRADE,
    get_default_refinery_yields_polars,
)
from utils.logging_config import get_logger

if TYPE_CHECKING:
    from simulation.model import BasinModel

logger = get_logger(__name__)


class RefineryAgentSet(AgentSetPolars):
    """
    Vectorized Refinery Agent Set using mesa-frames.
    
    Refineries process crude oil into refined products based on configuration
    and crude grade. All refineries are stored in a single DataFrame.
    
    DataFrame Columns:
        - unique_id: Unique refinery identifier
        - refinery_name: Full refinery name
        - basin: Basin location
        - market_center: Market center location
        - configuration: Refinery type (Simple Distillation, Hydroskimming, etc.)
        - effective_capacity: Maximum processing capacity (bbl/month)
        - weight: Historical run volume weight for allocation
        - runs_vol: Current tick's crude input volume
        - total_runs_processed: Cumulative crude processed
        - is_active: Whether refinery is active
    """
    
    def __init__(self, model: "BasinModel"):
        """Initialize the RefineryAgentSet.
        
        Args:
            model: Parent BasinModel instance
        """
        super().__init__(model)
        
        # Preload default yields for vectorized operations
        self._default_yields_df = get_default_refinery_yields_polars()
        
        # Mapping DataFrame for grade-specific yields (loaded separately)
        self._mapping_df: Optional[pl.DataFrame] = None
        
        logger.info("RefineryAgentSet initialized")
    
    def set_mapping_data(self, mapping_df: pl.DataFrame) -> None:
        """Set the crude-to-product conversion mapping data.
        
        Args:
            mapping_df: DataFrame with yield conversion mapping
        """
        self._mapping_df = mapping_df
        logger.info("Loaded refinery mapping data: %d rows", mapping_df.shape[0])
    
    def add_refinery(
        self,
        unique_id: str,
        refinery_name: str,
        basin: str,
        configuration: str,
        effective_capacity: float,
        weight: float = 1.0,
        market_center: str = "Market",
        **kwargs
    ) -> None:
        """Add a single refinery to the agent set.
        
        Args:
            unique_id: Unique refinery identifier
            refinery_name: Full refinery name
            basin: Basin location
            configuration: Refinery processing configuration
            effective_capacity: Maximum capacity (bbl/month)
            weight: Weight for proportional allocation
            market_center: Market center location
            **kwargs: Additional refinery attributes
        """
        refinery_data = {
            "unique_id": [unique_id],
            "refinery_name": [refinery_name],
            "basin": [basin],
            "market_center": [market_center],
            "configuration": [configuration],
            "effective_capacity": [float(effective_capacity)],
            "weight": [float(weight)],
            "runs_vol": [0.0],
            "total_runs_processed": [0.0],
            "is_active": [True],
            "status": ["Active"],
        }
        
        # Add product yield columns (initialized to 0)
        for product in REFINERY_PRODUCTS:
            refinery_data[f"yield_{product.replace('/', '_')}"] = [0.0]
            refinery_data[f"total_yield_{product.replace('/', '_')}"] = [0.0]
        
        refinery_df = pl.DataFrame(refinery_data)
        self.add(refinery_df)
        
        logger.debug(
            "Added refinery: id=%s, name=%s, config=%s, capacity=%.0f",
            unique_id, refinery_name, configuration, effective_capacity
        )
    
    def add_refineries(self, refineries_df: pl.DataFrame) -> None:
        """Add multiple refineries from a DataFrame.
        
        Args:
            refineries_df: DataFrame with refinery configurations
        """
        if refineries_df.is_empty():
            logger.warning("Empty DataFrame passed to add_refineries")
            return
        
        # Ensure required columns exist
        refineries_df = self._prepare_refineries_dataframe(refineries_df)
        self.add(refineries_df)
        
        logger.info("Added %d refineries to RefineryAgentSet", refineries_df.shape[0])
    
    def _prepare_refineries_dataframe(self, df: pl.DataFrame) -> pl.DataFrame:
        """Prepare and validate refineries DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Prepared DataFrame with all required columns
        """
        defaults = {
            "refinery_name": "Refinery",
            "basin": "Basin",
            "market_center": "Market",
            "configuration": RefineryConfiguration.SIMPLE_DISTILLATION.value,
            "effective_capacity": 100000.0,
            "weight": 1.0,
            "runs_vol": 0.0,
            "total_runs_processed": 0.0,
            "is_active": True,
            "status": "Active",
        }
        
        for col, default_value in defaults.items():
            if col not in df.columns:
                df = df.with_columns(pl.lit(default_value).alias(col))
        
        # Add product yield columns
        for product in REFINERY_PRODUCTS:
            yield_col = f"yield_{product.replace('/', '_')}"
            total_yield_col = f"total_yield_{product.replace('/', '_')}"
            
            if yield_col not in df.columns:
                df = df.with_columns(pl.lit(0.0).alias(yield_col))
            if total_yield_col not in df.columns:
                df = df.with_columns(pl.lit(0.0).alias(total_yield_col))
        
        return df
    
    def step(self) -> pl.DataFrame:
        """Execute one simulation step for all refineries.
        
        Resets per-tick counters.
        
        Returns:
            DataFrame with reset refinery states
        """
        if self.agents.is_empty():
            return self.agents
        
        # Reset per-tick values
        reset_cols = [
            pl.lit(0.0).alias("runs_vol"),
        ]
        
        # Reset yield columns
        for product in REFINERY_PRODUCTS:
            yield_col = f"yield_{product.replace('/', '_')}"
            reset_cols.append(pl.lit(0.0).alias(yield_col))
        
        df = self.agents.with_columns(reset_cols)
        self._agents = df
        
        return self.agents
    
    def allocate_crude(
        self,
        crude_volumes_by_grade: Dict[str, float],
        year: int,
        month: int
    ) -> Dict[str, Dict[str, float]]:
        """Allocate crude oil to refineries and calculate product yields.
        
        Distributes crude proportionally based on refinery weights.
        
        Args:
            crude_volumes_by_grade: Dict mapping crude grade to volume (bbl)
            year: Processing year
            month: Processing month
            
        Returns:
            Dict mapping refinery_id to product yields
        """
        if self.agents.is_empty() or not crude_volumes_by_grade:
            return {}
        
        df = self.agents
        
        # Calculate total weight for active refineries
        active_df = df.filter(pl.col("is_active"))
        if active_df.is_empty():
            logger.warning("No active refineries for allocation")
            return {}
        
        total_weight = active_df["weight"].sum()
        if total_weight <= 0:
            total_weight = active_df.shape[0]  # Equal allocation
        
        # Calculate allocation fraction for each refinery
        df = df.with_columns([
            pl.when(pl.col("is_active"))
            .then(pl.col("weight") / total_weight)
            .otherwise(0.0)
            .alias("allocation_fraction")
        ])
        
        # Process each crude grade
        results = {}
        
        for grade, volume in crude_volumes_by_grade.items():
            if volume <= 0:
                continue
            
            # Allocate crude to refineries
            df = df.with_columns([
                (pl.col("runs_vol") + volume * pl.col("allocation_fraction"))
                .alias("runs_vol")
            ])
        
        # Calculate yields for all refineries
        df = self._calculate_yields_vectorized(df)
        
        # Update totals
        df = df.with_columns([
            (pl.col("total_runs_processed") + pl.col("runs_vol"))
            .alias("total_runs_processed")
        ])
        
        # Update total yields
        for product in REFINERY_PRODUCTS:
            yield_col = f"yield_{product.replace('/', '_')}"
            total_yield_col = f"total_yield_{product.replace('/', '_')}"
            df = df.with_columns([
                (pl.col(total_yield_col) + pl.col(yield_col))
                .alias(total_yield_col)
            ])
        
        # Clean up temporary columns
        if "allocation_fraction" in df.columns:
            df = df.drop("allocation_fraction")
        
        self._agents = df
        
        # Build results dictionary
        for row in df.filter(pl.col("is_active")).iter_rows(named=True):
            refinery_id = row["unique_id"]
            results[refinery_id] = {
                "runs_vol": row["runs_vol"],
            }
            for product in REFINERY_PRODUCTS:
                yield_col = f"yield_{product.replace('/', '_')}"
                results[refinery_id][product] = row[yield_col]
        
        return results
    
    def _calculate_yields_vectorized(self, df: pl.DataFrame) -> pl.DataFrame:
        """Calculate product yields using vectorized operations.
        
        Args:
            df: DataFrame with refinery data
            
        Returns:
            DataFrame with calculated yields
        """
        # Join with default yields
        yields_df = self._default_yields_df.pivot(
            index="configuration",
            on="product",
            values="yield_fraction"
        )
        
        # Rename pivoted columns
        for product in REFINERY_PRODUCTS:
            if product in yields_df.columns:
                yields_df = yields_df.rename({
                    product: f"default_yield_{product.replace('/', '_')}"
                })
        
        df = df.join(yields_df, on="configuration", how="left")
        
        # Calculate yields as runs_vol * yield_fraction
        for product in REFINERY_PRODUCTS:
            yield_col = f"yield_{product.replace('/', '_')}"
            default_yield_col = f"default_yield_{product.replace('/', '_')}"
            
            if default_yield_col in df.columns:
                df = df.with_columns([
                    (pl.col("runs_vol") * pl.col(default_yield_col).fill_null(0.0))
                    .alias(yield_col)
                ])
                df = df.drop(default_yield_col)
            else:
                df = df.with_columns([
                    pl.lit(0.0).alias(yield_col)
                ])
        
        return df
    
    def get_total_capacity(self) -> float:
        """Get total effective capacity of all active refineries.
        
        Returns:
            Total capacity in bbl/month
        """
        return self.agents.filter(
            pl.col("is_active")
        )["effective_capacity"].sum()
    
    def get_total_runs(self) -> float:
        """Get total crude runs for current period.
        
        Returns:
            Total runs volume in bbl
        """
        return self.agents["runs_vol"].sum()
    
    def get_total_yields(self) -> Dict[str, float]:
        """Get total product yields for current period.
        
        Returns:
            Dict mapping product to total yield (bbl)
        """
        df = self.agents
        
        yields = {}
        for product in REFINERY_PRODUCTS:
            yield_col = f"yield_{product.replace('/', '_')}"
            if yield_col in df.columns:
                yields[product] = df[yield_col].sum()
            else:
                yields[product] = 0.0
        
        return yields
    
    def get_cumulative_yields(self) -> Dict[str, float]:
        """Get cumulative product yields.
        
        Returns:
            Dict mapping product to cumulative yield (bbl)
        """
        df = self.agents
        
        yields = {}
        for product in REFINERY_PRODUCTS:
            total_yield_col = f"total_yield_{product.replace('/', '_')}"
            if total_yield_col in df.columns:
                yields[product] = df[total_yield_col].sum()
            else:
                yields[product] = 0.0
        
        return yields
    
    def get_refinery_summary(self) -> Dict[str, Any]:
        """Get summary statistics for all refineries.
        
        Returns:
            Dictionary with summary statistics
        """
        df = self.agents
        
        if df.is_empty():
            return {
                "total_refineries": 0,
                "active_refineries": 0,
                "total_capacity": 0.0,
                "total_runs": 0.0,
                "total_yields": {},
                "by_configuration": {},
            }
        
        active = df.filter(pl.col("is_active"))
        
        # Group by configuration
        by_config = active.group_by("configuration").agg([
            pl.count().alias("count"),
            pl.col("effective_capacity").sum().alias("capacity"),
            pl.col("runs_vol").sum().alias("runs"),
        ])
        
        return {
            "total_refineries": df.shape[0],
            "active_refineries": active.shape[0],
            "total_capacity": active["effective_capacity"].sum(),
            "total_runs": df["runs_vol"].sum(),
            "total_cumulative_runs": df["total_runs_processed"].sum(),
            "total_yields": self.get_total_yields(),
            "by_configuration": dict(
                zip(by_config["configuration"].to_list(), by_config["count"].to_list())
            ),
        }
    
    def set_refinery_status(
        self, 
        refinery_ids: List[str], 
        is_active: bool
    ) -> None:
        """Set active status for specific refineries.
        
        Args:
            refinery_ids: List of refinery IDs to update
            is_active: New active status
        """
        df = self.agents
        
        df = df.with_columns([
            pl.when(pl.col("unique_id").is_in(refinery_ids))
            .then(pl.lit(is_active))
            .otherwise(pl.col("is_active"))
            .alias("is_active"),
            
            pl.when(pl.col("unique_id").is_in(refinery_ids))
            .then(pl.lit("Active" if is_active else "Inactive"))
            .otherwise(pl.col("status"))
            .alias("status")
        ])
        
        self._agents = df
    
    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Convert agents to list of dictionaries.
        
        Returns:
            List of refinery state dictionaries
        """
        return self.agents.to_dicts()
