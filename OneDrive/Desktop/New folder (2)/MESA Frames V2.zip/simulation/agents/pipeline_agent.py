"""
PipelineAgentSet - Vectorized Pipeline Agents for Mesa-Frames SimOxy Simulation.

This module implements a vectorized pipeline agent set using mesa-frames AgentSetPolars.
Handles transportation of crude oil and refined products from production to export.

OPTIMIZATION:
- Uses Polars expressions for vectorized calculations
- Supports multiple pipelines with capacity tracking
- Efficient flow allocation across pipelines
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional, Dict, Any, List, TYPE_CHECKING

import polars as pl
from mesa_frames import AgentSetPolars

from config.simulation_config import CONSTANTS
from utils.logging_config import get_logger

if TYPE_CHECKING:
    from simulation.model import BasinModel

logger = get_logger(__name__)


class PipelineAgentSet(AgentSetPolars):
    """
    Vectorized Pipeline Agent Set using mesa-frames.
    
    Pipelines transport crude oil from wells/refineries to market centers.
    All pipelines are stored in a single DataFrame for vectorized operations.
    
    DataFrame Columns:
        - unique_id: Unique pipeline identifier
        - pipeline_name: Pipeline name
        - market_center: Market center served
        - basin: Basin location
        - max_capacity: Maximum daily capacity (bbl/day)
        - daily_transport: Current day's transported volume (bbl)
        - cumulative_transport: Total transported volume (bbl)
        - utilization_pct: Current utilization percentage
        - is_operational: Whether pipeline is operational
        - is_active: Whether pipeline is currently active
        - stranded_throughput: Volume that couldn't be transported (bbl)
    """
    
    def __init__(self, model: "BasinModel"):
        """Initialize the PipelineAgentSet.
        
        Args:
            model: Parent BasinModel instance
        """
        super().__init__(model)
        logger.info("PipelineAgentSet initialized")
    
    def add_pipeline(
        self,
        unique_id: str,
        pipeline_name: str = "Pipeline",
        market_center: str = "Market",
        basin: str = "Basin",
        capacity_bpd: float = 0.0,
        **kwargs
    ) -> None:
        """Add a single pipeline to the agent set.
        
        Args:
            unique_id: Unique pipeline identifier
            pipeline_name: Pipeline name
            market_center: Market center location
            basin: Basin location
            capacity_bpd: Capacity in barrels per day
            **kwargs: Additional pipeline attributes
        """
        # Impute default capacity if zero/null
        if capacity_bpd <= 0:
            capacity_bpd = CONSTANTS.DEFAULT_PIPELINE_CAPACITY
        
        pipeline_data = {
            "unique_id": [unique_id],
            "pipeline_name": [pipeline_name],
            "market_center": [market_center],
            "basin": [basin],
            "max_capacity": [float(capacity_bpd)],
            "daily_transport": [0.0],
            "cumulative_transport": [0.0],
            "utilization_pct": [0.0],
            "is_operational": [True],
            "is_active": [True],
            "stranded_throughput": [0.0],
        }
        
        pipeline_df = pl.DataFrame(pipeline_data)
        self.add(pipeline_df)
        
        logger.debug(
            "Added pipeline: id=%s, name=%s, capacity=%.0f bbl/day",
            unique_id, pipeline_name, capacity_bpd
        )
    
    def add_pipelines(self, pipelines_df: pl.DataFrame) -> None:
        """Add multiple pipelines from a DataFrame.
        
        Args:
            pipelines_df: DataFrame with pipeline configurations
        """
        if pipelines_df.is_empty():
            logger.warning("Empty DataFrame passed to add_pipelines")
            return
        
        # Ensure required columns exist
        pipelines_df = self._prepare_pipelines_dataframe(pipelines_df)
        self.add(pipelines_df)
        
        logger.info("Added %d pipelines to PipelineAgentSet", pipelines_df.shape[0])
    
    def _prepare_pipelines_dataframe(self, df: pl.DataFrame) -> pl.DataFrame:
        """Prepare and validate pipelines DataFrame.
        
        Args:
            df: Input DataFrame
            
        Returns:
            Prepared DataFrame with all required columns
        """
        defaults = {
            "pipeline_name": "Pipeline",
            "market_center": "Market",
            "basin": "Basin",
            "max_capacity": CONSTANTS.DEFAULT_PIPELINE_CAPACITY,
            "daily_transport": 0.0,
            "cumulative_transport": 0.0,
            "utilization_pct": 0.0,
            "is_operational": True,
            "is_active": True,
            "stranded_throughput": 0.0,
        }
        
        for col, default_value in defaults.items():
            if col not in df.columns:
                df = df.with_columns(pl.lit(default_value).alias(col))
        
        # Impute default capacity for zero/null values
        df = df.with_columns(
            pl.when(pl.col("max_capacity") <= 0)
            .then(CONSTANTS.DEFAULT_PIPELINE_CAPACITY)
            .otherwise(pl.col("max_capacity"))
            .alias("max_capacity")
        )
        
        return df
    
    def step(self) -> pl.DataFrame:
        """Execute one simulation step for all pipelines.
        
        Resets daily counters at the start of each step.
        
        Returns:
            DataFrame with reset pipeline states
        """
        if self.agents.is_empty():
            return self.agents
        
        # Reset daily transport at start of step
        df = self.agents.with_columns([
            pl.lit(0.0).alias("daily_transport"),
            pl.lit(0.0).alias("utilization_pct"),
            pl.lit(0.0).alias("stranded_throughput"),
        ])
        
        self._agents = df
        return self.agents
    
    def receive_flow(self, volumes_by_pipeline: Dict[str, float]) -> Dict[str, float]:
        """Receive flow volumes for pipelines.
        
        Args:
            volumes_by_pipeline: Dict mapping pipeline_id to volume (bbl)
            
        Returns:
            Dict mapping pipeline_id to actually transported volume
        """
        if not volumes_by_pipeline:
            return {}
        
        # Create updates DataFrame
        updates = pl.DataFrame({
            "unique_id": list(volumes_by_pipeline.keys()),
            "requested_volume": list(volumes_by_pipeline.values())
        })
        
        # Join and calculate actual transport
        df = self.agents.join(updates, on="unique_id", how="left")
        
        df = df.with_columns([
            pl.col("requested_volume").fill_null(0.0).alias("requested_volume"),
        ])
        
        # Calculate actual transport (capped at capacity)
        df = df.with_columns([
            pl.when(pl.col("is_operational") & pl.col("is_active"))
            .then(
                pl.min_horizontal(
                    pl.col("requested_volume"),
                    pl.col("max_capacity") - pl.col("daily_transport")
                ).clip(lower_bound=0.0)
            )
            .otherwise(0.0)
            .alias("actual_transport")
        ])
        
        # Update transport metrics
        df = df.with_columns([
            (pl.col("daily_transport") + pl.col("actual_transport")).alias("daily_transport"),
            (pl.col("cumulative_transport") + pl.col("actual_transport")).alias("cumulative_transport"),
            (pl.col("requested_volume") - pl.col("actual_transport")).clip(lower_bound=0.0)
            .alias("stranded_throughput"),
        ])
        
        # Calculate utilization
        df = df.with_columns([
            pl.when(pl.col("max_capacity") > 0)
            .then((pl.col("daily_transport") / pl.col("max_capacity")) * 100)
            .otherwise(0.0)
            .alias("utilization_pct")
        ])
        
        # Get actual transport amounts for return
        result = dict(
            zip(
                df["unique_id"].to_list(),
                df["actual_transport"].to_list()
            )
        )
        
        # Clean up and update agents
        df = df.drop(["requested_volume", "actual_transport"])
        self._agents = df
        
        return result
    
    def receive_total_flow(self, total_volume: float) -> float:
        """Receive total flow and distribute across all active pipelines.
        
        Distributes flow proportionally based on available capacity.
        
        Args:
            total_volume: Total volume to transport (bbl)
            
        Returns:
            Actually transported volume (bbl)
        """
        if self.agents.is_empty() or total_volume <= 0:
            return 0.0
        
        df = self.agents
        
        # Calculate available capacity for each pipeline
        df = df.with_columns([
            pl.when(pl.col("is_operational") & pl.col("is_active"))
            .then((pl.col("max_capacity") - pl.col("daily_transport")).clip(lower_bound=0.0))
            .otherwise(0.0)
            .alias("available_capacity")
        ])
        
        total_available = df["available_capacity"].sum()
        
        if total_available <= 0:
            logger.warning("No pipeline capacity available")
            return 0.0
        
        # Calculate allocation per pipeline (proportional to available capacity)
        volume_to_allocate = min(total_volume, total_available)
        
        df = df.with_columns([
            pl.when(total_available > 0)
            .then(volume_to_allocate * pl.col("available_capacity") / total_available)
            .otherwise(0.0)
            .alias("allocated_volume")
        ])
        
        # Update transport metrics
        df = df.with_columns([
            (pl.col("daily_transport") + pl.col("allocated_volume")).alias("daily_transport"),
            (pl.col("cumulative_transport") + pl.col("allocated_volume")).alias("cumulative_transport"),
        ])
        
        # Calculate stranded volume
        stranded = max(0.0, total_volume - volume_to_allocate)
        
        df = df.with_columns([
            (pl.col("stranded_throughput") + stranded / df.shape[0]).alias("stranded_throughput")
        ])
        
        # Calculate utilization
        df = df.with_columns([
            pl.when(pl.col("max_capacity") > 0)
            .then((pl.col("daily_transport") / pl.col("max_capacity")) * 100)
            .otherwise(0.0)
            .alias("utilization_pct")
        ])
        
        # Clean up
        df = df.drop(["available_capacity", "allocated_volume"])
        self._agents = df
        
        return volume_to_allocate
    
    def get_total_capacity(self) -> float:
        """Get total capacity of all active pipelines.
        
        Returns:
            Total capacity in bbl/day
        """
        return self.agents.filter(
            pl.col("is_operational") & pl.col("is_active")
        )["max_capacity"].sum()
    
    def get_total_available_capacity(self) -> float:
        """Get total available (unused) capacity.
        
        Returns:
            Available capacity in bbl/day
        """
        df = self.agents.filter(
            pl.col("is_operational") & pl.col("is_active")
        )
        
        return (df["max_capacity"] - df["daily_transport"]).sum()
    
    def get_total_daily_transport(self) -> float:
        """Get total volume transported today.
        
        Returns:
            Total daily transport in bbl
        """
        return self.agents["daily_transport"].sum()
    
    def get_total_stranded(self) -> float:
        """Get total stranded throughput.
        
        Returns:
            Total stranded volume in bbl
        """
        return self.agents["stranded_throughput"].sum()
    
    def get_average_utilization(self) -> float:
        """Get average utilization across all pipelines.
        
        Returns:
            Average utilization percentage
        """
        active = self.agents.filter(
            pl.col("is_operational") & pl.col("is_active")
        )
        
        if active.is_empty():
            return 0.0
        
        return active["utilization_pct"].mean()
    
    def set_pipeline_status(
        self, 
        pipeline_ids: List[str], 
        is_active: bool
    ) -> None:
        """Set active status for specific pipelines.
        
        Args:
            pipeline_ids: List of pipeline IDs to update
            is_active: New active status
        """
        df = self.agents
        
        df = df.with_columns([
            pl.when(pl.col("unique_id").is_in(pipeline_ids))
            .then(pl.lit(is_active))
            .otherwise(pl.col("is_active"))
            .alias("is_active")
        ])
        
        self._agents = df
    
    def get_pipeline_summary(self) -> Dict[str, Any]:
        """Get summary statistics for all pipelines.
        
        Returns:
            Dictionary with summary statistics
        """
        df = self.agents
        
        if df.is_empty():
            return {
                "total_pipelines": 0,
                "active_pipelines": 0,
                "total_capacity": 0.0,
                "total_daily_transport": 0.0,
                "total_stranded": 0.0,
                "average_utilization": 0.0,
            }
        
        active = df.filter(pl.col("is_operational") & pl.col("is_active"))
        
        return {
            "total_pipelines": df.shape[0],
            "active_pipelines": active.shape[0],
            "total_capacity": active["max_capacity"].sum(),
            "total_daily_transport": df["daily_transport"].sum(),
            "total_cumulative_transport": df["cumulative_transport"].sum(),
            "total_stranded": df["stranded_throughput"].sum(),
            "average_utilization": active["utilization_pct"].mean() if not active.is_empty() else 0.0,
        }
    
    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Convert agents to list of dictionaries.
        
        Returns:
            List of pipeline state dictionaries
        """
        return self.agents.to_dicts()


# Backward compatibility - single pipeline wrapper
class PipelineAgent:
    """
    Single pipeline wrapper for backward compatibility.
    
    Wraps a single pipeline's data for use with code expecting
    the traditional agent interface.
    """
    
    def __init__(
        self,
        unique_id: str,
        model: "BasinModel",
        pipeline_id: Optional[str] = None,
        pipeline_name: str = "Pipeline",
        market_center: str = "Market",
        basin: str = "Basin",
        capacity_bpd: float = 0.0,
    ):
        """Initialize single pipeline wrapper."""
        self.unique_id = unique_id
        self.model = model
        self.pipeline_id = pipeline_id or unique_id
        self.pipeline_name = pipeline_name
        self.market_center = market_center
        self.basin = basin
        
        # Impute default capacity
        self.max_capacity = capacity_bpd if capacity_bpd > 0 else CONSTANTS.DEFAULT_PIPELINE_CAPACITY
        
        # State
        self.is_operational = True
        self.is_active = True
        self.daily_transport = 0.0
        self.cumulative_transport = 0.0
        self.utilization_pct = 0.0
        self.stranded_throughput = 0.0
    
    def receive_flow(self, volume: float) -> None:
        """Receive flow volume."""
        volume = max(volume, 0.0)
        self.daily_transport = volume
        self.cumulative_transport += volume
        
        self.utilization_pct = (
            (volume / self.max_capacity) * 100
            if self.max_capacity > 0 else 0.0
        )
    
    def add_flow(self, amount: float) -> float:
        """Add production flow to pipeline."""
        if not self.is_operational or not self.is_active:
            return 0.0
        
        available = max(0.0, self.max_capacity - self.daily_transport)
        actual = min(amount, available)
        
        self.daily_transport += actual
        self.cumulative_transport += actual
        
        self.utilization_pct = (
            (self.daily_transport / self.max_capacity) * 100
            if self.max_capacity > 0 else 0.0
        )
        
        return actual
    
    def reset_daily(self) -> None:
        """Reset daily counters."""
        self.daily_transport = 0.0
        self.utilization_pct = 0.0
        self.stranded_throughput = 0.0
    
    def activate(self) -> None:
        """Activate pipeline."""
        if self.max_capacity > 0:
            self.is_active = True
            self.is_operational = True
    
    def get_state(self) -> Dict[str, Any]:
        """Get pipeline state as dictionary.
        
        Returns:
            Dictionary with pipeline state
        """
        return {
            "unique_id": self.unique_id,
            "pipeline_id": self.pipeline_id,
            "pipeline_name": self.pipeline_name,
            "market_center": self.market_center,
            "basin": self.basin,
            "max_capacity": self.max_capacity,
            "daily_transport": self.daily_transport,
            "cumulative_transport": self.cumulative_transport,
            "utilization_pct": self.utilization_pct,
            "is_operational": self.is_operational,
            "is_active": self.is_active,
            "stranded_throughput": self.stranded_throughput,
        }
