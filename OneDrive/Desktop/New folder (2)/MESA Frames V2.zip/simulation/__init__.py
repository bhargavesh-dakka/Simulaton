"""
Mesa-Frames Optimized Basin Simulation Package.

This package provides a high-performance oil & gas basin simulation
using mesa-frames for vectorized agent operations.

MODULES:
- model: BasinModel - main simulation model
- runner: SimulationRunner - high-level API for running simulations
- agents: WellAgentSet, PipelineAgentSet, RefineryAgentSet

OPTIMIZATION:
- Mesa-frames ModelDF for vectorized operations
- Polars DataFrames for efficient data handling
- Supports 10,000+ wells efficiently

COMPLIANCE:
- Decline curve calculations per handbook
- Reserve depletion tracking
- Production by crude grade allocation
"""

from .model import BasinModel
from .runner import SimulationRunner
from .agents import (
    WellAgentSet,
    PipelineAgentSet,
    PipelineAgent,
    RefineryAgentSet,
)

__all__ = [
    "BasinModel",
    "SimulationRunner",
    "WellAgentSet",
    "PipelineAgentSet",
    "PipelineAgent",
    "RefineryAgentSet",
]

__version__ = "2.0.0"
