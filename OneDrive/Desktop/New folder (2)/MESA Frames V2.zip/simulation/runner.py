"""
SimulationRunner - High-level runner for UI/API integration.

This module provides a stable interface for running simulations
without exposing Mesa internals.

OPTIMIZATION:
- Uses mesa-frames BasinModel for vectorized operations
- Supports bulk well loading via DataFrames
- Efficient state access and progress tracking

COMPLIANCE:
- Stable interface (no Mesa internals exposed)
- Well validation against handbook rules
- Supports soft reset with optional well persistence
- Production and takeaway history export
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Optional, List, Dict, Any
from pathlib import Path

import polars as pl

from config.simulation_config import (
    WellType,
    DeclineType,
    DriveMechanism,
    WellConfiguration,
    VALIDATION_BOUNDS,
)
from utils.logging_config import get_logger, SimulationLogger
from exceptions import (
    SimulationNotInitializedError,
    WellValidationError,
    DateValidationError,
    OffshoreComplianceError,
)
from .model import BasinModel

logger = get_logger(__name__)
sim_logger = SimulationLogger(__name__)


class SimulationRunner:
    """
    High-level runner for UI / API integration.

    Hierarchy: Country > Market Center > Basins > Wells

    COMPLIANCE:
    - Stable interface (no Mesa internals exposed)
    - Well validation against handbook rules
    - Supports soft reset with optional well persistence
    - Production and takeaway history export
    
    Attributes:
        model: The underlying BasinModel
        is_running: Whether simulation is currently running
        pause_requested: Whether pause has been requested
        total_steps: Total number of simulation steps
        completed_steps: Number of completed steps
    """

    __api_version__ = "2.0.0"  # Mesa-frames version

    def __init__(
        self,
        total_recoverable_resources: float,
        start_date: datetime,
        end_date: datetime,
        basin_name: str = "Permian Basin",
        market_center: str = "Permian",
        country: str = "US",
        basin_reserves: Optional[float] = None,
        load_from_excel: bool = False,
        load_actual_production: bool = True,
    ) -> None:
        """
        Initialize SimulationRunner.
        
        Args:
            total_recoverable_resources: Total recoverable oil (bbl)
            start_date: Simulation start date
            end_date: Simulation end date
            basin_name: Basin name
            market_center: Market center name
            country: Country code
            basin_reserves: Initial basin reserves (bbl)
            load_from_excel: Whether to load wells from Excel files
            load_actual_production: Whether to auto-load actual production data
        """
        self._initial_basin_reserves = basin_reserves or total_recoverable_resources
        self._start_date = start_date
        self._end_date = end_date
        self._basin_name = basin_name
        self._market_center = market_center
        self._country = country
        self._load_actual_production = load_actual_production

        self.model = BasinModel(
            total_recoverable_resources=total_recoverable_resources,
            start_date=start_date,
            end_date=end_date,
            basin_name=basin_name,
            market_center=market_center,
            country=country,
            basin_reserves=basin_reserves,
        )

        self.is_running = False
        self.pause_requested = False
        self.total_steps = max(0, (end_date - start_date).days)
        self.completed_steps = 0

        # Persist well configs for soft reset
        self._well_configs: List[Dict[str, Any]] = []
        
        # Performance tracking
        self._step_times: List[float] = []
        self._last_progress_update = 0

        if load_from_excel:
            self._load_wells_from_excel()
            
            # Auto-load actual production data if requested
            if load_actual_production:
                try:
                    self.load_actual_production_data()
                except Exception as e:
                    logger.warning("Could not auto-load actual production data: %s", e)
        
        logger.info(
            "SimulationRunner initialized: basin=%s, period=%s to %s, total_steps=%d",
            basin_name,
            start_date.isoformat(),
            end_date.isoformat(),
            self.total_steps
        )

    # ------------------------------------------------------------------
    # SUMMARY & STATUS
    # ------------------------------------------------------------------
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Return a summary of the simulation configuration and state.
        
        Returns:
            Dictionary with simulation summary
        """
        return {
            "basin_name": self.model.basin_name,
            "country": self.model.country,
            "market_center": self.model.market_center,
            "start_date": self.model.start_date.isoformat() if self.model.start_date else None,
            "end_date": self.model.end_date.isoformat() if self.model.end_date else None,
            "total_recoverable_resources": self.model.basin_total_recoverable_resources,
            "remaining_reserves": self.model.basin_remaining_reserves,
            "cumulative_production": self.model.basin_cumulative_production,
            "recovery_factor": self.model.basin_recovery_factor,
            "num_wells": self.model.wells.agents.shape[0],
            "active_wells": self.model.wells.get_active_wells_count(),
        }

    def count_wells_in_simulation_range(self) -> int:
        """
        Return the number of wells currently loaded in the simulation.
        
        Returns:
            Number of wells in the model
        """
        return self.model.wells.agents.shape[0]

    # ------------------------------------------------------------------
    # CONFIGURATION
    # ------------------------------------------------------------------
    
    def set_drilling_constraints(self, constraints: Dict[str, Any]) -> None:
        """
        Set drilling constraints for the underlying BasinModel.
        
        Args:
            constraints: Dictionary of well_type -> max_wells_per_quarter
            
        Raises:
            AttributeError: If model doesn't support drilling constraints
        """
        if hasattr(self.model, "drilling_constraints"):
            self.model.drilling_constraints = constraints
            logger.info("Drilling constraints updated: %s", constraints)
        else:
            raise AttributeError("BasinModel does not support drilling constraints.")

    # ------------------------------------------------------------------
    # WELL LOADING
    # ------------------------------------------------------------------
    
    def _load_wells_from_excel(self) -> None:
        """Load wells from Excel data files with schema validation."""
        from utils.data_loader import load_and_merge_well_data
        
        result = load_and_merge_well_data(
            start_date=self.model.start_date,
            end_date=self.model.end_date,
            basin_name=self.model.basin_name,
            market_center=self.model.market_center,
            country=self.model.country
        )
        
        # Handle both tuple return (merged_df, metadata) and DataFrame return
        if isinstance(result, tuple):
            wells_df, metadata = result
        else:
            wells_df = result
            metadata = {}

        if wells_df is not None and not wells_df.is_empty():
            # Validate required fields
            required_fields = {
                "initial_production",
                "well_type",
                "decline_type",
                "b_factor",
                "nominal_decline_rate",
                "production_start_date",
            }
            
            missing = required_fields - set(wells_df.columns)
            if missing:
                raise WellValidationError(
                    f"Well data missing required fields: {missing}",
                    field=str(missing)
                )
            
            # Map api/API column to api_number for actual production lookup
            if "api" in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("api").cast(pl.Int64).alias("api_number")
                )
            elif "API" in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("API").cast(pl.Int64).alias("api_number")
                )
            
            # Map decline curve parameters for fallback simulation
            # last_known_qi from Qi/qi_latest_bopd column
            if "qi_latest_bopd" in wells_df.columns and "last_known_qi" not in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("qi_latest_bopd").cast(pl.Float64).alias("last_known_qi")
                )
            elif "Qi" in wells_df.columns and "last_known_qi" not in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("Qi").cast(pl.Float64).alias("last_known_qi")
                )
            
            # last_known_di from Di_per_month_latest column
            if "Di_per_month_latest" in wells_df.columns and "last_known_di" not in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("Di_per_month_latest").cast(pl.Float64).alias("last_known_di")
                )
            elif "Di" in wells_df.columns and "last_known_di" not in wells_df.columns:
                wells_df = wells_df.with_columns(
                    pl.col("Di").cast(pl.Float64).alias("last_known_di")
                )
            
            # last_data_date from latest_production_date column
            if "latest_production_date" in wells_df.columns and "last_data_date" not in wells_df.columns:
                # Handle both string and date types
                if wells_df["latest_production_date"].dtype == pl.Utf8:
                    wells_df = wells_df.with_columns(
                        pl.col("latest_production_date").str.to_date("%Y-%m-%d").alias("last_data_date")
                    )
                else:
                    wells_df = wells_df.with_columns(
                        pl.col("latest_production_date").alias("last_data_date")
                    )
            
            # Add wells from DataFrame
            self.model.add_wells_from_dataframe(wells_df)
            
            # Store configs for reset
            for row in wells_df.iter_rows(named=True):
                self._well_configs.append(row)
            
            logger.info("Loaded %d wells from Excel data", wells_df.shape[0])

    def load_wells_from_dataframe(self, wells_df: pl.DataFrame) -> None:
        """
        Load wells from a Polars DataFrame.
        
        This is the preferred method for bulk well loading.
        
        Args:
            wells_df: DataFrame with well configurations
        """
        self.model.add_wells_from_dataframe(wells_df)
        
        # Store configs for reset
        for row in wells_df.iter_rows(named=True):
            self._well_configs.append(row)
        
        logger.info("Loaded %d wells from DataFrame", wells_df.shape[0])
    
    def load_actual_production_data(
        self,
        fact_filename: str = "houston_fact_combined_cleaned.csv",
        basin_name: Optional[str] = None,
        market_center: Optional[str] = None,
        country: Optional[str] = None
    ) -> None:
        """
        Load actual production data from CSV for wells.
        
        This data will be used instead of simulation for historical periods.
        Simulation will only be used for future periods (when no actuals exist).
        
        Args:
            fact_filename: Name of the fact CSV file
            basin_name: Optional basin name filter
            market_center: Optional market center filter
            country: Optional country filter
        """
        self.model.load_actual_production_data(
            fact_filename=fact_filename,
            basin_name=basin_name,
            market_center=market_center,
            country=country
        )
        
        logger.info(
            "Loaded actual production data via runner for %s basin",
            basin_name or self.model.basin_name
        )

    # ------------------------------------------------------------------
    # WELL MANAGEMENT
    # ------------------------------------------------------------------
    
    def _validate_well_config(self, cfg: Dict[str, Any]) -> None:
        """
        Validate well configuration against handbook rules.
        
        Args:
            cfg: Well configuration dictionary
            
        Raises:
            WellValidationError: If configuration is invalid
            DateValidationError: If dates are invalid
            OffshoreComplianceError: If offshore compliance fails
        """
        # Validate b_factor
        b_factor = cfg.get("b_factor", 0)
        if b_factor < VALIDATION_BOUNDS.B_FACTOR_MIN or b_factor > VALIDATION_BOUNDS.B_FACTOR_MAX:
            raise WellValidationError(
                f"b_factor out of compliance range ({VALIDATION_BOUNDS.B_FACTOR_MIN}–{VALIDATION_BOUNDS.B_FACTOR_MAX})",
                field="b_factor",
                value=b_factor,
                constraint=f"Must be between {VALIDATION_BOUNDS.B_FACTOR_MIN} and {VALIDATION_BOUNDS.B_FACTOR_MAX}"
            )

        # Validate decline rate
        decline_rate = cfg.get("nominal_decline_rate", 0)
        if decline_rate <= 0:
            raise WellValidationError(
                "Nominal decline rate must be positive",
                field="nominal_decline_rate",
                value=decline_rate,
                constraint="Must be > 0"
            )

        # Validate production_start_date
        prod_start = cfg.get("production_start_date")
        if prod_start is not None:
            if not isinstance(prod_start, datetime):
                raise WellValidationError(
                    "production_start_date must be a datetime object",
                    field="production_start_date",
                    value=type(prod_start).__name__
                )

        # Validate offshore compliance
        location = cfg.get("location", "")
        well_type = cfg.get("well_type", "")
        if isinstance(location, str) and "offshore" in location.lower():
            if well_type != WellType.CONVENTIONAL_OFFSHORE.value:
                raise OffshoreComplianceError(
                    "Offshore wells must use 'Conventional Offshore' (COMPLIANCE)",
                    well_type=well_type,
                    location=location
                )

    def add_well(self, **kwargs) -> Dict[str, Any]:
        """
        Add a well and return its state (COMPLIANCE validated).
        
        Args:
            **kwargs: Well configuration parameters
            
        Returns:
            Dictionary containing the created well's state
            
        Raises:
            WellValidationError: If configuration is invalid
        """
        self._validate_well_config(kwargs)

        self.model.add_well(**kwargs)
        
        # Store config for reset
        self._well_configs.append(dict(kwargs))

        logger.debug("Well added via runner: %s", kwargs.get("unique_id"))

        # Return minimal state (actual well data is in DataFrame)
        return {
            "unique_id": kwargs.get("unique_id"),
            "well_type": kwargs.get("well_type"),
            "basin": kwargs.get("basin", self.model.basin_name),
            "initial_production": kwargs.get("initial_production"),
            "status": "added"
        }

    # ------------------------------------------------------------------
    # SIMULATION CONTROL
    # ------------------------------------------------------------------
    
    def start(self) -> None:
        """Start the simulation."""
        self.is_running = True
        self.model.simulation_active = True
        logger.info("Simulation started")

    def pause(self) -> None:
        """Pause the simulation."""
        self.pause_requested = True
        logger.info("Simulation pause requested")

    def resume(self) -> None:
        """Resume the simulation."""
        self.pause_requested = False
        logger.info("Simulation resumed")

    def step(self) -> Dict[str, Any]:
        """
        Execute one simulation step.
        
        Returns:
            Current simulation state
        """
        if self.pause_requested or not self.model.simulation_active:
            return self.get_state()

        start_time = time.perf_counter()
        
        step_result = self.model.step()
        
        elapsed = time.perf_counter() - start_time
        self._step_times.append(elapsed)

        if self.model.simulation_active:
            self.completed_steps += 1

        if self.completed_steps >= self.total_steps:
            self.model.simulation_active = False
            self.is_running = False
            logger.info("Simulation completed: %d steps", self.completed_steps)

        return self.get_state()

    def run_steps(
        self, 
        num_steps: int, 
        return_all: bool = False,
        progress_callback: Optional[callable] = None
    ) -> List[Dict[str, Any]]:
        """
        Run multiple simulation steps.
        
        Args:
            num_steps: Number of steps to run
            return_all: If True, return state after each step
            progress_callback: Optional callback for progress updates
            
        Returns:
            List of state dictionaries
        """
        states: List[Dict[str, Any]] = []

        for i in range(num_steps):
            if not self.model.simulation_active:
                break
            
            state = self.step()
            
            if return_all:
                states.append(state)
            
            if progress_callback and (i + 1) % 30 == 0:
                progress_callback(self.completed_steps, self.total_steps)

        return states if return_all else [self.get_state()]

    def run_simulation(
        self,
        progress_callback: Optional[callable] = None
    ) -> pl.DataFrame:
        """
        Run the complete simulation until end date.
        
        Args:
            progress_callback: Optional callback for progress updates
            
        Returns:
            DataFrame with simulation results
        """
        self.start()
        
        results_df = self.model.run_simulation(
            progress_callback=progress_callback
        )
        
        self.completed_steps = self.model._step_count
        self.is_running = False
        
        return results_df

    # ------------------------------------------------------------------
    # STATE ACCESS
    # ------------------------------------------------------------------
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get current simulation state with progress information.
        
        Returns:
            Dictionary with state and progress
        """
        # Use get_simulation_state for comprehensive state with wells
        model_state = self.model.get_simulation_state()
        
        avg_step_time = (
            sum(self._step_times[-100:]) / min(len(self._step_times), 100)
            if self._step_times else 0
        )
        
        return {
            "state": model_state,
            "progress": {
                "completed_steps": self.completed_steps,
                "total_steps": self.total_steps,
                "percentage": (
                    self.completed_steps / self.total_steps * 100
                    if self.total_steps > 0
                    else 0
                ),
                "avg_step_time_ms": avg_step_time * 1000,
                "estimated_remaining_seconds": (
                    avg_step_time * (self.total_steps - self.completed_steps)
                    if avg_step_time > 0 else None
                ),
            },
            "is_running": self.is_running,
            "pause_requested": self.pause_requested,
        }

    def get_production_data(self) -> Dict[str, Any]:
        """
        Get production data including history and basin state.
        
        Returns:
            Dictionary with production data
        """
        history_df = self.model.get_simulation_results()
        
        # Convert to list of dicts for API compatibility
        history = history_df.to_dicts() if not history_df.is_empty() else []

        basin_state = {
            "name": self.model.basin_name,
            "country": self.model.country,
            "market_center": self.model.market_center,
            "total_recoverable_resources": self.model.basin_total_recoverable_resources,
            "remaining_reserves": self.model.basin_remaining_reserves,
            "cumulative_production": self.model.basin_cumulative_production,
            "recovery_factor": self.model.basin_recovery_factor,
            "num_wells": self.model.wells.agents.shape[0],
            "active_wells": self.model.wells.get_active_wells_count(),
        }

        return {
            "history": history,
            "basin": basin_state,
            "current_date": self.model.current_date.isoformat(),
        }

    def get_wells_dataframe(self) -> pl.DataFrame:
        """
        Get wells as a Polars DataFrame.
        
        Returns:
            DataFrame with all wells and their current state
        """
        return self.model.get_wells_dataframe()

    # ------------------------------------------------------------------
    # RESET
    # ------------------------------------------------------------------
    
    def reset(self, keep_wells: bool = False) -> None:
        """
        Reset simulation; optionally restore wells.
        
        Args:
            keep_wells: If True, restore previously added wells
        """
        configs = list(self._well_configs)
        self._well_configs.clear()

        self.model = BasinModel(
            total_recoverable_resources=self._initial_basin_reserves,
            start_date=self._start_date,
            end_date=self._end_date,
            basin_name=self._basin_name,
            market_center=self._market_center,
            country=self._country,
            basin_reserves=self._initial_basin_reserves,
        )

        self.completed_steps = 0
        self.is_running = False
        self.pause_requested = False
        self._step_times.clear()

        if keep_wells:
            # Convert configs back to DataFrame and load
            if configs:
                wells_df = pl.DataFrame(configs)
                self.model.add_wells_from_dataframe(wells_df)
                self._well_configs = configs
        
        logger.info(
            "Simulation reset: keep_wells=%s, restored=%d wells",
            keep_wells,
            len(self._well_configs)
        )

    # ------------------------------------------------------------------
    # PIPELINE ACCESS
    # ------------------------------------------------------------------
    
    def get_pipeline_capacity(self) -> float:
        """
        Get pipeline maximum capacity.
        
        Returns:
            Maximum capacity in bbl/day
        """
        return self.model.pipeline.max_capacity

    def get_pipeline_utilization(self) -> Dict[str, Any]:
        """
        Get pipeline utilization details.
        
        Returns:
            Dictionary with utilization information
        """
        pipeline = self.model.pipeline
        return {
            "daily_transport": pipeline.daily_transport,
            "capacity": pipeline.max_capacity,
            "utilization_percentage": pipeline.utilization_pct,
            "cumulative_transported": pipeline.cumulative_transport,
        }

    def get_pipeline_state(self) -> Dict[str, Any]:
        """
        Get complete pipeline state.
        
        Returns:
            Dictionary with pipeline state
        """
        return self.model.pipeline.get_state()

    # ------------------------------------------------------------------
    # PRODUCTION VS TAKEAWAY
    # ------------------------------------------------------------------
    
    def get_production_vs_takeaway(self) -> List[Dict[str, Any]]:
        """
        Daily production vs pipeline takeaway comparison.
        
        Returns:
            List with comparison data from simulation history
        """
        history = self.model.simulation_history
        
        if not history:
            return []
        
        # Return last entry for current state comparison
        latest = history[-1]
        
        return [{
            "date": latest.get("date"),
            "daily_production": latest.get("total_realized_production", 0),
            "potential_production": latest.get("total_potential_production", 0),
            "pipeline_capacity": self.model.pipeline.max_capacity,
            "pipeline_transported": latest.get("pipeline_transported", 0),
            "pipeline_utilization_pct": latest.get("pipeline_utilization_pct", 0),
            "gap": latest.get("total_realized_production", 0) - latest.get("pipeline_transported", 0),
            "active_wells": latest.get("active_wells", 0),
            "total_wells": latest.get("total_wells", 0),
        }]

    # ------------------------------------------------------------------
    # PERFORMANCE METRICS
    # ------------------------------------------------------------------
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """
        Get simulation performance metrics.
        
        Returns:
            Dictionary with performance statistics
        """
        if not self._step_times:
            return {
                "steps_executed": 0,
                "avg_step_time_ms": 0,
                "min_step_time_ms": 0,
                "max_step_time_ms": 0,
                "total_time_seconds": 0,
                "steps_per_second": 0,
            }
        
        return {
            "steps_executed": len(self._step_times),
            "avg_step_time_ms": sum(self._step_times) / len(self._step_times) * 1000,
            "min_step_time_ms": min(self._step_times) * 1000,
            "max_step_time_ms": max(self._step_times) * 1000,
            "total_time_seconds": sum(self._step_times),
            "steps_per_second": len(self._step_times) / sum(self._step_times) if sum(self._step_times) > 0 else 0,
        }
