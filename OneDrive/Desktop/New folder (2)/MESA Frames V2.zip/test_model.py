"""
Test module for BasinModel - validates all core and new methods.
"""

import sys
from datetime import datetime, timedelta

import polars as pl

# Add parent to path for imports
sys.path.insert(0, '.')

from simulation.model import BasinModel, MinimalStateCollector
from config.simulation_config import WellType


def test_minimal_state_collector():
    """Test MinimalStateCollector functionality."""
    print("\n" + "="*60)
    print("TEST: MinimalStateCollector")
    print("="*60)
    
    # Create model
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
        basin_name="Test Basin",
        market_center="Permian",
    )
    
    # Add a test well
    model.add_well(
        well_name="TEST-001",
        well_type=WellType.CONVENTIONAL_OFFSHORE.value,
        initial_production=100.0,
        decline_rate=0.05,
        qi_bopd=100.0,
        crude_grade="Light Sweet",
    )
    
    # Create collector
    collector = MinimalStateCollector()
    
    # Initial state should be None
    assert collector.get_current_state() is None
    assert collector.get_previous_state() is None
    print("✓ Initial state is None")
    
    # Run a step and collect
    model.step()
    collector.collect(model)
    
    # Now current state should exist
    current = collector.get_current_state()
    assert current is not None
    assert "current_date" in current
    assert "basin" in current
    assert "pipeline" in current
    assert "wells" in current
    assert "summary" in current
    print("✓ State collected with correct structure")
    
    # Previous should still be None (first collect)
    assert collector.get_previous_state() is None
    print("✓ Previous state is None after first collect")
    
    # Run another step and collect
    model.step()
    collector.collect(model)
    
    # Now previous should have first state
    prev = collector.get_previous_state()
    assert prev is not None
    print("✓ Previous state exists after second collect")
    
    # Test DataFrame methods
    model_df = collector.get_model_vars_dataframe()
    assert not model_df.is_empty()
    assert "current_date" in model_df.columns
    print(f"✓ Model vars DataFrame: {model_df.shape}")
    
    agent_df = collector.get_agent_vars_dataframe()
    assert not agent_df.is_empty()
    assert "AgentID" in agent_df.columns
    print(f"✓ Agent vars DataFrame: {agent_df.shape}")
    
    print("\n✓ MinimalStateCollector: ALL TESTS PASSED")


def test_get_quarter():
    """Test _get_quarter method."""
    print("\n" + "="*60)
    print("TEST: _get_quarter")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 15),
        end_date=datetime(2024, 12, 31),
    )
    
    # Test Q1
    model.current_date = datetime(2024, 1, 15)
    assert model._get_quarter() == (2024, 1)
    print("✓ January -> Q1")
    
    # Test Q2
    model.current_date = datetime(2024, 5, 15)
    assert model._get_quarter() == (2024, 2)
    print("✓ May -> Q2")
    
    # Test Q3
    model.current_date = datetime(2024, 8, 15)
    assert model._get_quarter() == (2024, 3)
    print("✓ August -> Q3")
    
    # Test Q4
    model.current_date = datetime(2024, 11, 15)
    assert model._get_quarter() == (2024, 4)
    print("✓ November -> Q4")
    
    # Test with explicit date
    result = model._get_quarter(datetime(2023, 6, 1))
    assert result == (2023, 2)
    print("✓ Explicit date (June 2023) -> (2023, 2)")
    
    print("\n✓ _get_quarter: ALL TESTS PASSED")


def test_get_selected_basins():
    """Test _get_selected_basins method."""
    print("\n" + "="*60)
    print("TEST: _get_selected_basins")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
        basin_name="Delaware Basin",
    )
    
    # With no wells, should return model's basin name
    basins = model._get_selected_basins()
    assert basins == ["Delaware Basin"]
    print(f"✓ No wells -> [{model.basin_name}]")
    
    # Add well without basin column - should still return model basin
    model.add_well(
        well_name="WELL-001",
        initial_production=100.0,
        decline_rate=0.05,
        qi_bopd=100.0,
    )
    
    basins = model._get_selected_basins()
    print(f"✓ With wells (no basin col) -> {basins}")
    
    print("\n✓ _get_selected_basins: ALL TESTS PASSED")


def test_check_drilling_constraint():
    """Test _check_drilling_constraint method."""
    print("\n" + "="*60)
    print("TEST: _check_drilling_constraint")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 3, 31),
    )
    
    # Set constraint to 2 offshore wells per quarter
    model.drilling_constraints[WellType.CONVENTIONAL_OFFSHORE.value] = 2
    
    well_type = WellType.CONVENTIONAL_OFFSHORE.value
    
    # First two should pass
    assert model._check_drilling_constraint(well_type) == True
    print("✓ First check: allowed")
    
    # Manually increment tracker
    quarter = model._get_quarter()
    model.quarterly_drilling_tracker[quarter] = {well_type: 2}
    
    # Third should fail
    assert model._check_drilling_constraint(well_type) == False
    print("✓ After hitting limit: not allowed")
    
    # Different well type should still pass
    assert model._check_drilling_constraint("some_other_type") == True
    print("✓ Different well type: allowed")
    
    print("\n✓ _check_drilling_constraint: ALL TESTS PASSED")


def test_monthly_to_daily():
    """Test _monthly_to_daily conversion."""
    print("\n" + "="*60)
    print("TEST: _monthly_to_daily")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 12, 31),
    )
    
    # January 2024 has 31 days
    daily = model._monthly_to_daily(31000, 1, 2024)
    assert abs(daily - 1000.0) < 0.01
    print(f"✓ 31000 bbl / 31 days = {daily:.2f} bbl/day")
    
    # February 2024 (leap year) has 29 days
    daily = model._monthly_to_daily(29000, 2, 2024)
    assert abs(daily - 1000.0) < 0.01
    print(f"✓ 29000 bbl / 29 days = {daily:.2f} bbl/day")
    
    # April has 30 days
    daily = model._monthly_to_daily(30000, 4, 2024)
    assert abs(daily - 1000.0) < 0.01
    print(f"✓ 30000 bbl / 30 days = {daily:.2f} bbl/day")
    
    print("\n✓ _monthly_to_daily: ALL TESTS PASSED")


def test_pipeline_overflow():
    """Test _handle_pipeline_overflow method."""
    print("\n" + "="*60)
    print("TEST: _handle_pipeline_overflow")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
    )
    
    # Default pipeline capacity is 100,000 bpd
    # Storage buffer max = 100,000 * 7 = 700,000 bbl
    initial_buffer = model.pipeline_storage_buffer
    assert initial_buffer == 0
    print(f"✓ Initial storage buffer: {initial_buffer}")
    
    # Add 50,000 bbl overflow
    stored = model._handle_pipeline_overflow(50000)
    assert stored == 50000
    assert model.pipeline_storage_buffer == 50000
    print(f"✓ Stored 50,000 bbl, buffer now: {model.pipeline_storage_buffer}")
    
    # Add more overflow
    stored = model._handle_pipeline_overflow(100000)
    assert stored == 100000
    assert model.pipeline_storage_buffer == 150000
    print(f"✓ Stored 100,000 more, buffer now: {model.pipeline_storage_buffer}")
    
    print("\n✓ _handle_pipeline_overflow: ALL TESTS PASSED")


def test_get_simulation_state():
    """Test get_simulation_state method."""
    print("\n" + "="*60)
    print("TEST: get_simulation_state")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
        basin_name="Test Basin",
        market_center="Permian",
    )
    
    # Add well
    model.add_well(
        well_name="STATE-001",
        initial_production=500.0,
        decline_rate=0.05,
        qi_bopd=500.0,
    )
    
    # Run a few steps
    for _ in range(5):
        model.step()
    
    # Get state
    state = model.get_simulation_state()
    
    assert "current_date" in state
    assert "step" in state
    assert "basin" in state
    assert "pipeline" in state
    assert "wells" in state
    assert "summary" in state
    assert "monthly_accumulator" in state
    
    print(f"✓ Current date: {state['current_date']}")
    print(f"✓ Step: {state['step']}")
    print(f"✓ Basin: {state['basin']['name']}")
    print(f"✓ Active wells: {state['summary']['active_wells']}")
    print(f"✓ Total daily production: {state['summary']['total_daily_production']:.2f}")
    
    print("\n✓ get_simulation_state: ALL TESTS PASSED")


def test_get_monthly_accumulator_state():
    """Test get_monthly_accumulator_state method."""
    print("\n" + "="*60)
    print("TEST: get_monthly_accumulator_state")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 2, 28),
    )
    
    # Add well
    model.add_well(
        well_name="ACC-001",
        initial_production=1000.0,
        decline_rate=0.05,
        qi_bopd=1000.0,
        crude_grade="Light Sweet",
    )
    
    # Run for 10 days
    for _ in range(10):
        model.step()
    
    # Get accumulator state
    acc_state = model.get_monthly_accumulator_state()
    
    assert "year" in acc_state
    assert "month" in acc_state
    assert "production_by_grade" in acc_state
    assert "total_production" in acc_state
    
    print(f"✓ Year: {acc_state['year']}")
    print(f"✓ Month: {acc_state['month']}")
    print(f"✓ Total production: {acc_state['total_production']:.2f}")
    print(f"✓ Production by grade: {acc_state['production_by_grade']}")
    
    print("\n✓ get_monthly_accumulator_state: ALL TESTS PASSED")


def test_pipeline_methods():
    """Test pipeline-related methods."""
    print("\n" + "="*60)
    print("TEST: Pipeline Methods")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
    )
    
    # Add well and run
    model.add_well(
        well_name="PIPE-001",
        initial_production=5000.0,
        decline_rate=0.05,
        qi_bopd=5000.0,
    )
    
    model.step()
    
    # Test get_pipeline_daily_output
    daily_output = model.get_pipeline_daily_output()
    assert "pipeline_id" in daily_output
    assert "daily_transport" in daily_output
    assert "capacity_bpd" in daily_output
    print(f"✓ Pipeline daily output: {daily_output['daily_transport']:.2f} bbl")
    
    # Test get_all_pipelines_daily_output
    all_outputs = model.get_all_pipelines_daily_output()
    assert len(all_outputs) >= 1
    print(f"✓ All pipelines output: {len(all_outputs)} pipeline(s)")
    
    # Test get_pipeline_state
    pipe_state = model.get_pipeline_state()
    assert "total_capacity_bpd" in pipe_state
    assert "total_daily_transport" in pipe_state
    assert "storage_buffer" in pipe_state
    print(f"✓ Pipeline state: capacity={pipe_state['total_capacity_bpd']}, transport={pipe_state['total_daily_transport']:.2f}")
    
    print("\n✓ Pipeline Methods: ALL TESTS PASSED")


def test_allocate_pipeline_daily_flow():
    """Test _allocate_pipeline_daily_flow method."""
    print("\n" + "="*60)
    print("TEST: _allocate_pipeline_daily_flow")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
    )
    
    # Reset pipeline
    model.pipeline.reset_daily()
    
    # Allocate 50,000 bbl (within capacity)
    allocation = model._allocate_pipeline_daily_flow(50000)
    
    assert model.pipeline.unique_id in allocation
    assert allocation[model.pipeline.unique_id] == 50000
    print(f"✓ Allocated 50,000 bbl: {allocation}")
    
    # Reset and try overflow scenario
    model.pipeline.reset_daily()
    model.pipeline.max_capacity = 10000  # Limit to 10,000
    
    allocation = model._allocate_pipeline_daily_flow(15000)
    transported = allocation[model.pipeline.unique_id]
    
    # Should transport max capacity and overflow to storage
    assert transported <= 10000
    assert model.pipeline_storage_buffer >= 5000
    print(f"✓ With limited capacity: transported={transported}, overflow stored={model.pipeline_storage_buffer}")
    
    print("\n✓ _allocate_pipeline_daily_flow: ALL TESTS PASSED")


def test_state_conversion_methods():
    """Test _state_to_model_dict and _state_to_agent_dict."""
    print("\n" + "="*60)
    print("TEST: State Conversion Methods")
    print("="*60)
    
    model = BasinModel(
        total_recoverable_resources=1_000_000,
        start_date=datetime(2024, 1, 1),
        end_date=datetime(2024, 1, 31),
    )
    
    # Add wells
    for i in range(3):
        model.add_well(
            well_name=f"CONV-{i:03d}",
            initial_production=100.0 * (i + 1),
            decline_rate=0.05,
            qi_bopd=100.0 * (i + 1),
        )
    
    model.step()
    
    # Get full state
    state = model.get_simulation_state()
    
    # Convert to model dict
    model_dict = model._state_to_model_dict(state)
    assert "current_date" in model_dict
    assert "total_production" in model_dict
    assert "daily_production" in model_dict
    assert "num_active_wells" in model_dict
    print(f"✓ Model dict: active_wells={model_dict['num_active_wells']}, daily={model_dict['daily_production']:.2f}")
    
    # Convert to agent list
    agent_list = model._state_to_agent_dict(state)
    assert len(agent_list) == 3
    assert all("well_id" in a for a in agent_list)
    assert all("daily_production" in a for a in agent_list)
    print(f"✓ Agent list: {len(agent_list)} agents")
    
    print("\n✓ State Conversion Methods: ALL TESTS PASSED")


def run_all_tests():
    """Run all tests."""
    print("\n" + "="*60)
    print("RUNNING ALL BASIN MODEL TESTS")
    print("="*60)
    
    tests = [
        test_minimal_state_collector,
        test_get_quarter,
        test_get_selected_basins,
        test_check_drilling_constraint,
        test_monthly_to_daily,
        test_pipeline_overflow,
        test_get_simulation_state,
        test_get_monthly_accumulator_state,
        test_pipeline_methods,
        test_allocate_pipeline_daily_flow,
        test_state_conversion_methods,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"\n✗ {test.__name__} FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "="*60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("="*60)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
